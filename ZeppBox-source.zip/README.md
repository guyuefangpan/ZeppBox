# ZeppBox

Zepp OS 1.0 开发工具盒 — 小米手环第三方管理工具

## 功能

- BLE 蓝牙连接管理（MAC + AuthKey 认证）
- 设备信息读取
- 应用安装与卸载
- 安装队列管理
- 桌面小组件（蓝牙状态显示）
- 通知栏常驻连接状态

## 技术栈

- Android (Java 17, minSdk 24, targetSdk 34)
- WebView + HTML/CSS/JS 前端
- BLE (Gadgetbridge BtLEQueue 架构)
- ECDH sect163k1 认证
- Zepp OS 2021 Chunked Transfer 协议

## 构建

```bash
./gradlew assembleDebug
```

## 说明

本项目反编译自 APK，部分注释和格式可能丢失。
