# Add project specific ProGuard rules here.
# Keep BLE related classes
-keep class com.zmake.mobile.** { *; }
