package com.zmake.mobile;

import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;
import java.util.Random;

/* loaded from: classes3.dex */
public class ECDH_B163 {
    static final int BITVEC_MARGIN = 3;
    static final int BITVEC_NBITS = 166;
    static final int BITVEC_NBYTES = 24;
    static final int BITVEC_NWORDS = 6;
    static final int CURVE_DEGREE = 163;
    static final int ECC_PRV_KEY_SIZE = 24;
    static final int ECC_PUB_KEY_SIZE = 48;
    static final int[] polynomial = {201, 0, 0, 0, 0, 8};
    static final int[] coeff_b = {1244792317, 1362065524, 344058640, -1194765366, 174070023, 2};
    static final int[] base_x = {-399229386, -728152521, -1600581272, -2036148866, -252993182, 3};
    static final int[] base_y = {2037589233, -1323541492, -1563568827, 1906313551, -719340436, 0};
    static final int[] base_order = {-1541190605, 2011630610, 168702, 0, 0, 4};

    static int bitvec_get_bit(int[] x, int idx) {
        return (int) (((x[idx / 32] & 4294967295L) >> (idx & 31)) & 1);
    }

    static void bitvec_clr_bit(int[] x, int idx) {
        int i = idx / 32;
        x[i] = x[i] & (~(1 << (idx & 31)));
    }

    static void bitvec_copy(int[] x, int[] y) {
        for (int i = 0; i < 6; i++) {
            x[i] = y[i];
        }
    }

    static void bitvec_swap(int[] x, int[] y) {
        int[] tmp = new int[6];
        bitvec_copy(tmp, x);
        bitvec_copy(x, y);
        bitvec_copy(y, tmp);
    }

    static boolean bitvec_equal(int[] x, int[] y) {
        for (int i = 0; i < 6; i++) {
            if (x[i] != y[i]) {
                return false;
            }
        }
        return true;
    }

    static void bitvec_set_zero(int[] x) {
        for (int i = 0; i < 6; i++) {
            x[i] = 0;
        }
    }

    static boolean bitvec_is_zero(int[] x) {
        int i = 0;
        while (i < 6 && x[i] == 0) {
            i++;
        }
        return i == 6;
    }

    static int bitvec_degree(int[] x) {
        int i = 192;
        int y = 6;
        while (i > 0) {
            y--;
            if (x[y] != 0) {
                break;
            }
            i -= 32;
        }
        if (i != 0) {
            int u32mask = Integer.MIN_VALUE;
            while ((x[y] & u32mask) == 0) {
                u32mask = (int) ((u32mask & 4294967295L) >> 1);
                i--;
            }
        }
        return i;
    }

    static void bitvec_lshift(int[] x, int[] y, int nbits) {
        int nwords = nbits / 32;
        int i = 0;
        while (i < nwords) {
            x[i] = 0;
            i++;
        }
        int j = 0;
        while (i < 6) {
            x[i] = y[j];
            i++;
            j++;
        }
        int nbits2 = nbits & 31;
        if (nbits2 != 0) {
            for (int i2 = 5; i2 > 0; i2--) {
                x[i2] = (int) ((x[i2] << nbits2) | ((x[i2 - 1] & 4294967295L) >> (32 - nbits2)));
            }
            x[0] = (int) (x[0] << nbits2);
        }
    }

    static void gf2field_set_one(int[] x) {
        x[0] = 1;
        for (int i = 1; i < 6; i++) {
            x[i] = 0;
        }
    }

    static boolean gf2field_is_one(int[] x) {
        if (x[0] != 1) {
            return false;
        }
        int i = 1;
        while (i < 6 && x[i] == 0) {
            i++;
        }
        return i == 6;
    }

    static void gf2field_add(int[] z, int[] x, int[] y) {
        for (int i = 0; i < 6; i++) {
            z[i] = x[i] ^ y[i];
        }
    }

    static void gf2field_inc(int[] x) {
        x[0] = x[0] ^ 1;
    }

    static void gf2field_mul(int[] z, int[] x, int[] y) {
        int[] tmp = new int[6];
        bitvec_copy(tmp, x);
        if (bitvec_get_bit(y, 0) != 0) {
            bitvec_copy(z, x);
        } else {
            bitvec_set_zero(z);
        }
        for (int i = 1; i < CURVE_DEGREE; i++) {
            bitvec_lshift(tmp, tmp, 1);
            if (bitvec_get_bit(tmp, CURVE_DEGREE) != 0) {
                gf2field_add(tmp, tmp, polynomial);
            }
            if (bitvec_get_bit(y, i) != 0) {
                gf2field_add(z, z, tmp);
            }
        }
    }

    static void gf2field_inv(int[] z, int[] x) {
        int[] u = new int[6];
        int[] v = new int[6];
        int[] g = new int[6];
        int[] h = new int[6];
        bitvec_copy(u, x);
        bitvec_copy(v, polynomial);
        bitvec_set_zero(g);
        gf2field_set_one(z);
        while (!gf2field_is_one(u)) {
            int i = bitvec_degree(u) - bitvec_degree(v);
            if (i < 0) {
                bitvec_swap(u, v);
                bitvec_swap(g, z);
                i = -i;
            }
            bitvec_lshift(h, v, i);
            gf2field_add(u, u, h);
            bitvec_lshift(h, g, i);
            gf2field_add(z, z, h);
        }
    }

    static void gf2point_copy(int[] x1, int[] y1, int[] x2, int[] y2) {
        bitvec_copy(x1, x2);
        bitvec_copy(y1, y2);
    }

    static void gf2point_set_zero(int[] x, int[] y) {
        bitvec_set_zero(x);
        bitvec_set_zero(y);
    }

    static boolean gf2point_is_zero(int[] x, int[] y) {
        return bitvec_is_zero(x) && bitvec_is_zero(y);
    }

    static void gf2point_double(int[] x, int[] y) {
        if (!bitvec_is_zero(x)) {
            int[] l = new int[6];
            gf2field_inv(l, x);
            gf2field_mul(l, l, y);
            gf2field_add(l, l, x);
            gf2field_mul(y, x, x);
            gf2field_mul(x, l, l);
            gf2field_inc(l);
            gf2field_add(x, x, l);
            gf2field_mul(l, l, x);
            gf2field_add(y, y, l);
            return;
        }
        bitvec_set_zero(y);
    }

    static void gf2point_add(int[] x1, int[] y1, int[] x2, int[] y2) {
        if (!gf2point_is_zero(x2, y2)) {
            if (!gf2point_is_zero(x1, y1)) {
                if (bitvec_equal(x1, x2)) {
                    if (!bitvec_equal(y1, y2)) {
                        gf2point_set_zero(x1, y1);
                        return;
                    } else {
                        gf2point_double(x1, y1);
                        return;
                    }
                }
                int[] a = new int[6];
                int[] b = new int[6];
                int[] c = new int[6];
                int[] d = new int[6];
                gf2field_add(a, y1, y2);
                gf2field_add(b, x1, x2);
                gf2field_inv(c, b);
                gf2field_mul(c, c, a);
                gf2field_mul(d, c, c);
                gf2field_add(d, d, c);
                gf2field_add(d, d, b);
                gf2field_inc(d);
                gf2field_add(x1, x1, d);
                gf2field_mul(a, x1, c);
                gf2field_add(a, a, d);
                gf2field_add(y1, y1, a);
                bitvec_copy(x1, d);
                return;
            }
            gf2point_copy(x1, y1, x2, y2);
        }
    }

    static void gf2point_mul(int[] x, int[] y, int[] exp) {
        int[] tmpx = new int[6];
        int[] tmpy = new int[6];
        int nbits = bitvec_degree(exp);
        gf2point_set_zero(tmpx, tmpy);
        for (int i = nbits - 1; i >= 0; i--) {
            gf2point_double(tmpx, tmpy);
            if (bitvec_get_bit(exp, i) != 0) {
                gf2point_add(tmpx, tmpy, x, y);
            }
        }
        gf2point_copy(x, y, tmpx, tmpy);
    }

    static boolean gf2point_on_curve(int[] x, int[] y) {
        int[] a = new int[6];
        int[] b = new int[6];
        if (gf2point_is_zero(x, y)) {
            return false;
        }
        gf2field_mul(a, x, x);
        gf2field_mul(b, a, x);
        gf2field_add(a, a, b);
        gf2field_add(a, a, coeff_b);
        gf2field_mul(b, y, y);
        gf2field_add(a, a, b);
        gf2field_mul(b, x, y);
        return bitvec_equal(a, b);
    }

    static int[] bytes_to_int(byte[] bytes, int offset) {
        int[] value = new int[6];
        int byteptr = offset;
        int i = 0;
        while (i < 6) {
            int byteptr2 = byteptr + 1;
            int byteptr3 = byteptr2 + 1;
            int i2 = (bytes[byteptr] & 255) | ((bytes[byteptr2] & 255) << 8);
            int byteptr4 = byteptr3 + 1;
            int i3 = i2 | ((bytes[byteptr3] & 255) << 16);
            value[i] = i3 | ((bytes[byteptr4] & 255) << 24);
            i++;
            byteptr = byteptr4 + 1;
        }
        return value;
    }

    static void ints_to_bytes(byte[] bytes, int[] ints, int offset) {
        int byteptr = offset;
        for (int i = 0; i < 6; i++) {
            int byteptr2 = byteptr + 1;
            bytes[byteptr] = (byte) (ints[i] & 255);
            int byteptr3 = byteptr2 + 1;
            bytes[byteptr2] = (byte) ((ints[i] & MotionEventCompat.ACTION_POINTER_INDEX_MASK) >> 8);
            int byteptr4 = byteptr3 + 1;
            bytes[byteptr3] = (byte) ((ints[i] & 16711680) >> 16);
            byteptr = byteptr4 + 1;
            bytes[byteptr4] = (byte) ((ints[i] & ViewCompat.MEASURED_STATE_MASK) >> 24);
        }
    }

    public static boolean ecdh_generate_keys(byte[] public_key, byte[] private_key) {
        int[] private_key_int32 = bytes_to_int(private_key, 0);
        int[] public_key_int32_1 = bytes_to_int(public_key, 0);
        int[] public_key_int32_2 = bytes_to_int(public_key, 24);
        gf2point_copy(public_key_int32_1, public_key_int32_2, base_x, base_y);
        if (bitvec_degree(private_key_int32) < 81) {
            return false;
        }
        int nbits = bitvec_degree(base_order);
        for (int i = nbits - 1; i < 192; i++) {
            bitvec_clr_bit(private_key_int32, i);
        }
        gf2point_mul(public_key_int32_1, public_key_int32_2, private_key_int32);
        ints_to_bytes(public_key, public_key_int32_1, 0);
        ints_to_bytes(public_key, public_key_int32_2, 24);
        return true;
    }

    public static boolean ecdh_shared_secret(byte[] private_key, byte[] others_pub, byte[] output) {
        int[] private_key_int32 = bytes_to_int(private_key, 0);
        int[] others_pub_int32_1 = bytes_to_int(others_pub, 0);
        int[] others_pub_int32_2 = bytes_to_int(others_pub, 24);
        if (gf2point_is_zero(others_pub_int32_1, others_pub_int32_2) || !gf2point_on_curve(others_pub_int32_1, others_pub_int32_2)) {
            return false;
        }
        System.arraycopy(others_pub, 0, output, 0, ECC_PUB_KEY_SIZE);
        int nbits = bitvec_degree(base_order);
        for (int i = nbits - 1; i < 192; i++) {
            bitvec_clr_bit(private_key_int32, i);
        }
        int[] output_int32_1 = bytes_to_int(output, 0);
        int[] output_int32_2 = bytes_to_int(output, 24);
        gf2point_mul(output_int32_1, output_int32_2, private_key_int32);
        ints_to_bytes(output, output_int32_1, 0);
        ints_to_bytes(output, output_int32_2, 24);
        return true;
    }

    public static byte[][] generateKeyPair() {
        byte[] privateKey = new byte[24];
        byte[] publicKey = new byte[ECC_PUB_KEY_SIZE];
        Random r = new Random();
        for (int attempt = 0; attempt < 10; attempt++) {
            r.nextBytes(privateKey);
            if (ecdh_generate_keys(publicKey, privateKey)) {
                break;
            }
        }
        return new byte[][]{privateKey, publicKey};
    }

    public static byte[] computeSharedSecret(byte[] privateKey, byte[] remotePublicKey) {
        byte[] shared = new byte[ECC_PUB_KEY_SIZE];
        ecdh_shared_secret(privateKey, remotePublicKey, shared);
        return shared;
    }

    public static boolean verifyPublicKey(byte[] publicKey) {
        if (publicKey == null || publicKey.length != ECC_PUB_KEY_SIZE) {
            return false;
        }
        int[] x = bytes_to_int(publicKey, 0);
        int[] y = bytes_to_int(publicKey, 24);
        return gf2point_on_curve(x, y);
    }
}
