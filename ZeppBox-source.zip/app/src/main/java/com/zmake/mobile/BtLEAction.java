package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;

/* loaded from: classes3.dex */
public abstract class BtLEAction {
    private final BluetoothGattCharacteristic characteristic;

    public abstract boolean expectsResult();

    public abstract String getKind();

    public abstract boolean run(BluetoothGatt bluetoothGatt);

    public BtLEAction(BluetoothGattCharacteristic characteristic) {
        this.characteristic = characteristic;
    }

    public BluetoothGattCharacteristic getCharacteristic() {
        return this.characteristic;
    }

    public void onGattCallback(int status, byte[] value) {
    }

    public String toString() {
        String name = getCharacteristic() != null ? getCharacteristic().getUuid().toString() : "null";
        return getKind() + " on " + name;
    }
}
