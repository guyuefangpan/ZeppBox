package com.zmake.mobile;

import android.util.Log;
import java.util.zip.CRC32;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: classes3.dex */
public class Huami2021ChunkedEncoder {
    private static final String TAG = "Huami2021ChunkEncoder";
    private final SendCallback sendCallback;
    private byte mHandle = 0;
    private int mEncryptionSequenceNumber = 0;
    private byte[] mSharedSessionKey = null;
    private int mMTU = 23;

    /* loaded from: classes3.dex */
    public interface SendCallback {
        void onSendChunk(byte[] bArr);
    }

    public Huami2021ChunkedEncoder(SendCallback callback) {
        this.sendCallback = callback;
    }

    public void setMTU(int mtu) {
        this.mMTU = mtu;
    }

    public void setEncryptionParameters(int sequenceNumber, byte[] sessionKey) {
        this.mEncryptionSequenceNumber = sequenceNumber;
        this.mSharedSessionKey = sessionKey;
        Log.d(TAG, "Encryption set: seqNr=" + sequenceNumber + " keyLen=" + (sessionKey != null ? sessionKey.length : 0));
    }

    public void reset() {
        this.mHandle = (byte) 0;
        this.mEncryptionSequenceNumber = 0;
        this.mSharedSessionKey = null;
    }

    public void write(short endpoint, byte[] data, boolean encrypt) {
        byte[] payloadData;
        int payloadLen;
        short s = endpoint;
        boolean z = encrypt;
        Log.d(TAG, "write: endpoint=0x" + String.format("%04x", Integer.valueOf(65535 & s)) + " len=" + data.length + " encrypt=" + z);
        if (!z || this.mSharedSessionKey != null) {
            this.mHandle = (byte) (this.mHandle + 1);
            byte handle = this.mHandle;
            int length = data.length;
            byte count = 0;
            if (z) {
                if (this.mSharedSessionKey == null) {
                    Log.e(TAG, "Cannot encrypt: no session key");
                    return;
                }
                byte[] messageKey = new byte[16];
                for (int i = 0; i < 16; i++) {
                    messageKey[i] = (byte) (this.mSharedSessionKey[i] ^ handle);
                }
                int encLen = length + 8;
                int overflow = encLen % 16;
                if (overflow > 0) {
                    encLen += 16 - overflow;
                }
                byte[] plain = new byte[encLen];
                System.arraycopy(data, 0, plain, 0, length);
                int i2 = this.mEncryptionSequenceNumber;
                plain[length] = (byte) (i2 & 255);
                plain[length + 1] = (byte) ((i2 >> 8) & 255);
                plain[length + 2] = (byte) ((i2 >> 16) & 255);
                plain[length + 3] = (byte) ((i2 >> 24) & 255);
                this.mEncryptionSequenceNumber = i2 + 1;
                CRC32 crc = new CRC32();
                crc.update(plain, 0, length + 4);
                int checksum = (int) crc.getValue();
                plain[length + 4] = (byte) (checksum & 255);
                plain[length + 5] = (byte) ((checksum >> 8) & 255);
                plain[length + 6] = (byte) ((checksum >> 16) & 255);
                plain[length + 7] = (byte) ((checksum >> 24) & 255);
                payloadData = aesEcbEncrypt(plain, messageKey);
                payloadLen = encLen;
            } else {
                payloadData = data;
                payloadLen = length;
            }
            int remaining = payloadLen;
            int headerSize = 11;
            int dataOffset = 0;
            while (remaining > 0) {
                int maxChunk = (this.mMTU - 3) - headerSize;
                if (maxChunk < 1) {
                    maxChunk = 20 - headerSize;
                }
                int copyBytes = Math.min(remaining, maxChunk);
                byte[] chunk = new byte[copyBytes + headerSize];
                byte flags = z ? (byte) (0 | 8) : (byte) 0;
                if (count == 0) {
                    flags = (byte) (flags | 1);
                }
                if (remaining <= maxChunk) {
                    flags = (byte) (flags | 6);
                }
                chunk[0] = 3;
                chunk[1] = flags;
                chunk[2] = 0;
                chunk[3] = handle;
                chunk[4] = count;
                if (count == 0) {
                    chunk[5] = (byte) (length & 255);
                    chunk[6] = (byte) ((length >> 8) & 255);
                    chunk[7] = (byte) ((length >> 16) & 255);
                    chunk[8] = (byte) ((length >> 24) & 255);
                    chunk[9] = (byte) (s & 255);
                    chunk[10] = (byte) ((s >> 8) & 255);
                }
                System.arraycopy(payloadData, dataOffset, chunk, headerSize, copyBytes);
                Log.d(TAG, "  chunk " + ((int) count) + ": " + chunk.length + "B flags=0x" + String.format("%02x", Byte.valueOf(flags)));
                SendCallback sendCallback = this.sendCallback;
                if (sendCallback != null) {
                    sendCallback.onSendChunk(chunk);
                }
                remaining -= copyBytes;
                dataOffset += copyBytes;
                headerSize = 5;
                count = (byte) (count + 1);
                s = endpoint;
                z = encrypt;
            }
            return;
        }
        Log.e(TAG, "Cannot encrypt: no session key — message will NOT be sent");
    }

    public void sendAck(byte handle, byte count) {
        byte[] ack = {3, 9, 0, handle, count};
        SendCallback sendCallback = this.sendCallback;
        if (sendCallback != null) {
            sendCallback.onSendChunk(ack);
        }
    }

    private byte[] aesEcbEncrypt(byte[] data, byte[] key) {
        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            cipher.init(1, keySpec);
            return cipher.doFinal(data);
        } catch (Exception e) {
            Log.e(TAG, "AES encrypt failed", e);
            return data;
        }
    }
}
