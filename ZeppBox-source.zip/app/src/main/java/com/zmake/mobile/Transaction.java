package com.zmake.mobile;

import android.bluetooth.BluetoothGattCallback;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class Transaction {
    private final List<BtLEAction> actions = new ArrayList(4);
    private BluetoothGattCallback gattCallback;
    private boolean modifyGattCallback;
    private final String name;

    public Transaction(String name) {
        this.name = name != null ? name : "";
    }

    public String getName() {
        return this.name;
    }

    public void addAction(BtLEAction action) {
        this.actions.add(action);
    }

    public List<BtLEAction> getActions() {
        return this.actions;
    }

    public int getActionCount() {
        return this.actions.size();
    }

    public void setCallback(BluetoothGattCallback callback) {
        this.gattCallback = callback;
        this.modifyGattCallback = true;
    }

    public BluetoothGattCallback getCallback() {
        return this.gattCallback;
    }

    public boolean isModifyGattCallback() {
        return this.modifyGattCallback;
    }

    public String toString() {
        return "Transaction[" + this.name + "](" + this.actions.size() + " actions)";
    }
}
