package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;

/* loaded from: classes3.dex */
public class SleepAction extends BtLEAction {
    private final int millis;

    public SleepAction(int millis) {
        super(null);
        this.millis = millis;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean expectsResult() {
        return false;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean run(BluetoothGatt gatt) {
        try {
            Thread.sleep(this.millis);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return true;
        }
    }

    @Override // com.zmake.mobile.BtLEAction
    public String getKind() {
        return "SLEEP(" + this.millis + "ms)";
    }
}
