package com.zmake.mobile;

import android.appwidget.AppWidgetManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.webkit.WebViewAssetLoader;
import com.zmake.mobile.BleManager;
import com.zmake.mobile.MainActivity;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/* loaded from: classes3.dex */
public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_BLE_PERMS = 200;
    private BleManager bleManager;
    private ValueCallback<Uri[]> filePathCallback;
    private NotificationHelper notificationHelper;
    private WebView webView;

    /* loaded from: classes3.dex */
    public class FileSaverInterface {
        public FileSaverInterface() {
        }

        @JavascriptInterface
        public void saveFile(String base64Data, final String filename, String mimeType) {
            OutputStream out;
            try {
                byte[] data = Base64.decode(base64Data, 0);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put("_display_name", filename);
                    values.put("mime_type", mimeType != null ? mimeType : "application/octet-stream");
                    values.put("relative_path", Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = MainActivity.this.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri != null && (out = MainActivity.this.getContentResolver().openOutputStream(uri)) != null) {
                        out.write(data);
                        out.close();
                    }
                } else {
                    File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!downloadsDir.exists()) {
                        downloadsDir.mkdirs();
                    }
                    File outputFile = new File(downloadsDir, filename);
                    FileOutputStream fos = new FileOutputStream(outputFile);
                    fos.write(data);
                    fos.close();
                }
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$FileSaverInterface$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.FileSaverInterface.this.lambda$saveFile$0(filename);
                    }
                });
            } catch (Exception e) {
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$FileSaverInterface$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.FileSaverInterface.this.lambda$saveFile$1(e);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$saveFile$0(String filename) {
            Toast.makeText(MainActivity.this, "已保存: " + filename, 1).show();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$saveFile$1(Exception e) {
            Toast.makeText(MainActivity.this, "保存失败: " + e.getMessage(), 1).show();
        }

        @JavascriptInterface
        public void openFile(final String filename, String mimeType) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    String[] projection = {"_id"};
                    String[] selectionArgs = {filename};
                    Cursor cursor = MainActivity.this.getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, "_display_name = ?", selectionArgs, "_id DESC");
                    if (cursor != null && cursor.moveToFirst()) {
                        long id = cursor.getLong(cursor.getColumnIndexOrThrow("_id"));
                        Uri contentUri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, String.valueOf(id));
                        cursor.close();
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setDataAndType(contentUri, mimeType != null ? mimeType : "*/*");
                        intent.addFlags(1);
                        Intent chooser = Intent.createChooser(intent, "选择打开方式");
                        MainActivity.this.startActivity(chooser);
                    } else {
                        if (cursor != null) {
                            cursor.close();
                        }
                        MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$FileSaverInterface$$ExternalSyntheticLambda3
                            @Override // java.lang.Runnable
                            public final void run() {
                                MainActivity.FileSaverInterface.this.lambda$openFile$2(filename);
                            }
                        });
                    }
                    return;
                }
                File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File outputFile = new File(downloadsDir, filename);
                if (outputFile.exists()) {
                    Uri uri = Uri.fromFile(outputFile);
                    Intent intent2 = new Intent("android.intent.action.VIEW");
                    intent2.setDataAndType(uri, mimeType != null ? mimeType : "*/*");
                    Intent chooser2 = Intent.createChooser(intent2, "选择打开方式");
                    MainActivity.this.startActivity(chooser2);
                    return;
                }
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$FileSaverInterface$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.FileSaverInterface.this.lambda$openFile$3(filename);
                    }
                });
            } catch (Exception e) {
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$FileSaverInterface$$ExternalSyntheticLambda5
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.FileSaverInterface.this.lambda$openFile$4(e);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$openFile$2(String filename) {
            Toast.makeText(MainActivity.this, "未找到文件: " + filename, 1).show();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$openFile$3(String filename) {
            Toast.makeText(MainActivity.this, "未找到文件: " + filename, 1).show();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$openFile$4(Exception e) {
            Toast.makeText(MainActivity.this, "打开失败: " + e.getMessage(), 1).show();
        }

        @JavascriptInterface
        public void copyText(String text) {
            try {
                ClipboardManager clipboard = (ClipboardManager) MainActivity.this.getSystemService("clipboard");
                ClipData clip = ClipData.newPlainText("code", text);
                clipboard.setPrimaryClip(clip);
            } catch (Exception e) {
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$FileSaverInterface$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity.FileSaverInterface.this.lambda$copyText$5(e);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$copyText$5(Exception e) {
            Toast.makeText(MainActivity.this, "复制失败: " + e.getMessage(), 0).show();
        }
    }

    private SharedPreferences getDevicePrefs() {
        return getSharedPreferences("zeppbox_device", 0);
    }

    @JavascriptInterface
    public void saveDevice(String mac, String authKey, String name) {
        getDevicePrefs().edit().putString("saved_mac", mac).putString("saved_authkey", authKey).putString("saved_name", name).apply();
    }

    @JavascriptInterface
    public String getSavedDevice() {
        String mac = getDevicePrefs().getString("saved_mac", "");
        String authKey = getDevicePrefs().getString("saved_authkey", "");
        String name = getDevicePrefs().getString("saved_name", "");
        return mac.isEmpty() ? "null" : "{\"mac\":\"" + escapeJs(mac) + "\",\"authKey\":\"" + escapeJs(authKey) + "\",\"name\":\"" + escapeJs(name) + "\"}";
    }

    @JavascriptInterface
    public void clearSavedDevice() {
        getDevicePrefs().edit().clear().apply();
    }

    @JavascriptInterface
    public String getQueueStatus() {
        BleManager bleManager = this.bleManager;
        return bleManager == null ? "[]" : bleManager.getQueueStatusJson();
    }

    @JavascriptInterface
    public void cancelQueueItem(final String itemId) {
        runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$cancelQueueItem$0(itemId);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$cancelQueueItem$0(String itemId) {
        BleManager bleManager = this.bleManager;
        if (bleManager != null) {
            bleManager.cancelQueueItem(itemId);
        }
    }

    @JavascriptInterface
    public void clearInstallQueue() {
        runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$clearInstallQueue$1();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$clearInstallQueue$1() {
        BleManager bleManager = this.bleManager;
        if (bleManager != null) {
            bleManager.clearQueue();
        }
    }

    /* loaded from: classes3.dex */
    public class BleBridge {
        public BleBridge() {
        }

        @JavascriptInterface
        public void scan() {
            MainActivity.this.ensurePermissions();
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$scan$0();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$scan$0() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.startScan();
            }
        }

        @JavascriptInterface
        public void scanAll() {
            MainActivity.this.ensurePermissions();
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$scanAll$1();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$scanAll$1() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.startScanAll();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$stopScan$2() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.stopScan();
            }
        }

        @JavascriptInterface
        public void stopScan() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$stopScan$2();
                }
            });
        }

        @JavascriptInterface
        public void connect(final String mac, final String authKeyHex) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$connect$3(authKeyHex, mac);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$connect$3(String authKeyHex, String mac) {
            if (MainActivity.this.bleManager == null) {
                return;
            }
            String hex = authKeyHex.trim();
            if (hex.startsWith("0x") || hex.startsWith("0X")) {
                hex = hex.substring(2);
            }
            byte[] key = MainActivity.this.parseHex(hex.replaceAll("\\s+", ""));
            if (key == null || key.length != 16) {
                MainActivity.this.jsCall("bleEvent.error('Auth key must be 16 bytes (32 hex chars)')");
            } else {
                MainActivity.this.bleManager.connect(mac, key);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$disconnect$4() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.disconnect();
            }
        }

        @JavascriptInterface
        public void disconnect() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$disconnect$4();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$requestBattery$5() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.requestBattery();
            }
        }

        @JavascriptInterface
        public void requestBattery() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$requestBattery$5();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$requestDeviceInfo$6() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.readDeviceInfo();
            }
        }

        @JavascriptInterface
        public void requestDeviceInfo() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$requestDeviceInfo$6();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$requestRssi$9() {
            if (MainActivity.this.bleManager != null) {
                MainActivity.this.bleManager.requestRssi();
            }
        }

        @JavascriptInterface
        public void requestRssi() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$requestRssi$9();
                }
            });
        }

        @JavascriptInterface
        public void selectAppFile() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$selectAppFile$7();
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$selectAppFile$7() {
            Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
            intent.addCategory("android.intent.category.OPENABLE");
            intent.setType("*/*");
            String[] mimeTypes = {"application/octet-stream", "application/zip", "application/*"};
            intent.putExtra("android.intent.extra.MIME_TYPES", mimeTypes);
            try {
                MainActivity.this.startActivityForResult(intent, MainActivity.REQUEST_BLE_PERMS);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "无法打开文件选择器", 0).show();
            }
        }

        @JavascriptInterface
        public void uninstallApp(final int appId) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$BleBridge$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.BleBridge.this.lambda$uninstallApp$8(appId);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$uninstallApp$8(int appId) {
            if (MainActivity.this.bleManager != null && MainActivity.this.bleManager.isConnected()) {
                MainActivity.this.bleManager.uninstallApp(appId);
            } else {
                MainActivity.this.jsCall("bleEvent && bleEvent.log('设备未连接，无法卸载应用')");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public byte[] parseHex(String hex) {
        if (hex.length() % 2 != 0) {
            return null;
        }
        byte[] result = new byte[hex.length() / 2];
        for (int i = 0; i < result.length; i++) {
            try {
                result[i] = (byte) Integer.parseInt(hex.substring(i * 2, (i * 2) + 2), 16);
            } catch (Exception e) {
                return null;
            }
        }
        return result;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void jsCall(final String js) {
        runOnUiThread(new Runnable() { // from class: com.zmake.mobile.MainActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$jsCall$2(js);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$jsCall$2(String js) {
        WebView webView = this.webView;
        if (webView != null) {
            webView.evaluateJavascript(js, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            String[] perms = {"android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT", "android.permission.POST_NOTIFICATIONS"};
            boolean need = false;
            int length = perms.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    break;
                }
                String p = perms[i];
                if (ActivityCompat.checkSelfPermission(this, p) == 0) {
                    i++;
                } else {
                    need = true;
                    break;
                }
            }
            if (need) {
                ActivityCompat.requestPermissions(this, perms, REQUEST_BLE_PERMS);
                return;
            }
            return;
        }
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, REQUEST_BLE_PERMS);
        }
    }

    private void initBle() {
        BleManager bleManager = new BleManager(this);
        this.bleManager = bleManager;
        bleManager.setCallback(new BleManager.Callback() { // from class: com.zmake.mobile.MainActivity.1
            @Override // com.zmake.mobile.BleManager.Callback
            public void onRssiRead(int rssi) {
                MainActivity.this.jsCall("bleEvent && bleEvent.rssiRead(" + rssi + ")");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onScanResult(String name, String mac, int rssi) {
                MainActivity.this.jsCall("bleEvent && bleEvent.scanResult('" + MainActivity.this.escapeJs(name) + "','" + mac + "'," + rssi + ")");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onConnected() {
                MainActivity.this.jsCall("bleEvent && bleEvent.connected()");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onDisconnected() {
                MainActivity.this.jsCall("bleEvent && bleEvent.disconnected()");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onServicesReady() {
                MainActivity.this.bleManager.startAuthentication();
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onAuthSuccess() {
                MainActivity.this.jsCall("bleEvent && bleEvent.authSuccess()");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onAuthFail(String reason) {
                MainActivity.this.jsCall("bleEvent && bleEvent.authFail('" + MainActivity.this.escapeJs(reason) + "')");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onNotification(byte[] data) {
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onDisRead(String fw, String sn, String model, String mfr) {
                MainActivity.this.jsCall("bleEvent && bleEvent.deviceInfo('" + MainActivity.this.escapeJs(fw) + "','" + MainActivity.this.escapeJs(sn) + "','" + MainActivity.this.escapeJs(model) + "','" + MainActivity.this.escapeJs(mfr) + "')");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onBattery(int level, boolean charging) {
                MainActivity.this.jsCall("bleEvent && bleEvent.batteryInfo(" + level + ", " + charging + ")");
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onLog(String msg) {
                if (msg == null) {
                    return;
                }
                if (msg.startsWith("queueItemAdded:")) {
                    String rest = msg.substring("queueItemAdded:".length());
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueItemAdded('" + MainActivity.this.escapeJs(rest) + "')");
                    return;
                }
                if (msg.startsWith("queueItemCompleted:")) {
                    String rest2 = msg.substring("queueItemCompleted:".length());
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueItemCompleted('" + MainActivity.this.escapeJs(rest2) + "')");
                    return;
                }
                if (msg.startsWith("queueItemFailed:")) {
                    String rest3 = msg.substring("queueItemFailed:".length());
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueItemFailed('" + MainActivity.this.escapeJs(rest3) + "')");
                    return;
                }
                if (msg.startsWith("queueProgress:")) {
                    String rest4 = msg.substring("queueProgress:".length());
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueProgress('" + MainActivity.this.escapeJs(rest4) + "')");
                    return;
                }
                if (msg.startsWith("queueChanged:")) {
                    String rest5 = msg.substring("queueChanged:".length());
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueChanged(" + rest5 + ")");
                } else if (msg.startsWith("queueItemRemoved:")) {
                    String rest6 = msg.substring("queueItemRemoved:".length());
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueItemRemoved('" + MainActivity.this.escapeJs(rest6) + "')");
                } else if (msg.startsWith("queueCleared")) {
                    MainActivity.this.jsCall("bleEvent && bleEvent.queueCleared()");
                } else {
                    MainActivity.this.jsCall("bleEvent && bleEvent.log('" + MainActivity.this.escapeJs(msg) + "')");
                }
            }

            @Override // com.zmake.mobile.BleManager.Callback
            public void onError(String error) {
                MainActivity.this.jsCall("bleEvent && bleEvent.error('" + MainActivity.this.escapeJs(error) + "')");
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String escapeJs(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView.setWebContentsDebuggingEnabled(true);
        WebView webView = new WebView(this);
        this.webView = webView;
        setContentView(webView);
        WebSettings settings = this.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(2);
        settings.setMixedContentMode(0);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        this.webView.addJavascriptInterface(new FileSaverInterface(), "AndroidFileSaver");
        this.webView.addJavascriptInterface(new BleBridge(), "BleBridge");
        this.webView.addJavascriptInterface(this, "AndroidBridge");
        initBle();
        this.notificationHelper = new NotificationHelper(this);
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        this.webView.setWebViewClient(new WebViewClient() { // from class: com.zmake.mobile.MainActivity.2
            @Override // android.webkit.WebViewClient
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        this.webView.setWebChromeClient(new WebChromeClient() { // from class: com.zmake.mobile.MainActivity.3
            @Override // android.webkit.WebChromeClient
            public boolean onShowFileChooser(WebView webView2, ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams params) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = callback;
                Intent intent = params.createIntent();
                intent.addCategory("android.intent.category.OPENABLE");
                intent.setType("*/*");
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
                try {
                    MainActivity.this.startActivityForResult(intent, 100);
                    return true;
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
            }
        });
        this.webView.loadUrl("https://appassets.androidplatform.net/index.html");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100) {
            if (this.filePathCallback == null) {
                return;
            }
            Uri[] results = null;
            if (resultCode == -1 && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getDataString() != null) {
                    results = new Uri[]{Uri.parse(data.getDataString())};
                }
            }
            this.filePathCallback.onReceiveValue(results);
            this.filePathCallback = null;
            return;
        }
        if (requestCode == REQUEST_BLE_PERMS) {
            if (resultCode == -1 && data != null && data.getData() != null) {
                Uri uri = data.getData();
                handleAppFileSelected(uri);
            } else {
                jsCall("bleEvent && bleEvent.queueItemFailed('no_file:未选择文件')");
            }
        }
    }

    private void handleAppFileSelected(final Uri uri) {
        new Thread(new Runnable() { // from class: com.zmake.mobile.MainActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$handleAppFileSelected$3(uri);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$handleAppFileSelected$3(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) {
                jsCall("bleEvent && bleEvent.queueItemFailed('no_read:无法读取文件')");
                return;
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            while (true) {
                int len = is.read(buffer);
                if (len == -1) {
                    break;
                } else {
                    baos.write(buffer, 0, len);
                }
            }
            is.close();
            byte[] fileData = baos.toByteArray();
            AppInfo appInfo = AppUtils.parseBinFile(fileData);
            if (appInfo == null) {
                jsCall("bleEvent && bleEvent.queueItemFailed('no_parse:无效的应用文件')");
                return;
            }
            BleManager bleManager = this.bleManager;
            if (bleManager != null && bleManager.isConnected()) {
                this.bleManager.addToQueue(fileData, appInfo);
            } else {
                jsCall("bleEvent && bleEvent.queueItemFailed('no_conn:设备未连接')");
            }
        } catch (Exception e) {
            jsCall("bleEvent && bleEvent.queueItemFailed('err:" + escapeJs(e.getMessage()) + "')");
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.webView.canGoBack()) {
            this.webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        BleManager bleManager = this.bleManager;
        if (bleManager != null) {
            bleManager.stopScan();
            this.bleManager.close();
        }
        this.webView.destroy();
        NotificationHelper notificationHelper = this.notificationHelper;
        if (notificationHelper != null) {
            notificationHelper.cancelNotification();
        }
        super.onDestroy();
    }

    @JavascriptInterface
    public void showNotification(String title, String text) {
        NotificationHelper notificationHelper = this.notificationHelper;
        if (notificationHelper != null) {
            notificationHelper.showNotification(title, text);
        }
    }

    @JavascriptInterface
    public void cancelNotification() {
        NotificationHelper notificationHelper = this.notificationHelper;
        if (notificationHelper != null) {
            notificationHelper.cancelNotification();
        }
    }

    @JavascriptInterface
    public void updateWidget(String deviceName, String status, String battery) {
        getSharedPreferences("zeppbox_widget", 0).edit().putString("device_name", deviceName).putString(NotificationCompat.CATEGORY_STATUS, status).putString("battery", battery).apply();
        WidgetProvider.triggerUpdate(this);
    }

    @JavascriptInterface
    public void requestPinWidget() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        AppWidgetManager mgr = AppWidgetManager.getInstance(this);
        ComponentName provider = new ComponentName(this, (Class<?>) WidgetProvider.class);
        if (mgr.isRequestPinAppWidgetSupported()) {
            mgr.requestPinAppWidget(provider, null, null);
        }
    }
}
