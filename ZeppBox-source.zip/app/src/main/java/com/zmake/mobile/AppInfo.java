package com.zmake.mobile;

/* loaded from: classes3.dex */
public class AppInfo {
    public int appId = -1;
    public String appName = "";
    public String appType = "";
    public String vender = "";
    public String description = "";
    public String version = "1.0";

    public String toString() {
        return "AppInfo{appId=" + this.appId + ", appName='" + this.appName + "', appType='" + this.appType + "', vender='" + this.vender + "', version='" + this.version + "'}";
    }

    public String toJson() {
        return "{\"appId\":" + this.appId + ",\"appName\":\"" + escapeJson(this.appName) + "\",\"appType\":\"" + escapeJson(this.appType) + "\",\"vender\":\"" + escapeJson(this.vender) + "\",\"version\":\"" + escapeJson(this.version) + "\",\"description\":\"" + escapeJson(this.description) + "\"}";
    }

    private String escapeJson(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
