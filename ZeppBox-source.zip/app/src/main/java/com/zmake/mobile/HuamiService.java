package com.zmake.mobile;

import java.util.UUID;

/* loaded from: classes3.dex */
public class HuamiService {
    public static final byte AUTH_FAIL = 37;
    public static final byte CHUNKED_2021_TYPE = 3;
    public static final byte CMD_BATTERY_REPLY = 4;
    public static final byte CMD_BATTERY_REQUEST = 3;
    public static final byte CMD_PUB_KEY = 4;
    public static final byte CMD_SESSION_KEY = 5;
    public static final short ENDPOINT_AUTH = 130;
    public static final short ENDPOINT_BATTERY = 41;
    public static final short ENDPOINT_DEVICE_INFO = 10;
    public static final byte FLAG_ACK = 9;
    public static final byte FLAG_ENCRYPTED = 8;
    public static final byte FLAG_FIRST = 1;
    public static final byte FLAG_LAST = 2;
    public static final byte FLAG_NEED_ACK = 4;
    public static final byte RESPONSE = 16;
    public static final byte SUCCESS = 1;
    public static final UUID UUID_SERVICE_FEE0 = UUID.fromString("0000fee0-0000-3512-2118-0009af100700");
    public static final UUID UUID_SERVICE_FEE1 = UUID.fromString("0000fee1-0000-3512-2118-0009af100700");
    public static final UUID UUID_SERVICE_FEE7 = UUID.fromString("0000fee7-0000-3512-2118-0009af100700");
    public static final UUID UUID_CHARACTERISTIC_CHUNKEDTRANSFER_2021_WRITE = UUID.fromString("00000016-0000-3512-2118-0009af100700");
    public static final UUID UUID_CHARACTERISTIC_CHUNKEDTRANSFER_2021_READ = UUID.fromString("00000017-0000-3512-2118-0009af100700");
    public static final UUID UUID_CHARACTERISTIC_AUTH = UUID.fromString("00000009-0000-3512-2118-0009af100700");
    public static final UUID UUID_SERVICE_DIS = UUID.fromString("0000180a-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_DIS_FIRMWARE = UUID.fromString("00002a28-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_DIS_FIRMWARE_ALT = UUID.fromString("00002a26-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_DIS_SERIAL = UUID.fromString("00002a25-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_DIS_MODEL = UUID.fromString("00002a27-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_DIS_MODEL_ALT = UUID.fromString("00002a24-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_DIS_MANUFACTURER = UUID.fromString("00002a29-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
}
