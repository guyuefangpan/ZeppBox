package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.os.Build;
import android.util.Log;

/* loaded from: classes3.dex */
public class WriteAction extends BtLEAction {
    private static final String TAG = "WriteAction";
    private final WriteCallback callback;
    private final byte[] value;

    /* loaded from: classes3.dex */
    public interface WriteCallback {
        void onWriteResult(int i, byte[] bArr);
    }

    public WriteAction(BluetoothGattCharacteristic characteristic, byte[] value) {
        this(characteristic, value, null);
    }

    public WriteAction(BluetoothGattCharacteristic characteristic, byte[] value, WriteCallback callback) {
        super(characteristic);
        this.value = value;
        this.callback = callback;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean expectsResult() {
        return true;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean run(BluetoothGatt gatt) {
        return writeCharacteristic(gatt, getCharacteristic(), this.value);
    }

    private static boolean writeCharacteristic(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, byte[] value) {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                int status = gatt.writeCharacteristic(characteristic, value, characteristic.getWriteType());
                if (status == 0) {
                    return true;
                }
                Log.e(TAG, "writeCharacteristic failed: status=" + status);
                return false;
            } catch (Exception e) {
                Log.e(TAG, "writeCharacteristic exception", e);
                return false;
            }
        }
        if (characteristic.setValue(value)) {
            return gatt.writeCharacteristic(characteristic);
        }
        Log.e(TAG, "setValue failed");
        return false;
    }

    @Override // com.zmake.mobile.BtLEAction
    public void onGattCallback(int status, byte[] value) {
        WriteCallback writeCallback = this.callback;
        if (writeCallback != null) {
            writeCallback.onWriteResult(status, value);
        }
    }

    @Override // com.zmake.mobile.BtLEAction
    public String getKind() {
        return "WRITE";
    }
}
