package com.zmake.mobile;

import android.util.Log;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import kotlin.UByte;

/* loaded from: classes3.dex */
public class ZeppOsAuthService {
    private static final String TAG = "ZeppOsAuth";
    private byte[] authKey;
    private final Callback callback;
    private final byte[] privateEC = new byte[24];
    private final byte[] publicEC = new byte[48];
    private byte[] remotePublicEC;
    private byte[] remoteRandom;

    /* loaded from: classes3.dex */
    public interface Callback {
        void onAuthFail(String str);

        void onAuthSuccess();

        void onEncryptionParametersSet(int i, byte[] bArr);

        void onLog(String str);

        void onSendData(short s, byte[] bArr, boolean z);
    }

    public ZeppOsAuthService(Callback callback) {
        this.callback = callback;
    }

    public void setAuthKey(byte[] key) {
        this.authKey = key;
    }

    public void startAuthentication() {
        byte[] bArr = this.authKey;
        if (bArr == null || bArr.length != 16) {
            Callback callback = this.callback;
            if (callback != null) {
                StringBuilder append = new StringBuilder().append("Auth key must be 16 bytes, got: ");
                byte[] bArr2 = this.authKey;
                callback.onAuthFail(append.append(bArr2 == null ? "null" : Integer.valueOf(bArr2.length)).toString());
                return;
            }
            return;
        }
        this.callback.onLog("=== Starting Zepp OS ECDH authentication ===");
        this.callback.onLog("Auth key (hex): " + bytesToHex(this.authKey));
        this.callback.onLog("Generating ECDH key pair (sect163k1)...");
        SecureRandom random = new SecureRandom();
        boolean generated = false;
        int attempt = 0;
        while (true) {
            if (attempt >= 10) {
                break;
            }
            random.nextBytes(this.privateEC);
            if (!ECDH_B163.ecdh_generate_keys(this.publicEC, this.privateEC)) {
                attempt++;
            } else {
                generated = true;
                break;
            }
        }
        if (!generated) {
            this.callback.onAuthFail("Failed to generate ECDH key pair");
            return;
        }
        if (!ECDH_B163.verifyPublicKey(this.publicEC)) {
            this.callback.onLog("WARNING: Our public key failed on-curve verification!");
        } else {
            this.callback.onLog("Our public key verified on curve (OK)");
        }
        this.callback.onLog("ECDH public key: " + bytesToHex(this.publicEC));
        byte[] command = new byte[52];
        command[0] = 4;
        command[1] = 2;
        command[2] = 0;
        command[3] = 2;
        System.arraycopy(this.publicEC, 0, command, 4, 48);
        this.callback.onLog("Sending public key to device (endpoint 0x0082)...");
        this.callback.onSendData(HuamiService.ENDPOINT_AUTH, command, false);
    }

    public void handlePayload(byte[] payload) {
        if (payload == null || payload.length < 3) {
            this.callback.onLog("Auth response too short: " + (payload != null ? payload.length : 0));
            return;
        }
        this.callback.onLog("Auth response: " + payload.length + " bytes, first bytes: " + bytesToHex(payload).substring(0, Math.min(20, payload.length * 2)));
        if (payload[0] != 16) {
            this.callback.onLog("Not a response (expected 0x10, got 0x" + String.format("%02x", Byte.valueOf(payload[0])) + ")");
            return;
        }
        if (payload[1] == 4 && payload[2] == 1) {
            handlePubKeyResponse(payload);
        } else if (payload[1] == 5) {
            handleSessionKeyResponse(payload);
        } else {
            this.callback.onLog("Unknown auth response: cmd=0x" + String.format("%02x", Byte.valueOf(payload[1])) + " status=0x" + String.format("%02x", Byte.valueOf(payload[2])));
        }
    }

    private void handlePubKeyResponse(byte[] payload) {
        if (payload.length < 67) {
            this.callback.onLog("PubKey response too short: " + payload.length);
            this.callback.onAuthFail("Invalid public key response");
            return;
        }
        this.callback.onLog("Received device public key, computing shared secret...");
        byte[] bArr = new byte[16];
        this.remoteRandom = bArr;
        this.remotePublicEC = new byte[48];
        System.arraycopy(payload, 3, bArr, 0, 16);
        System.arraycopy(payload, 19, this.remotePublicEC, 0, 48);
        this.callback.onLog("Remote random: " + bytesToHex(this.remoteRandom));
        this.callback.onLog("Remote public key: " + bytesToHex(this.remotePublicEC));
        this.callback.onLog("Our private key: " + bytesToHex(this.privateEC));
        this.callback.onLog("Our public key: " + bytesToHex(this.publicEC));
        byte[] sharedEC = new byte[48];
        boolean ecdhOk = ECDH_B163.ecdh_shared_secret(this.privateEC, this.remotePublicEC, sharedEC);
        if (ecdhOk) {
            this.callback.onLog("Shared secret (48B): " + bytesToHex(sharedEC));
            boolean allZero = true;
            int length = sharedEC.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    break;
                }
                byte b = sharedEC[i];
                if (b != 0) {
                    allZero = false;
                    break;
                }
                i++;
            }
            if (!allZero) {
                int encryptedSeqNr = (sharedEC[0] & UByte.MAX_VALUE) | ((sharedEC[1] & UByte.MAX_VALUE) << 8) | ((sharedEC[2] & UByte.MAX_VALUE) << 16) | ((sharedEC[3] & UByte.MAX_VALUE) << 24);
                byte[] sessionKey = new byte[16];
                for (int i2 = 0; i2 < 16; i2++) {
                    sessionKey[i2] = (byte) (this.authKey[i2] ^ sharedEC[i2 + 8]);
                }
                this.callback.onLog("Encrypted seqNr=" + encryptedSeqNr);
                this.callback.onLog("Auth key: " + bytesToHex(this.authKey));
                this.callback.onLog("Session key: " + bytesToHex(sessionKey));
                this.callback.onLog("SharedEC[0:4]: " + bytesToHex(new byte[]{sharedEC[0], sharedEC[1], sharedEC[2], sharedEC[3]}));
                this.callback.onLog("SharedEC[8:24]: " + bytesToHex(new byte[]{sharedEC[8], sharedEC[9], sharedEC[10], sharedEC[11], sharedEC[12], sharedEC[13], sharedEC[14], sharedEC[15], sharedEC[16], sharedEC[17], sharedEC[18], sharedEC[19], sharedEC[20], sharedEC[21], sharedEC[22], sharedEC[23]}));
                this.callback.onEncryptionParametersSet(encryptedSeqNr, sessionKey);
                this.callback.onLog("Sending session key (double encrypted random)...");
                byte[] enc1 = aesEcbEncrypt(this.remoteRandom, this.authKey);
                byte[] enc2 = aesEcbEncrypt(this.remoteRandom, sessionKey);
                this.callback.onLog("enc1 (AES authKey): " + bytesToHex(enc1));
                this.callback.onLog("enc2 (AES sessionKey): " + bytesToHex(enc2));
                this.callback.onLog("enc1 == enc2? " + Arrays.equals(enc1, enc2));
                byte[] command = new byte[33];
                command[0] = 5;
                System.arraycopy(enc1, 0, command, 1, 16);
                System.arraycopy(enc2, 0, command, 17, 16);
                this.callback.onSendData(HuamiService.ENDPOINT_AUTH, command, false);
                return;
            }
            this.callback.onLog("ERROR: Shared secret is all zeros!");
            this.callback.onAuthFail("ECDH produced zero shared secret");
            return;
        }
        this.callback.onLog("ERROR: ECDH shared secret failed (point not on curve or zero)");
        this.callback.onLog("Shared secret (all zeros?): " + bytesToHex(sharedEC));
        this.callback.onAuthFail("ECDH computation failed - remote key not on curve");
    }

    private void handleSessionKeyResponse(byte[] payload) {
        if (payload[2] == 1) {
            this.callback.onLog("=== Authentication successful! ===");
            this.callback.onAuthSuccess();
        } else if (payload[2] != 37) {
            this.callback.onLog("Authentication failed: 0x" + String.format("%02x", Byte.valueOf(payload[2])));
            this.callback.onAuthFail("Auth failed (0x" + String.format("%02x", Byte.valueOf(payload[2])) + ")");
        } else {
            this.callback.onLog("Authentication failed: wrong auth key");
            this.callback.onAuthFail("Auth key incorrect (0x25)");
        }
    }

    private byte[] aesEcbEncrypt(byte[] data, byte[] key) {
        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            cipher.init(1, keySpec);
            return cipher.doFinal(data);
        } catch (Exception e) {
            Log.e(TAG, "AES encrypt failed", e);
            return data;
        }
    }

    private String bytesToHex(byte[] bytes) {
        if (bytes == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", Integer.valueOf(b & UByte.MAX_VALUE)));
        }
        return sb.toString();
    }
}
