package com.zmake.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/* loaded from: classes3.dex */
public class NotificationHelper {
    private static final String CHANNEL_ID = "ble_status";
    private static final int NOTIFICATION_ID = 1001;
    private Context context;
    private NotificationManager manager;

    public NotificationHelper(Context context) {
        this.context = context;
        this.manager = (NotificationManager) context.getSystemService("notification");
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "蓝牙连接状态", 2);
            channel.setDescription("显示蓝牙设备连接状态");
            this.manager.createNotificationChannel(channel);
        }
    }

    public void showNotification(String title, String text) {
        Intent intent = new Intent(this.context, (Class<?>) MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this.context, 0, intent, 201326592);
        Notification.Builder b = new Notification.Builder(this.context, CHANNEL_ID);
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(text).setContentIntent(pi).setOngoing(true).setPriority(-1);
        this.manager.notify(1001, b.build());
    }

    public void cancelNotification() {
        this.manager.cancel(1001);
    }
}
