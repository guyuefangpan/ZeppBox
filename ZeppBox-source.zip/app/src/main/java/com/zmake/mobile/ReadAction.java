package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;

/* loaded from: classes3.dex */
public class ReadAction extends BtLEAction {
    private static final String TAG = "ReadAction";
    private final ReadCallback callback;

    /* loaded from: classes3.dex */
    public interface ReadCallback {
        void onReadResult(int i, byte[] bArr);
    }

    public ReadAction(BluetoothGattCharacteristic characteristic) {
        this(characteristic, null);
    }

    public ReadAction(BluetoothGattCharacteristic characteristic, ReadCallback callback) {
        super(characteristic);
        this.callback = callback;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean expectsResult() {
        return true;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean run(BluetoothGatt gatt) {
        return gatt.readCharacteristic(getCharacteristic());
    }

    @Override // com.zmake.mobile.BtLEAction
    public void onGattCallback(int status, byte[] value) {
        ReadCallback readCallback = this.callback;
        if (readCallback != null) {
            readCallback.onReadResult(status, value);
        }
    }

    @Override // com.zmake.mobile.BtLEAction
    public String getKind() {
        return "READ";
    }
}
