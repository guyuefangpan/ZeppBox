package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;

/* loaded from: classes3.dex */
public class RequestMtuAction extends BtLEAction {
    private final int mtu;

    public RequestMtuAction(int mtu) {
        super(null);
        this.mtu = mtu;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean expectsResult() {
        return true;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean run(BluetoothGatt gatt) {
        return gatt.requestMtu(this.mtu);
    }

    @Override // com.zmake.mobile.BtLEAction
    public String getKind() {
        return "REQUEST_MTU(" + this.mtu + ")";
    }
}
