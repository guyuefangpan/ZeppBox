package com.zmake.mobile;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import com.zmake.mobile.BtLEQueue;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes3.dex */
public class BtLEQueue {
    private static final long GATT_TIMEOUT_SECONDS = 10;
    private static final String TAG = "BtLEQueue";
    private final BluetoothAdapter btAdapter;
    private final BluetoothManager btManager;
    private Callback callback;
    private final Context context;
    private BluetoothGatt gatt;
    private volatile CountDownLatch mConnectionLatch;
    private volatile BtLEAction mCurrentAction;
    private volatile Transaction mCurrentTransaction;
    private Thread mDispatchThread;
    private final Handler mReceiverHandler;
    private final HandlerThread mReceiverThread;
    private volatile BluetoothGattCallback mTransactionGattCallback;
    private volatile CountDownLatch mWaitForActionResultLatch;
    private ScanResultCallback scanResultCallback;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean connected = false;
    private volatile int currentMtu = 23;
    private final LinkedBlockingDeque<Transaction> mTransactions = new LinkedBlockingDeque<>();
    private final AtomicBoolean mDisposed = new AtomicBoolean(false);
    private volatile int mLastCallbackStatus = -1;
    private volatile byte[] mLastCallbackValue = null;
    private volatile boolean mAbortTransaction = false;
    private boolean mtuProcessed = false;
    private volatile boolean scanning = false;
    private final BluetoothGattCallback internalGattCallback = new C03391();
    private final ScanCallback scanCallback = new C03402();

    /* loaded from: classes3.dex */
    public interface Callback {
        void onConnected();

        void onDisconnected();

        void onError(String str);

        void onLog(String str);

        void onMtuChanged(int i);

        void onNotification(BluetoothGattCharacteristic bluetoothGattCharacteristic, byte[] bArr);

        void onRssiRead(int i);

        void onServicesDiscovered(List<BluetoothGattService> list);
    }

    /* loaded from: classes3.dex */
    public interface ScanResultCallback {
        void onScanResult(String str, String str2, int i);
    }

    public BtLEQueue(Context ctx) {
        this.context = ctx;
        BluetoothManager bluetoothManager = (BluetoothManager) ctx.getSystemService("bluetooth");
        this.btManager = bluetoothManager;
        this.btAdapter = bluetoothManager != null ? bluetoothManager.getAdapter() : null;
        HandlerThread handlerThread = new HandlerThread("BtLEQueue_Callback");
        this.mReceiverThread = handlerThread;
        handlerThread.start();
        this.mReceiverHandler = new Handler(handlerThread.getLooper());
        startDispatchThread();
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    private void startDispatchThread() {
        Thread thread = new Thread(new DispatchRunnable(), "BtLEQueue_Dispatch");
        this.mDispatchThread = thread;
        thread.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes3.dex */
    public class DispatchRunnable implements Runnable {
        private DispatchRunnable() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Log.d(BtLEQueue.TAG, "Dispatch thread started");
            while (!BtLEQueue.this.mDisposed.get()) {
                try {
                    try {
                        Transaction transaction = (Transaction) BtLEQueue.this.mTransactions.takeFirst();
                        if (transaction != null) {
                            if (BtLEQueue.this.gatt != null && BtLEQueue.this.connected) {
                                Log.d(BtLEQueue.TAG, "Processing transaction: " + transaction);
                                BtLEQueue.this.mCurrentTransaction = transaction;
                                if (transaction.isModifyGattCallback()) {
                                    BtLEQueue.this.mTransactionGattCallback = transaction.getCallback();
                                    BtLEQueue.this.log("Transaction callback set for: " + transaction.getName());
                                }
                                BtLEQueue.this.mAbortTransaction = false;
                                Iterator<BtLEAction> it = transaction.getActions().iterator();
                                while (true) {
                                    if (!it.hasNext()) {
                                        break;
                                    }
                                    BtLEAction action = it.next();
                                    if (BtLEQueue.this.mAbortTransaction) {
                                        BtLEQueue.this.log("Transaction aborted, skipping: " + action);
                                        break;
                                    }
                                    if (BtLEQueue.this.mDisposed.get()) {
                                        break;
                                    }
                                    BtLEQueue.this.mCurrentAction = action;
                                    Log.d(BtLEQueue.TAG, "Executing action: " + action);
                                    if (action.expectsResult()) {
                                        BtLEQueue.this.mWaitForActionResultLatch = new CountDownLatch(1);
                                        BtLEQueue.this.mLastCallbackStatus = -1;
                                        BtLEQueue.this.mLastCallbackValue = null;
                                    }
                                    boolean success = false;
                                    try {
                                        success = action.run(BtLEQueue.this.gatt);
                                    } catch (Exception e) {
                                        Log.e(BtLEQueue.TAG, "Action execution error", e);
                                    }
                                    if (!success) {
                                        BtLEQueue.this.log("Action failed: " + action);
                                        BtLEQueue.this.mAbortTransaction = true;
                                        break;
                                    }
                                    if (action.expectsResult() && BtLEQueue.this.mWaitForActionResultLatch != null) {
                                        try {
                                            boolean received = BtLEQueue.this.mWaitForActionResultLatch.await(BtLEQueue.GATT_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                                            if (!received) {
                                                BtLEQueue.this.log("GATT callback timeout for: " + action);
                                                BtLEQueue.this.mAbortTransaction = true;
                                            } else if (BtLEQueue.this.mLastCallbackStatus != 0) {
                                                BtLEQueue.this.log("GATT callback error: status=" + BtLEQueue.this.mLastCallbackStatus + " for: " + action);
                                                BtLEQueue.this.mAbortTransaction = true;
                                            } else {
                                                Log.d(BtLEQueue.TAG, "Action completed OK: " + action);
                                                action.onGattCallback(BtLEQueue.this.mLastCallbackStatus, BtLEQueue.this.mLastCallbackValue);
                                            }
                                        } catch (InterruptedException e2) {
                                            Log.d(BtLEQueue.TAG, "Action wait interrupted");
                                            BtLEQueue.this.mAbortTransaction = true;
                                        }
                                        BtLEQueue.this.mWaitForActionResultLatch = null;
                                    }
                                }
                                if (transaction.isModifyGattCallback()) {
                                    BtLEQueue.this.mTransactionGattCallback = null;
                                }
                                BtLEQueue.this.mCurrentTransaction = null;
                                BtLEQueue.this.mCurrentAction = null;
                                Log.d(BtLEQueue.TAG, "Transaction completed: " + transaction.getName());
                            }
                            Log.w(BtLEQueue.TAG, "Not connected, skipping transaction: " + transaction.getName());
                        }
                    } catch (Exception e3) {
                        Log.e(BtLEQueue.TAG, "Dispatch thread error", e3);
                        BtLEQueue.this.log("Dispatch error: " + e3.getMessage());
                    }
                } catch (InterruptedException e4) {
                    Log.d(BtLEQueue.TAG, "Dispatch thread interrupted");
                }
            }
            Log.d(BtLEQueue.TAG, "Dispatch thread finished");
        }
    }

    public TransactionBuilder createTransaction(String taskName) {
        return new TransactionBuilder(taskName, this.mTransactions);
    }

    public void write(BluetoothGattCharacteristic characteristic, byte[] data) {
        TransactionBuilder builder = createTransaction("write");
        builder.write(characteristic, data);
        builder.queue();
    }

    public void connect(String mac) {
        BluetoothAdapter bluetoothAdapter = this.btAdapter;
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Callback callback = this.callback;
            if (callback != null) {
                callback.onError("Bluetooth not enabled");
                return;
            }
            return;
        }
        BluetoothGatt bluetoothGatt = this.gatt;
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
            this.gatt.close();
            this.gatt = null;
        }
        this.connected = false;
        this.mtuProcessed = false;
        BluetoothDevice device = this.btAdapter.getRemoteDevice(mac);
        if (device == null) {
            Callback callback2 = this.callback;
            if (callback2 != null) {
                callback2.onError("Device not found: " + mac);
                return;
            }
            return;
        }
        log("Connecting to " + mac + "...");
        if (Build.VERSION.SDK_INT < 26) {
            this.gatt = device.connectGatt(this.context, false, this.internalGattCallback, 2);
        } else {
            this.gatt = device.connectGatt(this.context, false, this.internalGattCallback, 2, 0, this.mReceiverHandler);
        }
    }

    public void disconnect() {
        BluetoothGatt bluetoothGatt = this.gatt;
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
        }
    }

    public void close() {
        this.mDisposed.set(true);
        BluetoothGatt bluetoothGatt = this.gatt;
        if (bluetoothGatt != null) {
            bluetoothGatt.close();
            this.gatt = null;
        }
        this.connected = false;
        this.mTransactions.clear();
        Thread thread = this.mDispatchThread;
        if (thread != null) {
            thread.interrupt();
        }
        HandlerThread handlerThread = this.mReceiverThread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.zmake.mobile.BtLEQueue$1 */
    /* loaded from: classes3.dex */
    public class C03391 extends BluetoothGattCallback {
        @Override // android.bluetooth.BluetoothGattCallback
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            if (status == 0 && BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onRssiRead(rssi);
            }
        }

        C03391() {
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onConnectionStateChange(BluetoothGatt g, final int status, int newState) {
            if (status != 0) {
                Log.e(BtLEQueue.TAG, "GATT connection error: status=" + status);
                BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        BtLEQueue.C03391.this.lambda$onConnectionStateChange$0(status);
                    }
                });
                g.close();
                BtLEQueue.this.connected = false;
                return;
            }
            if (newState == 2) {
                BtLEQueue.this.connected = true;
                BtLEQueue.this.log("GATT connected, requesting MTU 247...");
                BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda3
                    @Override // java.lang.Runnable
                    public final void run() {
                        BtLEQueue.C03391.this.lambda$onConnectionStateChange$1();
                    }
                });
                g.requestMtu(247);
                return;
            }
            if (newState == 0) {
                BtLEQueue.this.connected = false;
                BtLEQueue.this.log("GATT disconnected");
                BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        BtLEQueue.C03391.this.lambda$onConnectionStateChange$2();
                    }
                });
                g.close();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onConnectionStateChange$0(int status) {
            if (BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onError("Connection error: " + status);
                BtLEQueue.this.callback.onDisconnected();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onConnectionStateChange$1() {
            if (BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onConnected();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onConnectionStateChange$2() {
            if (BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onDisconnected();
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onMtuChanged(BluetoothGatt g, final int mtu, int status) {
            BtLEQueue.this.currentMtu = mtu;
            BtLEQueue.this.log("MTU changed: " + mtu + " (status=" + status + ")");
            BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    BtLEQueue.C03391.this.lambda$onMtuChanged$3(mtu);
                }
            });
            BtLEQueue.this.mLastCallbackStatus = status;
            CountDownLatch latch = BtLEQueue.this.mWaitForActionResultLatch;
            if (latch != null) {
                latch.countDown();
            }
            if (BtLEQueue.this.mtuProcessed) {
                BtLEQueue.this.log("MTU already processed, skipping duplicate service discovery");
            } else {
                BtLEQueue.this.mtuProcessed = true;
                BtLEQueue.this.mainHandler.postDelayed(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda6
                    @Override // java.lang.Runnable
                    public final void run() {
                        BtLEQueue.C03391.this.lambda$onMtuChanged$4();
                    }
                }, 200L);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onMtuChanged$3(int mtu) {
            if (BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onMtuChanged(mtu);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onMtuChanged$4() {
            if (BtLEQueue.this.gatt != null && BtLEQueue.this.connected) {
                BtLEQueue.this.log("Discovering services...");
                BtLEQueue.this.gatt.discoverServices();
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != 0) {
                BtLEQueue.this.log("Service discovery failed: status=" + status);
                if (BtLEQueue.this.callback != null) {
                    BtLEQueue.this.callback.onError("Service discovery failed: " + status);
                    return;
                }
                return;
            }
            BtLEQueue.this.log("Services discovered (" + status + ")");
            List<BluetoothGattService> services = g.getServices();
            BtLEQueue.this.log("Total services: " + services.size());
            for (BluetoothGattService svc : services) {
                BtLEQueue.this.log("  Service: " + svc.getUuid());
                for (BluetoothGattCharacteristic ch : svc.getCharacteristics()) {
                    int p = ch.getProperties();
                    String props = (p & 8) != 0 ? "W" : "";
                    if ((p & 4) != 0) {
                        props = props + "WN";
                    }
                    if ((p & 16) != 0) {
                        props = props + "N";
                    }
                    if ((p & 2) != 0) {
                        props = props + "R";
                    }
                    BtLEQueue.this.log("    Char: " + ch.getUuid() + " [" + props + "]");
                }
            }
            final List<BluetoothGattService> finalServices = new ArrayList<>(services);
            BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    BtLEQueue.C03391.this.lambda$onServicesDiscovered$5(finalServices);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onServicesDiscovered$5(List finalServices) {
            if (BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onServicesDiscovered(finalServices);
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            Log.d(BtLEQueue.TAG, "onCharacteristicWrite: " + c.getUuid() + " status=" + status);
            if (BtLEQueue.this.mTransactionGattCallback != null) {
                BtLEQueue.this.mTransactionGattCallback.onCharacteristicWrite(g, c, status);
            }
            BtLEQueue.this.mLastCallbackStatus = status;
            BtLEQueue.this.checkWaitingCharacteristic(c.getUuid());
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            Log.d(BtLEQueue.TAG, "onCharacteristicRead: " + c.getUuid() + " status=" + status);
            if (BtLEQueue.this.mTransactionGattCallback != null) {
                BtLEQueue.this.mTransactionGattCallback.onCharacteristicRead(g, c, status);
            }
            BtLEQueue.this.mLastCallbackStatus = status;
            byte[] value = null;
            try {
                value = c.getValue();
            } catch (Exception e) {
            }
            if (value != null) {
                BtLEQueue.this.mLastCallbackValue = (byte[]) value.clone();
            }
            BtLEQueue.this.checkWaitingCharacteristic(c.getUuid());
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int status) {
            Log.d(BtLEQueue.TAG, "onCharacteristicRead (API33+): " + c.getUuid() + " status=" + status + " valueLen=" + (value != null ? value.length : 0));
            BtLEQueue.this.mLastCallbackStatus = status;
            if (value != null) {
                BtLEQueue.this.mLastCallbackValue = (byte[]) value.clone();
                try {
                    c.setValue(value);
                } catch (Exception e) {
                }
            }
            if (BtLEQueue.this.mTransactionGattCallback != null) {
                BtLEQueue.this.mTransactionGattCallback.onCharacteristicRead(g, c, status);
            }
            BtLEQueue.this.checkWaitingCharacteristic(c.getUuid());
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            Log.d(BtLEQueue.TAG, "onCharacteristicChanged: " + c.getUuid());
            byte[] value = null;
            try {
                value = c.getValue();
            } catch (Exception e) {
            }
            handleCharacteristicChanged(g, c, value);
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            Log.d(BtLEQueue.TAG, "onCharacteristicChanged (API33+): " + c.getUuid() + " valueLen=" + (value != null ? value.length : 0));
            if (value != null) {
                try {
                    c.setValue(value);
                } catch (Exception e) {
                }
            }
            handleCharacteristicChanged(g, c, value);
        }

        private void handleCharacteristicChanged(BluetoothGatt g, final BluetoothGattCharacteristic c, final byte[] value) {
            if (BtLEQueue.this.mTransactionGattCallback != null) {
                BtLEQueue.this.mTransactionGattCallback.onCharacteristicChanged(g, c);
            }
            if (value != null) {
                BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        BtLEQueue.C03391.this.lambda$handleCharacteristicChanged$6(c, value);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$handleCharacteristicChanged$6(BluetoothGattCharacteristic finalChar, byte[] finalValue) {
            if (BtLEQueue.this.callback != null) {
                BtLEQueue.this.callback.onNotification(finalChar, finalValue);
            }
        }

        @Override // android.bluetooth.BluetoothGattCallback
        public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            Log.d(BtLEQueue.TAG, "onDescriptorWrite: " + d.getUuid() + " status=" + status);
            if (BtLEQueue.this.mTransactionGattCallback != null) {
                BtLEQueue.this.mTransactionGattCallback.onDescriptorWrite(g, d, status);
            }
            BtLEQueue.this.mLastCallbackStatus = status;
            BtLEQueue.this.checkWaitingCharacteristic(d.getCharacteristic().getUuid());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkWaitingCharacteristic(UUID uuid) {
        BtLEAction action = this.mCurrentAction;
        if (action != null && action.getCharacteristic() != null && action.getCharacteristic().getUuid().equals(uuid)) {
            CountDownLatch latch = this.mWaitForActionResultLatch;
            if (latch != null) {
                latch.countDown();
                return;
            }
            return;
        }
        CountDownLatch latch2 = this.mWaitForActionResultLatch;
        if (latch2 != null) {
            latch2.countDown();
        }
    }

    public void startScan(List<ScanFilter> filters) {
        BluetoothAdapter bluetoothAdapter = this.btAdapter;
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Callback callback = this.callback;
            if (callback != null) {
                callback.onError("Bluetooth not enabled");
                return;
            }
            return;
        }
        if (this.scanning) {
            stopScan();
        }
        ScanSettings settings = new ScanSettings.Builder().setScanMode(2).build();
        this.scanning = true;
        if (filters != null && !filters.isEmpty()) {
            this.btAdapter.getBluetoothLeScanner().startScan(filters, settings, this.scanCallback);
        } else {
            this.btAdapter.getBluetoothLeScanner().startScan(this.scanCallback);
        }
        log("Scanning started");
    }

    public void stopScan() {
        BluetoothAdapter bluetoothAdapter;
        if (this.scanning && (bluetoothAdapter = this.btAdapter) != null && bluetoothAdapter.isEnabled()) {
            this.btAdapter.getBluetoothLeScanner().stopScan(this.scanCallback);
        }
        this.scanning = false;
    }

    public void setScanResultCallback(ScanResultCallback cb) {
        this.scanResultCallback = cb;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.zmake.mobile.BtLEQueue$2 */
    /* loaded from: classes3.dex */
    public class C03402 extends ScanCallback {
        C03402() {
        }

        @Override // android.bluetooth.le.ScanCallback
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            final String name = device.getName() != null ? device.getName() : "Unknown";
            final String mac = device.getAddress();
            final int rssi = result.getRssi();
            if (BtLEQueue.this.scanResultCallback != null) {
                BtLEQueue.this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$2$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        BtLEQueue.C03402.this.lambda$onScanResult$0(name, mac, rssi);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onScanResult$0(String name, String mac, int rssi) {
            BtLEQueue.this.scanResultCallback.onScanResult(name, mac, rssi);
        }
    }

    public boolean isConnected() {
        return this.connected;
    }

    public boolean isBluetoothEnabled() {
        BluetoothAdapter bluetoothAdapter = this.btAdapter;
        return bluetoothAdapter != null && bluetoothAdapter.isEnabled();
    }

    public int getMtu() {
        return this.currentMtu;
    }

    public BluetoothGatt getGatt() {
        return this.gatt;
    }

    public BluetoothGattCharacteristic getCharacteristic(UUID uuid) {
        BluetoothGatt bluetoothGatt = this.gatt;
        if (bluetoothGatt == null) {
            return null;
        }
        for (BluetoothGattService svc : bluetoothGatt.getServices()) {
            BluetoothGattCharacteristic ch = svc.getCharacteristic(uuid);
            if (ch != null) {
                return ch;
            }
        }
        return null;
    }

    public BluetoothGattService getService(UUID uuid) {
        BluetoothGatt bluetoothGatt = this.gatt;
        if (bluetoothGatt == null) {
            return null;
        }
        return bluetoothGatt.getService(uuid);
    }

    public static int calcMaxWriteChunk(int mtu) {
        return Math.min(512, Math.max(23, mtu) - 3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(final String msg) {
        if (this.callback != null) {
            this.mainHandler.post(new Runnable() { // from class: com.zmake.mobile.BtLEQueue$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    BtLEQueue.this.lambda$log$0(msg);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$log$0(String msg) {
        Callback callback = this.callback;
        if (callback != null) {
            callback.onLog(msg);
        }
    }
}
