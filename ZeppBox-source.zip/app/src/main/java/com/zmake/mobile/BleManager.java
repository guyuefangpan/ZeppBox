package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.ScanFilter;
import android.content.Context;
import android.os.ParcelUuid;
import com.zmake.mobile.BtLEQueue;
import com.zmake.mobile.Huami2021ChunkedDecoder;
import com.zmake.mobile.Huami2021ChunkedEncoder;
import com.zmake.mobile.ReadAction;
import com.zmake.mobile.ZeppOsAuthService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import kotlin.UByte;
import kotlin.UShort;

/* loaded from: classes3.dex */
public class BleManager {
    private static final String TAG = "BleManager";
    private byte[] authKey;
    private Callback callback;
    private BluetoothGattCharacteristic charRead;
    private BluetoothGattCharacteristic charWrite;
    private final ZeppOsAuthService mAuthService;
    private final Huami2021ChunkedDecoder mDecoder;
    private final Huami2021ChunkedEncoder mEncoder;
    private final BtLEQueue mQueue;
    private static final UUID UUID_SERVICE_1530 = UUID.fromString("00001530-0000-3512-2118-0009af100700");
    private static final UUID UUID_CHAR_1531_WRITE_RESP = UUID.fromString("00001531-0000-3512-2118-0009af100700");
    private static final UUID UUID_CHAR_1532_WRITE_NO_RESP = UUID.fromString("00001532-0000-3512-2118-0009af100700");
    private String disFirmware = "";
    private String disSerial = "";
    private String disModel = "";
    private String disManufacturer = "";
    private int disReadCount = 0;
    private int disExpected = 0;
    private volatile boolean servicesReadyFired = false;
    private volatile boolean servicesDiscoveredHandled = false;
    private final LinkedList<QueueItem> installQueue = new LinkedList<>();
    private volatile boolean queueProcessing = false;

    /* loaded from: classes3.dex */
    public interface Callback {
        void onAuthFail(String str);

        void onAuthSuccess();

        void onBattery(int i, boolean z);

        void onConnected();

        void onDisRead(String str, String str2, String str3, String str4);

        void onDisconnected();

        void onError(String str);

        void onLog(String str);

        void onNotification(byte[] bArr);

        void onRssiRead(int i);

        void onScanResult(String str, String str2, int i);

        void onServicesReady();
    }

    public void requestRssi() {
        log("Requesting RSSI...");
        BluetoothGatt gatt = this.mQueue.getGatt();
        if (gatt != null) {
            gatt.readRemoteRssi();
        }
    }

    public BleManager(Context ctx) {
        BtLEQueue btLEQueue = new BtLEQueue(ctx);
        this.mQueue = btLEQueue;
        this.mEncoder = new Huami2021ChunkedEncoder(new Huami2021ChunkedEncoder.SendCallback() { // from class: com.zmake.mobile.BleManager$$ExternalSyntheticLambda2
            @Override // com.zmake.mobile.Huami2021ChunkedEncoder.SendCallback
            public final void onSendChunk(byte[] bArr) {
                BleManager.this.lambda$new$0(bArr);
            }
        });
        this.mDecoder = new Huami2021ChunkedDecoder(new Huami2021ChunkedDecoder.PayloadHandler() { // from class: com.zmake.mobile.BleManager.1
            @Override // com.zmake.mobile.Huami2021ChunkedDecoder.PayloadHandler
            public void handlePayload(short type, byte[] payload) {
                BleManager.this.handleChunkedPayload(type, payload);
            }

            @Override // com.zmake.mobile.Huami2021ChunkedDecoder.PayloadHandler
            public void sendAck(byte handle, byte count) {
                BleManager.this.mEncoder.sendAck(handle, count);
            }

            @Override // com.zmake.mobile.Huami2021ChunkedDecoder.PayloadHandler
            public void onLog(String msg) {
                BleManager.this.log(msg);
            }
        });
        this.mAuthService = new ZeppOsAuthService(new ZeppOsAuthService.Callback() { // from class: com.zmake.mobile.BleManager.2
            @Override // com.zmake.mobile.ZeppOsAuthService.Callback
            public void onSendData(short endpoint, byte[] data, boolean encrypt) {
                BleManager.this.mEncoder.write(endpoint, data, encrypt);
            }

            @Override // com.zmake.mobile.ZeppOsAuthService.Callback
            public void onEncryptionParametersSet(int sequenceNumber, byte[] sessionKey) {
                BleManager.this.mEncoder.setEncryptionParameters(sequenceNumber, sessionKey);
                BleManager.this.mDecoder.setEncryptionParameters(sequenceNumber, sessionKey);
            }

            @Override // com.zmake.mobile.ZeppOsAuthService.Callback
            public void onAuthSuccess() {
                if (BleManager.this.callback != null) {
                    BleManager.this.callback.onAuthSuccess();
                }
            }

            @Override // com.zmake.mobile.ZeppOsAuthService.Callback
            public void onAuthFail(String reason) {
                if (BleManager.this.callback != null) {
                    BleManager.this.callback.onAuthFail(reason);
                }
            }

            @Override // com.zmake.mobile.ZeppOsAuthService.Callback
            public void onLog(String msg) {
                BleManager.this.log(msg);
            }
        });
        btLEQueue.setCallback(new BtLEQueue.Callback() { // from class: com.zmake.mobile.BleManager.3
            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onRssiRead(int rssi) {
                if (BleManager.this.callback != null) {
                    BleManager.this.callback.onRssiRead(rssi);
                }
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onConnected() {
                if (BleManager.this.callback != null) {
                    BleManager.this.callback.onConnected();
                }
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onDisconnected() {
                BleManager.this.servicesReadyFired = false;
                if (BleManager.this.callback != null) {
                    BleManager.this.callback.onDisconnected();
                }
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onServicesDiscovered(List<BluetoothGattService> services) {
                BleManager.this.handleServicesDiscovered(services);
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onMtuChanged(int mtu) {
                BleManager.this.mEncoder.setMTU(mtu);
                BleManager.this.log("Encoder MTU set to " + mtu);
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onNotification(BluetoothGattCharacteristic characteristic, byte[] value) {
                if (value == null || value.length == 0) {
                    BleManager.this.log("Notification: empty value on " + characteristic.getUuid());
                    return;
                }
                BleManager.this.log("Notification RX: " + value.length + "B on " + characteristic.getUuid() + " first=0x" + String.format("%02x", Integer.valueOf(value[0] & UByte.MAX_VALUE)));
                if (BleManager.this.charRead != null && characteristic.getUuid().equals(BleManager.this.charRead.getUuid())) {
                    BleManager.this.mDecoder.decode(value);
                } else {
                    BleManager.this.log("  Ignored: not read char (expected " + (BleManager.this.charRead != null ? BleManager.this.charRead.getUuid() : "null") + ")");
                }
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onLog(String msg) {
                BleManager.this.log(msg);
            }

            @Override // com.zmake.mobile.BtLEQueue.Callback
            public void onError(String error) {
                if (BleManager.this.callback != null) {
                    BleManager.this.callback.onError(error);
                }
            }
        });
        btLEQueue.setScanResultCallback(new BtLEQueue.ScanResultCallback() { // from class: com.zmake.mobile.BleManager$$ExternalSyntheticLambda3
            @Override // com.zmake.mobile.BtLEQueue.ScanResultCallback
            public final void onScanResult(String str, String str2, int i) {
                BleManager.this.lambda$new$1(str, str2, i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$new$0(byte[] chunk) {
        if (this.charWrite != null) {
            log("Encoder TX: " + chunk.length + "B to " + this.charWrite.getUuid());
            TransactionBuilder builder = this.mQueue.createTransaction("chunked_write");
            builder.write(this.charWrite, chunk);
            builder.queue();
            return;
        }
        log("Encoder TX: ERROR charWrite is null, cannot send chunk!");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$new$1(String name, String mac, int rssi) {
        Callback callback = this.callback;
        if (callback != null) {
            callback.onScanResult(name, mac, rssi);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleServicesDiscovered(List<BluetoothGattService> services) {
        if (this.servicesDiscoveredHandled) {
            log("Services already handled, skipping duplicate");
            return;
        }
        this.servicesDiscoveredHandled = true;
        BluetoothGattService fee0 = this.mQueue.getService(HuamiService.UUID_SERVICE_FEE0);
        if (fee0 == null) {
            fee0 = this.mQueue.getService(UUID.fromString("0000fee0-0000-1000-8000-00805f9b34fb"));
        }
        if (fee0 == null) {
            Callback callback = this.callback;
            if (callback != null) {
                callback.onError("FEE0 service not found. Is it Mi Band 7? Is Zepp app disconnected?");
                return;
            }
            return;
        }
        log("Found FEE0 service: " + fee0.getUuid());
        BluetoothGattCharacteristic characteristic = fee0.getCharacteristic(HuamiService.UUID_CHARACTERISTIC_CHUNKEDTRANSFER_2021_WRITE);
        this.charWrite = characteristic;
        if (characteristic == null) {
            this.charWrite = fee0.getCharacteristic(UUID.fromString("00000016-0000-1000-8000-00805f9b34fb"));
        }
        BluetoothGattCharacteristic characteristic2 = fee0.getCharacteristic(HuamiService.UUID_CHARACTERISTIC_CHUNKEDTRANSFER_2021_READ);
        this.charRead = characteristic2;
        if (characteristic2 == null) {
            this.charRead = fee0.getCharacteristic(UUID.fromString("00000017-0000-1000-8000-00805f9b34fb"));
        }
        if (this.charWrite == null || this.charRead == null) {
            for (BluetoothGattCharacteristic ch : fee0.getCharacteristics()) {
                String u = ch.getUuid().toString();
                if (u.contains("0016") && this.charWrite == null) {
                    this.charWrite = ch;
                }
                if (u.contains("0017") && this.charRead == null) {
                    this.charRead = ch;
                }
            }
        }
        if (this.charWrite == null || this.charRead == null) {
            Callback callback2 = this.callback;
            if (callback2 != null) {
                callback2.onError("Chunked 2021 characteristics not found");
                return;
            }
            return;
        }
        log("Found write char: " + this.charWrite.getUuid());
        log("Found read char: " + this.charRead.getUuid());
        int writeProps = this.charWrite.getProperties();
        String propStr = (writeProps & 8) != 0 ? "WRITE " : "";
        if ((writeProps & 4) != 0) {
            propStr = propStr + "WRITE_NR ";
        }
        if ((writeProps & 2) != 0) {
            propStr = propStr + "READ ";
        }
        if ((writeProps & 16) != 0) {
            propStr = propStr + "NOTIFY ";
        }
        log("Write char properties: " + propStr);
        log("Write char default write type: " + this.charWrite.getWriteType());
        TransactionBuilder builder = this.mQueue.createTransaction("enable_notifications");
        builder.notify(this.charRead, true);
        builder.queue();
        log("Notifications enabled, starting authentication...");
        TransactionBuilder delayBuilder = this.mQueue.createTransaction("settle_delay");
        delayBuilder.sleep(500);
        delayBuilder.queue();
        triggerServicesReady();
    }

    private void triggerServicesReady() {
        if (!this.servicesReadyFired) {
            this.servicesReadyFired = true;
            Callback callback = this.callback;
            if (callback != null) {
                callback.onServicesReady();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleChunkedPayload(short endpoint, byte[] payload) {
        log("RX endpoint=0x" + String.format("%04x", Integer.valueOf(endpoint & UShort.MAX_VALUE)) + " len=" + payload.length);
        if (endpoint == 130) {
            this.mAuthService.handlePayload(payload);
            return;
        }
        if (endpoint == 41) {
            handleBatteryResponse(payload);
            return;
        }
        log("Unknown endpoint 0x" + String.format("%04x", Integer.valueOf(65535 & endpoint)) + " (" + payload.length + " bytes)");
        Callback callback = this.callback;
        if (callback != null) {
            callback.onNotification(payload);
        }
    }

    private void handleBatteryResponse(byte[] payload) {
        log("Battery response raw (" + payload.length + "B): " + bytesToHex(payload));
        if (payload.length < 1) {
            log("Battery response: empty payload");
            return;
        }
        if (payload[0] != 4) {
            log("Battery response: unexpected cmd=0x" + String.format("%02x", Integer.valueOf(payload[0] & UByte.MAX_VALUE)) + " (expected 0x04)");
            return;
        }
        if (payload.length != 21) {
            log("Battery response: unexpected length=" + payload.length + " (expected 21)");
        }
        int level = payload.length >= 3 ? payload[2] & UByte.MAX_VALUE : 0;
        int state = payload.length >= 4 ? payload[3] & 255 : 0;
        boolean charging = state == 1;
        log("Battery: " + level + "% " + (charging ? "(charging)" : "(normal)") + " [payload len=" + payload.length + "]");
        Callback callback = this.callback;
        if (callback != null) {
            callback.onBattery(level, charging);
        }
    }

    private String bytesToHex(byte[] bytes) {
        if (bytes == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(bytes.length, 64); i++) {
            sb.append(String.format("%02x", Integer.valueOf(bytes[i] & UByte.MAX_VALUE)));
            if (i <= 0 || i % 16 != 15) {
                sb.append(' ');
            } else {
                sb.append("\n  ");
            }
        }
        return sb.toString().trim();
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    public boolean isConnected() {
        return this.mQueue.isConnected();
    }

    public boolean isBluetoothEnabled() {
        return this.mQueue.isBluetoothEnabled();
    }

    public int getMtu() {
        return this.mQueue.getMtu();
    }

    public void connect(String mac, byte[] authKey) {
        this.authKey = authKey;
        this.servicesReadyFired = false;
        this.servicesDiscoveredHandled = false;
        this.mEncoder.reset();
        this.mDecoder.reset();
        this.mAuthService.setAuthKey(authKey);
        this.mQueue.connect(mac);
    }

    public void disconnect() {
        this.mQueue.disconnect();
    }

    public void close() {
        this.mQueue.close();
    }

    public void stopScan() {
        this.mQueue.stopScan();
    }

    public void startScan() {
        List<ScanFilter> filters = new ArrayList<>();
        ScanFilter filter = new ScanFilter.Builder().setServiceUuid(ParcelUuid.fromString(HuamiService.UUID_SERVICE_FEE0.toString())).build();
        filters.add(filter);
        this.mQueue.startScan(filters);
        log("Scanning for Zepp devices...");
    }

    public void startScanAll() {
        this.mQueue.startScan(null);
        log("Scanning for all BLE devices...");
    }

    public void startAuthentication() {
        this.mAuthService.startAuthentication();
    }

    public void readDeviceInfo() {
        this.disFirmware = "";
        this.disSerial = "";
        this.disModel = "";
        this.disManufacturer = "小米";
        this.disReadCount = 0;
        this.disExpected = 0;
        if (enqueueDisReadWithFallback(HuamiService.UUID_DIS_FIRMWARE, HuamiService.UUID_DIS_FIRMWARE_ALT, "firmware")) {
            this.disExpected++;
        }
        if (enqueueDisRead(HuamiService.UUID_DIS_SERIAL, "serial")) {
            this.disExpected++;
        }
        if (enqueueDisReadWithFallback(HuamiService.UUID_DIS_MODEL, HuamiService.UUID_DIS_MODEL_ALT, "model")) {
            this.disExpected++;
        }
        if (this.disExpected == 0) {
            log("No DIS characteristics found on device");
            Callback callback = this.callback;
            if (callback != null) {
                callback.onDisRead("", "", "", "");
            }
        }
    }

    private boolean enqueueDisRead(UUID charUuid, final String fieldName) {
        BluetoothGattCharacteristic ch = this.mQueue.getCharacteristic(charUuid);
        if (ch == null) {
            log("DIS " + fieldName + " not found: " + charUuid);
            return false;
        }
        TransactionBuilder builder = this.mQueue.createTransaction("read_dis_" + fieldName);
        builder.read(ch, new ReadAction.ReadCallback() { // from class: com.zmake.mobile.BleManager$$ExternalSyntheticLambda0
            @Override // com.zmake.mobile.ReadAction.ReadCallback
            public final void onReadResult(int i, byte[] bArr) {
                BleManager.this.lambda$enqueueDisRead$2(fieldName, i, bArr);
            }
        });
        builder.queue();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$enqueueDisRead$2(String field, int status, byte[] value) {
        if (status == 0 && value != null) {
            String strValue = new String(value).trim();
            if (field.equals("firmware")) {
                this.disFirmware = strValue;
            } else if (field.equals("serial")) {
                this.disSerial = strValue;
            } else if (field.equals("model")) {
                this.disModel = strValue;
            } else if (field.equals("manufacturer")) {
                this.disManufacturer = strValue;
            }
        }
        this.disReadCount++;
        checkDisComplete();
    }

    private boolean enqueueDisReadWithFallback(UUID primary, UUID fallback, final String fieldName) {
        BluetoothGattCharacteristic ch = this.mQueue.getCharacteristic(primary);
        if (ch == null) {
            log("DIS " + fieldName + " primary not found, trying fallback: " + fallback);
            ch = this.mQueue.getCharacteristic(fallback);
        }
        if (ch == null) {
            log("DIS " + fieldName + " not found (no fallback either)");
            return false;
        }
        TransactionBuilder builder = this.mQueue.createTransaction("read_dis_" + fieldName);
        builder.read(ch, new ReadAction.ReadCallback() { // from class: com.zmake.mobile.BleManager$$ExternalSyntheticLambda4
            @Override // com.zmake.mobile.ReadAction.ReadCallback
            public final void onReadResult(int i, byte[] bArr) {
                BleManager.this.lambda$enqueueDisReadWithFallback$3(fieldName, i, bArr);
            }
        });
        builder.queue();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$enqueueDisReadWithFallback$3(String field, int status, byte[] value) {
        if (status == 0 && value != null) {
            String strValue = new String(value).trim();
            if (field.equals("firmware")) {
                this.disFirmware = strValue;
            } else if (field.equals("model")) {
                this.disModel = strValue;
            }
        }
        this.disReadCount++;
        checkDisComplete();
    }

    private void checkDisComplete() {
        int i = this.disReadCount;
        int i2 = this.disExpected;
        if (i >= i2 && i2 > 0) {
            String fw = this.disFirmware;
            String sn = this.disSerial;
            String md = this.disModel;
            String mf = this.disManufacturer;
            log("DIS read complete: fw=" + fw + " sn=" + sn + " model=" + md + " mfr=" + mf);
            Callback callback = this.callback;
            if (callback != null) {
                callback.onDisRead(fw, sn, md, mf);
            }
            this.disExpected = 0;
        }
    }

    public void requestBattery() {
        log("=== Requesting battery info ===");
        log("  Endpoint: 0x" + String.format("%04x", 41));
        log("  CMD: 0x" + String.format("%02x", 3));
        log("  Encrypted: true");
        log("  Session key set: " + (this.mEncoder != null));
        if (this.charWrite == null) {
            log("  ERROR: charWrite is null — not connected or services not discovered");
            return;
        }
        byte[] req = {3};
        this.mEncoder.write((short) 41, req, true);
        log("  Battery request sent");
    }

    /* loaded from: classes3.dex */
    public static class QueueItem {
        public final AppInfo appInfo;
        public final String appName;
        public final String appType;
        public final byte[] fileData;
        public final int fileSize;

        /* renamed from: id */
        public final String f41id;
        public Status status = Status.PENDING;
        public int progress = 0;
        public String message = "";

        /* loaded from: classes3.dex */
        public enum Status {
            PENDING,
            INSTALLING,
            COMPLETED,
            FAILED,
            CANCELLED
        }

        public QueueItem(String id, String appName, String appType, int fileSize, byte[] fileData, AppInfo appInfo) {
            this.f41id = id;
            this.appName = appName;
            this.appType = appType;
            this.fileSize = fileSize;
            this.fileData = fileData;
            this.appInfo = appInfo;
        }
    }

    public String getQueueStatusJson() {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        synchronized (this.installQueue) {
            Iterator<QueueItem> it = this.installQueue.iterator();
            while (it.hasNext()) {
                QueueItem item = it.next();
                if (!first) {
                    sb.append(",");
                }
                first = false;
                sb.append("{\"id\":\"").append(escapeJson(item.f41id)).append("\",\"appName\":\"").append(escapeJson(item.appName)).append("\",\"appType\":\"").append(escapeJson(item.appType)).append("\",\"fileSize\":").append(item.fileSize).append(",\"status\":\"").append(item.status.name()).append("\",\"progress\":").append(item.progress).append(",\"message\":\"").append(escapeJson(item.message)).append("\"}");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    private String escapeJson(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "").replace("\t", "\\t");
    }

    public void addToQueue(byte[] fileData, AppInfo appInfo) {
        String id = "install_" + System.currentTimeMillis() + "_" + ((int) (Math.random() * 1000.0d));
        String typeLabel = appInfo.appType.equals("watchface") ? "表盘" : "应用";
        QueueItem item = new QueueItem(id, appInfo.appName, appInfo.appType, fileData.length, fileData, appInfo);
        synchronized (this.installQueue) {
            this.installQueue.addLast(item);
        }
        log("queueItemAdded:" + id + ":" + appInfo.appName + ":" + typeLabel + ":" + fileData.length + ":" + (appInfo.appType.equals("watchface") ? "0" : "1"));
        processQueue();
    }

    public void cancelQueueItem(String itemId) {
        synchronized (this.installQueue) {
            Iterator<QueueItem> it = this.installQueue.iterator();
            while (it.hasNext()) {
                QueueItem item = it.next();
                if (item.f41id.equals(itemId) && item.status == QueueItem.Status.PENDING) {
                    item.status = QueueItem.Status.CANCELLED;
                    item.message = "已取消";
                    log("queueItemRemoved:" + itemId);
                    notifyQueueChanged();
                    return;
                }
            }
        }
    }

    public void clearQueue() {
        synchronized (this.installQueue) {
            Iterator<QueueItem> it = this.installQueue.iterator();
            while (it.hasNext()) {
                QueueItem item = it.next();
                if (item.status == QueueItem.Status.PENDING) {
                    item.status = QueueItem.Status.CANCELLED;
                    item.message = "已取消";
                    it.remove();
                }
            }
        }
        notifyQueueChanged();
        log("queueCleared");
    }

    private void notifyQueueChanged() {
        Callback callback = this.callback;
        if (callback != null) {
            callback.onLog("queueChanged:" + getQueueStatusJson());
        }
    }

    private void processQueue() {
        if (this.queueProcessing) {
            return;
        }
        synchronized (this.installQueue) {
            if (this.installQueue.isEmpty()) {
                return;
            }
            QueueItem next = null;
            Iterator<QueueItem> it = this.installQueue.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                QueueItem item = it.next();
                if (item.status == QueueItem.Status.PENDING) {
                    next = item;
                    break;
                }
            }
            if (next == null) {
                return;
            }
            next.status = QueueItem.Status.INSTALLING;
            this.queueProcessing = true;
            processNextInQueue();
        }
    }

    private void processNextInQueue() {
        QueueItem queueItem;
        BluetoothGattService bluetoothGattService;
        synchronized (this.installQueue) {
            Iterator<QueueItem> it = this.installQueue.iterator();
            while (true) {
                if (!it.hasNext()) {
                    queueItem = null;
                    break;
                }
                QueueItem next = it.next();
                if (next.status == QueueItem.Status.INSTALLING) {
                    queueItem = next;
                    break;
                }
            }
        }
        if (queueItem == null) {
            this.queueProcessing = false;
            synchronized (this.installQueue) {
                Iterator<QueueItem> it2 = this.installQueue.iterator();
                while (it2.hasNext()) {
                    QueueItem next2 = it2.next();
                    if (next2.status == QueueItem.Status.PENDING) {
                        this.queueProcessing = true;
                        next2.status = QueueItem.Status.INSTALLING;
                        processNextInQueue();
                        return;
                    }
                }
                return;
            }
        }
        if (this.charWrite != null) {
            log("=== 开始安装: " + queueItem.appName + " (" + queueItem.appType + ") ===");
            log("文件大小: " + queueItem.fileSize + " bytes");
            notifyQueueChanged();
            BluetoothGattService service = this.mQueue.getService(UUID_SERVICE_1530);
            if (service != null) {
                bluetoothGattService = service;
            } else {
                bluetoothGattService = this.mQueue.getService(UUID.fromString("00001530-0000-1000-8000-00805f9b34fb"));
            }
            if (bluetoothGattService == null) {
                queueItem.status = QueueItem.Status.FAILED;
                queueItem.message = "设备不支持0x1530安装服务";
                log("queueItemFailed:" + queueItem.f41id + ":设备不支持应用安装服务");
                notifyQueueChanged();
                this.queueProcessing = false;
                processQueue();
                return;
            }
            final BluetoothGattCharacteristic characteristic = bluetoothGattService.getCharacteristic(UUID_CHAR_1531_WRITE_RESP);
            final BluetoothGattCharacteristic characteristic2 = bluetoothGattService.getCharacteristic(UUID_CHAR_1532_WRITE_NO_RESP);
            if (characteristic != null || characteristic2 != null) {
                log("找到安装服务: 1531=" + (characteristic != null) + " 1532=" + (characteristic2 != null));
                final int i = !queueItem.appInfo.appType.equals("watchface") ? 1 : 0;
                final ArrayList<byte[]> buildInstallPackets = buildInstallPackets(queueItem.fileData, i);
                final int size = buildInstallPackets.size();
                log("数据包数量: " + size);
                if (characteristic != null) {
                    TransactionBuilder createTransaction = this.mQueue.createTransaction("enable_1531_notify");
                    createTransaction.notify(characteristic, true);
                    createTransaction.queue();
                }
                final QueueItem queueItem2 = queueItem;
                new Thread(new Runnable() { // from class: com.zmake.mobile.BleManager$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        BleManager.this.lambda$processNextInQueue$4(size, queueItem2, buildInstallPackets, characteristic, characteristic2, i);
                    }
                }).start();
                return;
            }
            queueItem.status = QueueItem.Status.FAILED;
            queueItem.message = "安装服务特征值未找到";
            log("queueItemFailed:" + queueItem.f41id + ":安装服务特征值未找到");
            notifyQueueChanged();
            this.queueProcessing = false;
            processQueue();
            return;
        }
        queueItem.status = QueueItem.Status.FAILED;
        queueItem.message = "设备未连接";
        log("queueItemFailed:" + queueItem.f41id + ":设备未连接");
        notifyQueueChanged();
        this.queueProcessing = false;
        processQueue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0076 A[Catch: Exception -> 0x0112, all -> 0x0159, TryCatch #2 {all -> 0x0159, blocks: (B:43:0x00bd, B:45:0x00c8, B:48:0x00dc, B:9:0x001b, B:11:0x002e, B:13:0x0032, B:20:0x003f, B:21:0x0053, B:23:0x0076, B:24:0x00ae, B:26:0x00b2, B:28:0x00b7, B:31:0x0047, B:32:0x004e, B:35:0x011b, B:37:0x0121), top: B:2:0x0009 }] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00b2 A[Catch: Exception -> 0x0112, all -> 0x0159, TryCatch #2 {all -> 0x0159, blocks: (B:43:0x00bd, B:45:0x00c8, B:48:0x00dc, B:9:0x001b, B:11:0x002e, B:13:0x0032, B:20:0x003f, B:21:0x0053, B:23:0x0076, B:24:0x00ae, B:26:0x00b2, B:28:0x00b7, B:31:0x0047, B:32:0x004e, B:35:0x011b, B:37:0x0121), top: B:2:0x0009 }] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00b7 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0047 A[Catch: Exception -> 0x0112, all -> 0x0159, TryCatch #2 {all -> 0x0159, blocks: (B:43:0x00bd, B:45:0x00c8, B:48:0x00dc, B:9:0x001b, B:11:0x002e, B:13:0x0032, B:20:0x003f, B:21:0x0053, B:23:0x0076, B:24:0x00ae, B:26:0x00b2, B:28:0x00b7, B:31:0x0047, B:32:0x004e, B:35:0x011b, B:37:0x0121), top: B:2:0x0009 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x004e A[Catch: Exception -> 0x0112, all -> 0x0159, TryCatch #2 {all -> 0x0159, blocks: (B:43:0x00bd, B:45:0x00c8, B:48:0x00dc, B:9:0x001b, B:11:0x002e, B:13:0x0032, B:20:0x003f, B:21:0x0053, B:23:0x0076, B:24:0x00ae, B:26:0x00b2, B:28:0x00b7, B:31:0x0047, B:32:0x004e, B:35:0x011b, B:37:0x0121), top: B:2:0x0009 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public /* synthetic */ void lambda$processNextInQueue$4(int totalPackets, QueueItem finalCurrent, ArrayList finalPackets, BluetoothGattCharacteristic finalChar1531, BluetoothGattCharacteristic finalChar1532, int type) {
        boolean useResponse;
        BluetoothGattCharacteristic targetChar;
        try {
            try {
                Thread.sleep(500L);
                for (int i = 0; i < totalPackets; i++) {
                    if (finalCurrent.status != QueueItem.Status.INSTALLING) {
                        break;
                    }
                    try {
                        byte[] packet = (byte[]) finalPackets.get(i);
                        int percent = (int) ((i * 100) / totalPackets);
                        finalCurrent.progress = percent;
                        if (i >= 4 && i % 4 != 0 && i < totalPackets - 2) {
                            useResponse = false;
                            if (!useResponse && finalChar1531 != null) {
                                targetChar = finalChar1531;
                                targetChar.setWriteType(2);
                            } else if (finalChar1532 == null) {
                                finalChar1532.setWriteType(1);
                                targetChar = finalChar1532;
                            } else {
                                targetChar = finalChar1531;
                                targetChar.setWriteType(2);
                            }
                            TransactionBuilder builder = this.mQueue.createTransaction("install_pkt_" + i);
                            builder.write(targetChar, packet);
                            builder.queue();
                            if (this.callback != null) {
                                String status = "queueProgress:" + finalCurrent.f41id + ":" + percent + ":发送数据包 " + (i + 1) + "/" + totalPackets;
                                this.callback.onLog(status);
                            }
                            if (i % 10 != 0) {
                                Thread.sleep(20L);
                            }
                        }
                        useResponse = true;
                        if (!useResponse) {
                        }
                        if (finalChar1532 == null) {
                        }
                        TransactionBuilder builder2 = this.mQueue.createTransaction("install_pkt_" + i);
                        builder2.write(targetChar, packet);
                        builder2.queue();
                        if (this.callback != null) {
                        }
                        if (i % 10 != 0) {
                        }
                    } catch (Exception e) {
                        e = e;
                        if (finalCurrent.status == QueueItem.Status.INSTALLING) {
                            finalCurrent.status = QueueItem.Status.FAILED;
                            finalCurrent.message = e.getMessage();
                            log("queueItemFailed:" + finalCurrent.f41id + ":" + e.getMessage());
                            notifyQueueChanged();
                        }
                        this.queueProcessing = false;
                        processQueue();
                    }
                }
                Thread.sleep(2000L);
                if (finalCurrent.status == QueueItem.Status.INSTALLING) {
                    finalCurrent.status = QueueItem.Status.COMPLETED;
                    finalCurrent.progress = 100;
                    finalCurrent.message = (type == 0 ? "表盘" : "应用") + "安装成功";
                    log("queueItemCompleted:" + finalCurrent.f41id + ":" + finalCurrent.message);
                    notifyQueueChanged();
                }
            } catch (Throwable th) {
                th = th;
                this.queueProcessing = false;
                processQueue();
                throw th;
            }
        } catch (Exception e2) {
            e = e2;
        } catch (Throwable th2) {
            th = th2;
            this.queueProcessing = false;
            processQueue();
            throw th;
        }
        this.queueProcessing = false;
        processQueue();
    }

    private ArrayList<byte[]> buildInstallPackets(byte[] fileData, int type) {
        int chunkSize;
        ArrayList<byte[]> packets = new ArrayList<>();
        packets.add(new byte[]{-48});
        packets.add(new byte[]{-47});
        byte[] d2 = new byte[14];
        d2[0] = -46;
        d2[1] = type == 0 ? (byte) 8 : (byte) -3;
        int fileLen = fileData.length;
        d2[2] = (byte) (fileLen & 255);
        d2[3] = (byte) ((fileLen >> 8) & 255);
        d2[4] = (byte) ((fileLen >> 16) & 255);
        d2[5] = (byte) ((fileLen >> 24) & 255);
        long crc = AppUtils.crc32(fileData);
        d2[6] = (byte) (crc & 255);
        d2[7] = (byte) ((crc >> 8) & 255);
        d2[8] = (byte) ((crc >> 16) & 255);
        d2[9] = (byte) (255 & (crc >> 24));
        d2[10] = 0;
        d2[11] = 32;
        d2[12] = 0;
        d2[13] = -1;
        packets.add(d2);
        packets.add(new byte[]{-45, 1});
        int offset = 0;
        int chunkCount = 0;
        while (offset < fileData.length) {
            if (chunkCount < 33) {
                chunkSize = Math.min(244, fileData.length - offset);
            } else {
                int chunkSize2 = fileData.length;
                chunkSize = Math.min(140, chunkSize2 - offset);
            }
            byte[] chunk = new byte[chunkSize];
            System.arraycopy(fileData, offset, chunk, 0, chunkSize);
            packets.add(chunk);
            offset += chunkSize;
            chunkCount++;
        }
        packets.add(new byte[]{-43});
        packets.add(new byte[]{-42});
        return packets;
    }

    public void uninstallApp(int appId) {
        log("=== 卸载应用 ID: " + appId + " ===");
        if (this.charWrite == null) {
            log("错误: 设备未连接");
            Callback callback = this.callback;
            if (callback != null) {
                callback.onLog("installComplete:false:设备未连接");
                return;
            }
            return;
        }
        byte[] command = {3, 7, 0, 87, 0, 20, 0, 0, 0, -96, 0, 2, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (byte) (appId & 255), (byte) ((appId >> 8) & 255), (byte) ((appId >> 16) & 255), (byte) ((appId >> 24) & 255)};
        log("卸载命令: " + bytesToHex(command));
        TransactionBuilder builder = this.mQueue.createTransaction("uninstall_app");
        builder.write(this.charWrite, command);
        builder.queue();
        log("卸载命令已发送");
        log("installComplete:true:应用卸载成功");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void log(String msg) {
        Callback callback = this.callback;
        if (callback != null) {
            callback.onLog(msg);
        }
    }

    public void resetState() {
        this.servicesReadyFired = false;
        this.servicesDiscoveredHandled = false;
        this.mEncoder.reset();
        this.mDecoder.reset();
    }
}
