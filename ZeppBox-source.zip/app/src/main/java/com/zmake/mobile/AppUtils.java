package com.zmake.mobile;

import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.json.JSONObject;

/* loaded from: classes3.dex */
public class AppUtils {
    private static final String TAG = "AppUtils";

    public static AppInfo parseBinFile(byte[] fileData) {
        if (fileData == null || fileData.length < 4) {
            Log.e(TAG, "File data too short");
            return null;
        }
        boolean isZip = false;
        if ((fileData[0] == 80 && fileData[1] == 75 && fileData[2] == 3 && fileData[3] == 4) || (fileData[0] == 80 && fileData[1] == 75 && fileData[2] == 5 && fileData[3] == 6)) {
            isZip = true;
        }
        if (!isZip) {
            Log.e(TAG, "File is not a ZIP archive");
            return null;
        }
        String appJson = extractAppJson(fileData);
        if (appJson == null) {
            Log.e(TAG, "app.json not found in ZIP");
            return null;
        }
        return parseAppJson(appJson);
    }

    private static String extractAppJson(byte[] zipData) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(zipData);
            ZipInputStream zis = new ZipInputStream(bis);
            while (true) {
                ZipEntry entry = zis.getNextEntry();
                if (entry != null) {
                    if (entry.getName().equals("app.json")) {
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        byte[] buffer = new byte[4096];
                        while (true) {
                            int len = zis.read(buffer);
                            if (len != -1) {
                                baos.write(buffer, 0, len);
                            } else {
                                zis.close();
                                return baos.toString("UTF-8");
                            }
                        }
                    } else {
                        zis.closeEntry();
                    }
                } else {
                    zis.close();
                    return null;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to extract app.json", e);
            return null;
        }
    }

    private static AppInfo parseAppJson(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONObject app = root.getJSONObject("app");
            AppInfo info = new AppInfo();
            info.appId = app.optInt("appId", -1);
            info.appName = app.optString("appName", "Unknown");
            info.appType = app.optString("appType", "");
            info.vender = app.optString("vender", "");
            info.description = app.optString("description", "");
            Object versionObj = app.opt("version");
            if (versionObj instanceof String) {
                info.version = (String) versionObj;
            } else if (versionObj instanceof JSONObject) {
                info.version = ((JSONObject) versionObj).optString("name", "1.0");
            } else {
                info.version = "1.0";
            }
            Log.d(TAG, "Parsed: " + info);
            return info;
        } catch (Exception e) {
            Log.e(TAG, "Failed to parse app.json", e);
            return null;
        }
    }

    public static long crc32(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data);
        return crc.getValue();
    }
}
