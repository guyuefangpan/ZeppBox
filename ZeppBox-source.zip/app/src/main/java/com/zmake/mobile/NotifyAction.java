package com.zmake.mobile;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.os.Build;
import android.util.Log;
import java.util.UUID;

/* loaded from: classes3.dex */
public class NotifyAction extends BtLEAction {
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final String TAG = "NotifyAction";
    private final boolean enable;

    public NotifyAction(BluetoothGattCharacteristic characteristic, boolean enable) {
        super(characteristic);
        this.enable = enable;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean expectsResult() {
        return true;
    }

    @Override // com.zmake.mobile.BtLEAction
    public boolean run(BluetoothGatt gatt) {
        boolean result = gatt.setCharacteristicNotification(getCharacteristic(), this.enable);
        if (!result) {
            Log.e(TAG, "setCharacteristicNotification failed");
            return false;
        }
        BluetoothGattDescriptor cccd = getCharacteristic().getDescriptor(CCCD);
        if (cccd == null) {
            Log.w(TAG, "No CCCD descriptor found, notification set but no descriptor to write");
            return true;
        }
        byte[] value = this.enable ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE;
        return writeDescriptor(gatt, cccd, value);
    }

    private static boolean writeDescriptor(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, byte[] value) {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                int status = gatt.writeDescriptor(descriptor, value);
                return status == 0;
            } catch (Exception e) {
                Log.e(TAG, "writeDescriptor exception", e);
                return false;
            }
        }
        descriptor.setValue(value);
        return gatt.writeDescriptor(descriptor);
    }

    @Override // com.zmake.mobile.BtLEAction
    public String getKind() {
        return this.enable ? "NOTIFY_ENABLE" : "NOTIFY_DISABLE";
    }
}
