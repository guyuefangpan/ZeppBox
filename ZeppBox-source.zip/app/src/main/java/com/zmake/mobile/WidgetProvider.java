package com.zmake.mobile;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;

/* loaded from: classes3.dex */
public class WidgetProvider extends AppWidgetProvider {
    @Override // android.appwidget.AppWidgetProvider
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        updateWidgets(context, manager, ids);
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        SharedPreferences prefs = context.getSharedPreferences("zeppbox_widget", 0);
        String deviceName = prefs.getString("device_name", "Xiaomi Smart Band 7");
        String status = prefs.getString(NotificationCompat.CATEGORY_STATUS, "disconnected");
        String battery = prefs.getString("battery", "");
        String signal = prefs.getString("signal", "");
        Intent intent = new Intent(context, (Class<?>) MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 0, intent, 201326592);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_ble_status);
        views.setTextViewText(R.id.widget_device_name, deviceName);
        if (status.equals("connected")) {
            views.setTextViewText(R.id.widget_status_text, "● 已连接");
            views.setTextColor(R.id.widget_status_text, Color.parseColor("#34c759"));
        } else if (status.equals("connecting")) {
            views.setTextViewText(R.id.widget_status_text, "● 连接中...");
            views.setTextColor(R.id.widget_status_text, Color.parseColor("#ff9500"));
        } else {
            views.setTextViewText(R.id.widget_status_text, "● 未连接");
            views.setTextColor(R.id.widget_status_text, Color.parseColor("#888888"));
        }
        if (!TextUtils.isEmpty(battery)) {
            views.setTextViewText(R.id.widget_battery_text, battery);
        } else {
            views.setTextViewText(R.id.widget_battery_text, "--");
        }
        if (TextUtils.isEmpty(signal)) {
            views.setTextViewText(R.id.widget_signal_text, "");
        } else {
            views.setTextViewText(R.id.widget_signal_text, signal);
        }
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        for (int id : ids) {
            manager.updateAppWidget(id, views);
        }
    }

    public static void triggerUpdate(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName name = new ComponentName(context, (Class<?>) WidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(name);
        updateWidgets(context, manager, ids);
    }
}
