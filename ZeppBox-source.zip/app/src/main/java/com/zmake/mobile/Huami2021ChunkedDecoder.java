package com.zmake.mobile;

import android.util.Log;
import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import kotlin.UByte;

/* loaded from: classes3.dex */
public class Huami2021ChunkedDecoder {
    private static final String TAG = "Huami2021ChunkDecoder";
    private final PayloadHandler handler;
    private ByteBuffer reassemblyBuffer = null;
    private int currentType = 0;
    private int currentLength = 0;
    private byte currentHandle = 0;
    private byte currentFlags = 0;
    private int mEncryptionSequenceNumber = 0;
    private byte[] mSharedSessionKey = null;

    /* loaded from: classes3.dex */
    public interface PayloadHandler {
        void handlePayload(short s, byte[] bArr);

        void onLog(String str);

        void sendAck(byte b, byte b2);
    }

    public Huami2021ChunkedDecoder(PayloadHandler handler) {
        this.handler = handler;
    }

    public void setEncryptionParameters(int sequenceNumber, byte[] sessionKey) {
        this.mEncryptionSequenceNumber = sequenceNumber;
        this.mSharedSessionKey = sessionKey;
    }

    public void reset() {
        this.reassemblyBuffer = null;
        this.currentType = 0;
        this.currentLength = 0;
        this.currentHandle = (byte) 0;
        this.mEncryptionSequenceNumber = 0;
        this.mSharedSessionKey = null;
    }

    public void decode(byte[] data) {
        String str;
        String str2;
        ByteBuffer byteBuffer;
        ByteBuffer byteBuffer2;
        int encLen;
        PayloadHandler payloadHandler;
        if (data == null) {
            str = "null";
        } else {
            if (data.length >= 5) {
                if (data[0] != 3) {
                    PayloadHandler payloadHandler2 = this.handler;
                    if (payloadHandler2 != null) {
                        payloadHandler2.onLog("Decoder: not chunked 2021 (type=0x" + String.format("%02x", Integer.valueOf(data[0] & UByte.MAX_VALUE)) + ") len=" + data.length);
                        return;
                    }
                    return;
                }
                int i = 1 + 1;
                byte flags = data[1];
                boolean encrypted = (flags & 8) != 0;
                boolean firstChunk = (flags & 1) != 0;
                boolean lastChunk = (flags & 2) != 0;
                boolean needsAck = (flags & 4) != 0;
                int i2 = i + 1;
                int i3 = i2 + 1;
                byte handle = data[i2];
                int i4 = i3 + 1;
                byte count = data[i3];
                PayloadHandler payloadHandler3 = this.handler;
                if (payloadHandler3 != null) {
                    payloadHandler3.onLog("Decoder RX: flags=0x" + String.format("%02x", Integer.valueOf(flags & UByte.MAX_VALUE)) + " first=" + firstChunk + " last=" + lastChunk + " ack=" + needsAck + " enc=" + encrypted + " handle=" + (handle & UByte.MAX_VALUE) + " count=" + (count & UByte.MAX_VALUE) + " dataLen=" + data.length);
                }
                if (needsAck && (payloadHandler = this.handler) != null) {
                    payloadHandler.sendAck(handle, count);
                }
                if (!firstChunk) {
                    str2 = "null";
                } else {
                    int i5 = i4 + 1;
                    int i6 = i5 + 1;
                    int i7 = (data[i4] & 255) | ((data[i5] & 255) << 8);
                    int i8 = i6 + 1;
                    str2 = "null";
                    int i9 = ((data[i6] & UByte.MAX_VALUE) << 16) | i7;
                    int i10 = i8 + 1;
                    int fullLength = ((data[i8] & 255) << 24) | i9;
                    if (fullLength >= 0 && fullLength <= 65536) {
                        this.currentLength = fullLength;
                        if (!encrypted) {
                            encLen = fullLength;
                        } else {
                            encLen = fullLength + 8;
                            int overflow = encLen % 16;
                            if (overflow > 0) {
                                encLen += 16 - overflow;
                            }
                        }
                        try {
                            this.reassemblyBuffer = ByteBuffer.allocate(encLen);
                            int i11 = i10 + 1;
                            int i12 = data[i10] & UByte.MAX_VALUE;
                            i4 = i11 + 1;
                            this.currentType = ((data[i11] & 255) << 8) | i12;
                            this.currentHandle = handle;
                            this.currentFlags = flags;
                            Log.d(TAG, "  First chunk: length=" + fullLength + " type=0x" + String.format("%04x", Integer.valueOf(this.currentType)));
                            PayloadHandler payloadHandler4 = this.handler;
                            if (payloadHandler4 != null) {
                                payloadHandler4.onLog("  First chunk: length=" + fullLength + " type=0x" + String.format("%04x", Integer.valueOf(this.currentType)));
                            }
                        } catch (OutOfMemoryError e) {
                            PayloadHandler payloadHandler5 = this.handler;
                            if (payloadHandler5 != null) {
                                int allocLen = encLen;
                                payloadHandler5.onLog("Cannot allocate " + allocLen + " bytes");
                                return;
                            }
                            return;
                        }
                    }
                    PayloadHandler payloadHandler6 = this.handler;
                    if (payloadHandler6 != null) {
                        payloadHandler6.onLog("Unreasonable length: " + fullLength);
                        return;
                    }
                    return;
                }
                int payloadLen = data.length - i4;
                if (payloadLen > 0 && (byteBuffer2 = this.reassemblyBuffer) != null) {
                    byteBuffer2.put(data, i4, payloadLen);
                }
                if (lastChunk && (byteBuffer = this.reassemblyBuffer) != null) {
                    int bufLen = byteBuffer.position();
                    byte[] trimmed = this.reassemblyBuffer.array();
                    PayloadHandler payloadHandler7 = this.handler;
                    if (payloadHandler7 != null) {
                        payloadHandler7.onLog("  Reassembled: " + bufLen + " bytes (expected " + this.currentLength + ") enc=" + encrypted + " sessionKey=" + (this.mSharedSessionKey != null ? "set" : str2));
                    }
                    if (encrypted && this.mSharedSessionKey != null) {
                        byte[] messageKey = new byte[16];
                        int j = 0;
                        for (int i13 = 16; j < i13; i13 = 16) {
                            messageKey[j] = (byte) (this.mSharedSessionKey[j] ^ this.currentHandle);
                            j++;
                            handle = handle;
                        }
                        byte[] buf = aesEcbDecrypt(trimmed, messageKey);
                        if (this.currentLength + 8 <= buf.length) {
                            CRC32 crc = new CRC32();
                            crc.update(buf, 0, this.currentLength + 4);
                            int expectedCrc = (int) crc.getValue();
                            int i14 = this.currentLength;
                            int actualCrc = (buf[i14 + 4] & UByte.MAX_VALUE) | ((buf[i14 + 5] & UByte.MAX_VALUE) << 8) | ((buf[i14 + 6] & UByte.MAX_VALUE) << 16) | ((buf[i14 + 7] & UByte.MAX_VALUE) << 24);
                            if (expectedCrc == actualCrc) {
                                PayloadHandler payloadHandler8 = this.handler;
                                if (payloadHandler8 != null) {
                                    payloadHandler8.onLog("  CRC OK");
                                }
                            } else {
                                Log.w(TAG, "CRC mismatch: expected=" + expectedCrc + " actual=" + actualCrc);
                                PayloadHandler payloadHandler9 = this.handler;
                                if (payloadHandler9 != null) {
                                    payloadHandler9.onLog("  CRC mismatch in decrypted data! expected=0x" + String.format("%08x", Integer.valueOf(expectedCrc)) + " actual=0x" + String.format("%08x", Integer.valueOf(actualCrc)));
                                }
                            }
                        }
                        int i15 = this.currentLength;
                        trimmed = new byte[i15];
                        System.arraycopy(buf, 0, trimmed, 0, Math.min(i15, buf.length));
                    } else if (encrypted && this.mSharedSessionKey == null) {
                        PayloadHandler payloadHandler10 = this.handler;
                        if (payloadHandler10 != null) {
                            payloadHandler10.onLog("  WARNING: encrypted message but no session key!");
                        }
                    } else {
                        byte[] trimmed2 = new byte[bufLen];
                        System.arraycopy(trimmed, 0, trimmed2, 0, bufLen);
                        trimmed = trimmed2;
                    }
                    PayloadHandler payloadHandler11 = this.handler;
                    if (payloadHandler11 != null) {
                        if (payloadHandler11 != null) {
                            payloadHandler11.onLog("  Dispatching: type=0x" + String.format("%04x", Integer.valueOf(this.currentType)) + " len=" + trimmed.length);
                        }
                        this.handler.handlePayload((short) this.currentType, trimmed);
                    }
                    this.reassemblyBuffer = null;
                    return;
                }
                return;
            }
            str = "null";
        }
        PayloadHandler payloadHandler12 = this.handler;
        if (payloadHandler12 != null) {
            payloadHandler12.onLog("Decoder: received short data: " + (data == null ? str : data.length + " bytes"));
        }
    }

    private byte[] aesEcbDecrypt(byte[] data, byte[] key) {
        try {
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            cipher.init(2, keySpec);
            return cipher.doFinal(data);
        } catch (Exception e) {
            Log.e(TAG, "AES decrypt failed", e);
            return data;
        }
    }
}
