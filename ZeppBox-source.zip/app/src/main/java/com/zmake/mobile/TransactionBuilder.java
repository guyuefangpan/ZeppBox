package com.zmake.mobile;

import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import com.zmake.mobile.ReadAction;
import com.zmake.mobile.WriteAction;
import java.util.concurrent.LinkedBlockingDeque;

/* loaded from: classes3.dex */
public class TransactionBuilder {
    private final LinkedBlockingDeque<Transaction> queue;
    private final Transaction transaction;

    public TransactionBuilder(String taskName, LinkedBlockingDeque<Transaction> queue) {
        this.transaction = new Transaction(taskName);
        this.queue = queue;
    }

    public TransactionBuilder write(BluetoothGattCharacteristic characteristic, byte[] data) {
        this.transaction.addAction(new WriteAction(characteristic, data));
        return this;
    }

    public TransactionBuilder write(BluetoothGattCharacteristic characteristic, byte[] data, WriteAction.WriteCallback callback) {
        this.transaction.addAction(new WriteAction(characteristic, data, callback));
        return this;
    }

    public TransactionBuilder read(BluetoothGattCharacteristic characteristic) {
        this.transaction.addAction(new ReadAction(characteristic));
        return this;
    }

    public TransactionBuilder read(BluetoothGattCharacteristic characteristic, ReadAction.ReadCallback callback) {
        this.transaction.addAction(new ReadAction(characteristic, callback));
        return this;
    }

    public TransactionBuilder notify(BluetoothGattCharacteristic characteristic, boolean enable) {
        this.transaction.addAction(new NotifyAction(characteristic, enable));
        return this;
    }

    public TransactionBuilder sleep(int millis) {
        this.transaction.addAction(new SleepAction(millis));
        return this;
    }

    public TransactionBuilder requestMtu(int mtu) {
        this.transaction.addAction(new RequestMtuAction(mtu));
        return this;
    }

    public TransactionBuilder setCallback(BluetoothGattCallback callback) {
        this.transaction.setCallback(callback);
        return this;
    }

    public void queue() {
        this.queue.addLast(this.transaction);
    }

    public void queueImmediately() {
        this.queue.addFirst(this.transaction);
    }

    public Transaction getTransaction() {
        return this.transaction;
    }
}
