/**
 * tga-encoder.js
 * -----------------------------------------------------------------------------
 * A self-contained JavaScript TGA encoder for ZeppOS.
 *
 * Converts PNG image data (Canvas ImageData, RGBA) into the ZeppOS-specific
 * TGA flavour. The byte layout and the four supported sub-formats mirror the
 * Python reference implementation found in zmake's `tga_save.py`
 * (https://github.com/melianmiko/zmake).
 *
 * Supported formats (selected by file-name suffix):
 *   "P"   -> TGA-P   (.p.png)    palette, data type 1, 8-bit indices
 *   "RLP" -> TGA-RLP (.rlp.png)  palette + RLE, data type 9
 *   "16"  -> TGA-16  (.rgb.png)  truecolour RGB565, data type 2
 *   "32"  -> TGA-32  (.rgba.png) truecolour RGBA,  data type 2
 *
 * Encode modes (target device family):
 *   "dialog" -> Mi Band 7 / default. Palette entries are stored BGRA.
 *   "nxp"    -> Newer platforms. Palette entries are stored RGBA and the image
 *               width is padded up to a multiple of 16 pixels.
 *
 * The code is intentionally written in ES5 syntax so it runs inside older
 * WebView engines. It has no external dependencies.
 * -----------------------------------------------------------------------------
 */

(function (root, factory) {
  "use strict";
  if (typeof module === "object" && module !== null && typeof module.exports === "object") {
    // CommonJS / Node (handy for unit tests)
    module.exports = factory();
  } else {
    // Browser / WebView global
    root.TGAEncoder = factory();
  }
})(typeof window !== "undefined" ? window : (typeof self !== "undefined" ? self : this), function () {
  "use strict";

  // ===========================================================================
  // Constants
  // ===========================================================================

  // Size of the ZeppOS TGA header + ID section (18 byte header + 46 byte ID).
  var HEADER_SIZE = 64;

  // The 4-byte magic stored at the beginning of the ID section.
  var ID_MAGIC = [0x53, 0x4F, 0x4D, 0x48]; // "SOMH"

  // Palette is always written as a fixed 256-entry table (matching zmake).
  var PALETTE_ENTRIES = 256;

  // Colour used to pad the palette up to 256 entries (opaque black).
  var PALETTE_PAD = [0, 0, 0, 255];

  // Maximum number of pixels a single RLE / literal packet may describe.
  var RLE_MAX_RUN = 128;

  // ===========================================================================
  // Small helpers
  // ===========================================================================

  /**
   * ES5-safe String.endsWith replacement.
   */
  function endsWith(str, suffix) {
    var s = String(str);
    var suf = String(suffix);
    return s.length >= suf.length &&
      s.indexOf(suf, s.length - suf.length) !== -1;
  }

  /**
   * Build a unique numeric key for an RGBA colour.
   *
   * The value fits inside a 32-bit unsigned int (0 .. 0xFFFFFFFF) and stays
   * well below Number.MAX_SAFE_INTEGER, so it can be used directly as an
   * object property name without collisions.
   */
  function colorKey(r, g, b, a) {
    return ((((r * 256) + g) * 256 + b) * 256 + a);
  }

  // ===========================================================================
  // Format detection
  // ===========================================================================

  /**
   * Determine the target TGA format from a file name.
   *
   *   "*.p.png"     -> "P"
   *   "*.rlp.png"   -> "RLP"
   *   "*.rgb.png"   -> "16"
   *   "*.rgba.png"  -> "32"
   *   anything else -> "P"   (zmake's default format)
   *
   * @param {string} filename
   * @return {string} one of "P" | "RLP" | "16" | "32"
   */
  function getFormatFromFilename(filename) {
    if (!filename) {
      return "P";
    }
    var name = String(filename).toLowerCase();
    // Order matters: check the longer suffixes first.
    if (endsWith(name, ".rlp.png")) {
      return "RLP";
    }
    if (endsWith(name, ".rgba.png")) {
      return "32";
    }
    if (endsWith(name, ".rgb.png")) {
      return "16";
    }
    if (endsWith(name, ".p.png")) {
      return "P";
    }
    return "P";
  }

  // ===========================================================================
  // Colour quantisation (median cut)
  // ===========================================================================

  /**
   * Walk the RGBA buffer once and collect every unique colour together with
   * the number of times it occurs.
   *
   * @param {Uint8ClampedArray|Uint8Array} data  RGBA pixel buffer
   * @return {Array<Object>} list of {r,g,b,a,count} entries
   */
  function collectUniqueColors(data) {
    var map = {};
    var colors = [];
    var len = data.length;
    var i;
    for (i = 0; i < len; i += 4) {
      var r = data[i];
      var g = data[i + 1];
      var b = data[i + 2];
      var a = data[i + 3];
      var key = colorKey(r, g, b, a);
      var entry = map[key];
      if (entry) {
        entry.count++;
      } else {
        entry = { r: r, g: g, b: b, a: a, count: 1 };
        map[key] = entry;
        colors.push(entry);
      }
    }
    return colors;
  }

  /**
   * Compute the per-channel range (max - min) for every colour inside a box.
   * @return {Array<number>} [rRange, gRange, bRange, aRange]
   */
  function boxRanges(box) {
    var rMin = 255, rMax = 0;
    var gMin = 255, gMax = 0;
    var bMin = 255, bMax = 0;
    var aMin = 255, aMax = 0;
    var i, c;
    for (i = 0; i < box.length; i++) {
      c = box[i];
      if (c.r < rMin) rMin = c.r;
      if (c.r > rMax) rMax = c.r;
      if (c.g < gMin) gMin = c.g;
      if (c.g > gMax) gMax = c.g;
      if (c.b < bMin) bMin = c.b;
      if (c.b > bMax) bMax = c.b;
      if (c.a < aMin) aMin = c.a;
      if (c.a > aMax) aMax = c.a;
    }
    return [rMax - rMin, gMax - gMin, bMax - bMin, aMax - aMin];
  }

  /**
   * Classic median-cut quantisation.
   *
   * Starts with a single box holding every colour and repeatedly splits the
   * box that has the largest single-channel range along that channel's
   * (population weighted) median, until `maxColors` boxes exist or no box can
   * be split any further.
   *
   * @param {Array<Object>} colors    output of collectUniqueColors
   * @param {number} maxColors        desired number of boxes
   * @return {Array<Array<Object>>}   list of boxes (each box = list of colours)
   */
  function medianCut(colors, maxColors) {
    // Each box is an array of colour entries; start with one big box.
    var boxes = [colors.slice(0)];
    var safety = maxColors * 4 + 16;

    while (boxes.length < maxColors && safety-- > 0) {
      // Pick the splittable box with the largest channel range.
      var bestIdx = -1;
      var bestRange = -1;
      var bestChannel = 0;
      var bi, ranges, ch, maxR;
      for (bi = 0; bi < boxes.length; bi++) {
        var box = boxes[bi];
        if (box.length < 2) {
          continue;
        }
        ranges = boxRanges(box);
        ch = 0;
        maxR = ranges[0];
        if (ranges[1] > maxR) { maxR = ranges[1]; ch = 1; }
        if (ranges[2] > maxR) { maxR = ranges[2]; ch = 2; }
        if (ranges[3] > maxR) { maxR = ranges[3]; ch = 3; }
        if (maxR > bestRange) {
          bestRange = maxR;
          bestIdx = bi;
          bestChannel = ch;
        }
      }

      // Nothing left to split.
      if (bestIdx === -1) {
        break;
      }

      var target = boxes[bestIdx];
      var sortCh = bestChannel;

      // Sort the box by the chosen channel (ascending).
      target.sort(function (x, y) {
        var xv, yv;
        if (sortCh === 0) { xv = x.r; yv = y.r; }
        else if (sortCh === 1) { xv = x.g; yv = y.g; }
        else if (sortCh === 2) { xv = x.b; yv = y.b; }
        else { xv = x.a; yv = y.a; }
      });

      // Find a population-weighted median so both halves carry a similar
      // number of pixels.
      var total = 0;
      var k;
      for (k = 0; k < target.length; k++) {
        total += target[k].count;
      }
      var half = total / 2;
      var cum = 0;
      var splitIdx = target.length - 1; // sensible fallback
      for (k = 0; k < target.length; k++) {
        cum += target[k].count;
        if (cum >= half) {
          splitIdx = k + 1;
          break;
        }
      }
      // Guard against empty halves.
      if (splitIdx < 1) {
        splitIdx = 1;
      }
      if (splitIdx >= target.length) {
        splitIdx = target.length - 1;
      }

      var box1 = target.slice(0, splitIdx);
      var box2 = target.slice(splitIdx);
      boxes.splice(bestIdx, 1, box1, box2);
    }

    return boxes;
  }

  /**
   * Quantise an RGBA image down to at most `maxColors` colours using the
   * median-cut algorithm.
   *
   * If the image already contains <= maxColors unique colours the palette is
   * simply the set of those colours and every pixel keeps its exact colour.
   *
   * @param {Object} imageData   {width, height, data: RGBA buffer}
   * @param {number} maxColors   maximum palette size (e.g. 256)
   * @return {Object} {palette: Array<[r,g,b,a]>, indices: Uint8Array}
   */
  function quantizeColors(imageData, maxColors) {
    var data = imageData.data;
    var width = imageData.width;
    var height = imageData.height;
    var pixelCount = width * height;

    var colors = collectUniqueColors(data);
    var boxes;
    if (colors.length <= maxColors) {
      // No compression needed: one box per unique colour.
      boxes = [];
      var i;
      for (i = 0; i < colors.length; i++) {
        boxes.push([colors[i]]);
      }
    } else {
      boxes = medianCut(colors, maxColors);
    }

    // Build the palette (box average) and a colour -> palette-index map.
    var palette = [];
    var colorToIndex = {};
    var bi, k, c;
    for (bi = 0; bi < boxes.length; bi++) {
      var box = boxes[bi];
      var tr = 0, tg = 0, tb = 0, ta = 0, tc = 0;
      for (k = 0; k < box.length; k++) {
        c = box[k];
        tr += c.r * c.count;
        tg += c.g * c.count;
        tb += c.b * c.count;
        ta += c.a * c.count;
        tc += c.count;
      }
      var pr, pg, pb, pa;
      if (tc > 0) {
        pr = Math.round(tr / tc);
        pg = Math.round(tg / tc);
        pb = Math.round(tb / tc);
        pa = Math.round(ta / tc);
      } else {
        pr = 0; pg = 0; pb = 0; pa = 255;
      }
      palette.push([pr, pg, pb, pa]);
      for (k = 0; k < box.length; k++) {
        c = box[k];
        colorToIndex[colorKey(c.r, c.g, c.b, c.a)] = bi;
      }
    }

    // Map every pixel to its palette index.
    var indices = new Uint8Array(pixelCount);
    var p = 0;
    var i2;
    for (i2 = 0; i2 < data.length; i2 += 4) {
      var key = colorKey(data[i2], data[i2 + 1], data[i2 + 2], data[i2 + 3]);
      var idx = colorToIndex[key];
      indices[p++] = (idx === undefined) ? 0 : idx;
    }

    return { palette: palette, indices: indices };
  }

  // ===========================================================================
  // RLE compression (used by TGA-RLP, data type 9)
  // ===========================================================================

  /**
   * Run-length encode a stream of palette indices using standard TGA RLE.
   *
   * Packet format (identical to zmake's output):
   *   - Run-length packet: header byte has bit 7 set.
   *       header = 0x80 | (count - 1)   (count is 1..128)
   *       followed by a single index byte, repeated `count` times.
   *   - Literal packet:    header byte has bit 7 clear.
   *       header = count - 1            (count is 1..128)
   *       followed by `count` index bytes.
   *
   * @param {Uint8Array} indices
   * @return {Uint8Array} compressed bytes
   */
  function rleEncodeIndices(indices) {
    var out = [];
    var n = indices.length;
    var i = 0;
    while (i < n) {
      // Measure the run of identical consecutive indices.
      var run = 1;
      while (i + run < n && indices[i + run] === indices[i] && run < RLE_MAX_RUN) {
        run++;
      }

      if (run >= 2) {
        // Emit a run-length packet.
        out.push(0x80 | (run - 1));
        out.push(indices[i]);
        i += run;
      } else {
        // Emit a literal packet. Gather pixels until a run of >= 2 begins
        // or the 128-pixel packet limit is reached.
        var litStart = i;
        var litCount = 1;
        i++;
        while (i < n && litCount < RLE_MAX_RUN) {
          // Stop just before a potential run so it can be packed efficiently.
          if (i + 1 < n && indices[i] === indices[i + 1]) {
            break;
          }
          litCount++;
          i++;
        }
        out.push(litCount - 1);
        for (var j = 0; j < litCount; j++) {
          out.push(indices[litStart + j]);
        }
      }
    }
    return new Uint8Array(out);
  }

  // ===========================================================================
  // Image-data helpers
  // ===========================================================================

  /**
   * Pad an RGBA buffer on the right so its row width becomes `dstWidth`.
   * The newly added pixels are transparent black (0,0,0,0), exactly like
   * PIL's `Image.new("RGBA", ...)` used by zmake.
   *
   * @param {Uint8ClampedArray|Uint8Array} src
   * @param {number} srcWidth
   * @param {number} height
   * @param {number} dstWidth
   * @return {Uint8ClampedArray}
   */
  function padImageDataRGBA(src, srcWidth, height, dstWidth) {
    var dst = new Uint8ClampedArray(dstWidth * height * 4);
    var rowBytes = srcWidth * 4;
    var y;
    for (y = 0; y < height; y++) {
      var srcOff = y * srcWidth * 4;
      var dstOff = y * dstWidth * 4;
      dst.set(src.subarray(srcOff, srcOff + rowBytes), dstOff);
    }
    return dst;
  }

  /**
   * Serialise the palette into a 256*4 byte table.
   * Channel order is BGRA for "dialog" and RGBA for "nxp".
   * Unused entries are filled with opaque black.
   *
   * @param {Array<Array<number>>} palette  list of [r,g,b,a]
   * @param {string} encodeMode             "dialog" | "nxp"
   * @return {Uint8Array} 1024 bytes
   */
  function buildPaletteBytes(palette, encodeMode) {
    var out = new Uint8Array(PALETTE_ENTRIES * 4);
    var count = palette.length;
    if (count > PALETTE_ENTRIES) {
      count = PALETTE_ENTRIES;
    }
    var i, c, base;
    for (i = 0; i < count; i++) {
      c = palette[i];
      base = i * 4;
      if (encodeMode === "nxp") {
        out[base] = c[0];     // R
        out[base + 1] = c[1]; // G
        out[base + 2] = c[2]; // B
        out[base + 3] = c[3]; // A
      } else {
        out[base] = c[2];     // B
        out[base + 1] = c[1]; // G
        out[base + 2] = c[0]; // R
        out[base + 3] = c[3]; // A
      }
    }
    // Pad the remaining slots with opaque black.
    for (i = count; i < PALETTE_ENTRIES; i++) {
      base = i * 4;
      out[base] = PALETTE_PAD[0];
      out[base + 1] = PALETTE_PAD[1];
      out[base + 2] = PALETTE_PAD[2];
      out[base + 3] = PALETTE_PAD[3];
    }
    return out;
  }

  /**
   * Encode RGBA pixels into 16-bit RGB565 (2 bytes per pixel, little-endian).
   *
   * For every pixel:
   *   r5 = round(31/255 * r)
   *   g6 = round(63/255 * g)
   *   b5 = round(31/255 * b)
   *   byte0 = ((g6 & 0x07) << 5) | b5
   *   byte1 = (r5 << 3) | (g6 >> 3)
   *
   * @param {Uint8ClampedArray|Uint8Array} data
   * @param {number} pixelCount
   * @return {Uint8Array}
   */
  function encodeTruecolor16(data, pixelCount) {
    var out = new Uint8Array(pixelCount * 2);
    var i, j;
    for (i = 0, j = 0; i < pixelCount; i++, j += 2) {
      var r = data[i * 4];
      var g = data[i * 4 + 1];
      var b = data[i * 4 + 2];
      var r5 = Math.round((31 / 255) * r);
      var g6 = Math.round((63 / 255) * g);
      var b5 = Math.round((31 / 255) * b);
      out[j] = ((g6 & 0x07) << 5) + b5;
      out[j + 1] = (r5 << 3) + (g6 >> 3);
    }
    return out;
  }

  /**
   * Encode RGBA pixels into 32-bit BGRA (4 bytes per pixel).
   * Channel order is always B, G, R, A regardless of encode mode, matching
   * zmake's `save_truecolor_tga` for depth == 32.
   *
   * @param {Uint8ClampedArray|Uint8Array} data
   * @param {number} pixelCount
   * @return {Uint8Array}
   */
  function encodeTruecolor32(data, pixelCount) {
    var out = new Uint8Array(pixelCount * 4);
    var i, j;
    for (i = 0, j = 0; i < pixelCount; i++, j += 4) {
      out[j] = data[i * 4 + 2];     // B
      out[j + 1] = data[i * 4 + 1]; // G
      out[j + 2] = data[i * 4];     // R
      out[j + 3] = data[i * 4 + 3]; // A
    }
    return out;
  }

  // ===========================================================================
  // Main entry point
  // ===========================================================================

  /**
   * Encode Canvas ImageData into a ZeppOS TGA ArrayBuffer.
   *
   * @param {Object} imageData   {width, height, data: Uint8ClampedArray RGBA}
   * @param {string} format      "P" | "RLP" | "16" | "32"
   * @param {string} encodeMode  "dialog" | "nxp"
   * @return {ArrayBuffer}
   */
  function encodeTGA(imageData, format, encodeMode) {
    if (!imageData || !imageData.data) {
      throw new Error("encodeTGA: imageData is required");
    }
    format = format || "P";
    encodeMode = encodeMode || "dialog";

    var realWidth = imageData.width;
    var height = imageData.height;

    // For "nxp" the stored width must be a multiple of 16. The original
    // (un-padded) width is preserved in the ID section as "real width".
    var tgaWidth = realWidth;
    var srcData = imageData.data;
    if (encodeMode === "nxp" && realWidth % 16 !== 0) {
      tgaWidth = realWidth + (16 - (realWidth % 16));
      srcData = padImageDataRGBA(imageData.data, realWidth, height, tgaWidth);
    }

    var pixelCount = tgaWidth * height;

    // Resolve the per-format header fields and produce the payload bytes.
    var paletteBytes = null; // Uint8Array (palette modes only)
    var pixelBytes = null;   // Uint8Array (indices or truecolour data)
    var hasColormap = 0;     // byte 1
    var dataType = 2;        // byte 2
    var colorDepth = 16;     // byte 16

    if (format === "P" || format === "RLP") {
      var quant = quantizeColors(
        { width: tgaWidth, height: height, data: srcData },
        PALETTE_ENTRIES
      );

      paletteBytes = buildPaletteBytes(quant.palette, encodeMode);

      if (format === "RLP") {
        pixelBytes = rleEncodeIndices(quant.indices);
        dataType = 9;
      } else {
        // TGA-P: raw index stream, one byte per pixel.
        pixelBytes = quant.indices;
        dataType = 1;
      }
      hasColormap = 1;
      colorDepth = 8;

    } else if (format === "16") {
      pixelBytes = encodeTruecolor16(srcData, pixelCount);
      hasColormap = 0;
      dataType = 2;
      colorDepth = 16;

    } else if (format === "32") {
      pixelBytes = encodeTruecolor32(srcData, pixelCount);
      hasColormap = 0;
      dataType = 2;
      colorDepth = 32;

    } else {
      throw new Error("encodeTGA: unknown format '" + format + "'");
    }

    // ----- Assemble the final buffer ----------------------------------------
    var paletteLen = paletteBytes ? paletteBytes.length : 0;
    var total = HEADER_SIZE + paletteLen + pixelBytes.length;
    var out = new Uint8Array(total);
    var dv = new DataView(out.buffer);

    // 18-byte TGA header.
    out[0] = 46;                 // ID length (ZeppOS always uses 46)
    out[1] = hasColormap;        // colour-map flag
    out[2] = dataType;           // data type (1, 2 or 9)

    if (paletteBytes) {
      dv.setUint16(3, 0, true);              // colour-map origin (LE)
      dv.setUint16(5, PALETTE_ENTRIES, true);// colour-map length = 256 (LE)
      out[7] = 32;                           // colour-map entry bit depth
    } else {
      dv.setUint16(3, 0, true);              // no colour map
      dv.setUint16(5, 0, true);
      out[7] = 0;
    }

    dv.setUint16(8, 0, true);   // X origin
    dv.setUint16(10, 0, true);  // Y origin
    dv.setUint16(12, tgaWidth, true); // width (LE)
    dv.setUint16(14, height, true);   // height (LE)
    out[16] = colorDepth;       // pixel bit depth
    out[17] = 32;               // image descriptor

    // 46-byte ID section (offset 18..63).
    out[18] = ID_MAGIC[0]; // 'S'
    out[19] = ID_MAGIC[1]; // 'O'
    out[20] = ID_MAGIC[2]; // 'M'
    out[21] = ID_MAGIC[3]; // 'H'
    dv.setUint16(22, realWidth, true); // real (un-padded) width (LE)
    // Bytes 24..63 stay zero (already initialised by Uint8Array).

    // Append palette (if any) and pixel data.
    var offset = HEADER_SIZE;
    if (paletteBytes) {
      out.set(paletteBytes, offset);
      offset += paletteLen;
    }
    out.set(pixelBytes, offset);

    return out.buffer;
  }

  // ===========================================================================
  // TGA 解码器（将 ZeppOS TGA 解码为 ImageData）
  // ===========================================================================

  /**
   * RLE 解码：将 TGA RLE 压缩的索引流还原为逐像素索引数组。
   *
   * @param {Uint8Array} data  RLE 压缩数据
   * @param {number} pixelCount  总像素数
   * @return {Uint8Array} 解码后的索引数组
   */
  function rleDecodeIndices(data, pixelCount) {
    var out = new Uint8Array(pixelCount);
    var pos = 0;
    var i = 0;
    while (i < data.length && pos < pixelCount) {
      var header = data[i++];
      var count = (header & 0x7F) + 1;
      if (header & 0x80) {
        // Run-length packet: 1 index byte repeated `count` times
        var idx = data[i++];
        for (var j = 0; j < count && pos < pixelCount; j++) {
          out[pos++] = idx;
        }
      } else {
        // Literal packet: `count` index bytes
        for (var k = 0; k < count && pos < pixelCount; k++) {
          out[pos++] = data[i++];
        }
      }
    }
    return out;
  }

  /**
   * 将 ZeppOS TGA ArrayBuffer 解码为 ImageData 兼容对象。
   *
   * @param {ArrayBuffer} buffer  TGA 文件数据
   * @return {Object} { width, height, data: Uint8ClampedArray, format }
   */
  function decodeTGA(buffer) {
    var bytes = new Uint8Array(buffer);
    var dv = new DataView(buffer);

    if (bytes.length < 64) {
      throw new Error("TGA 文件过小（< 64 字节）");
    }

    // 18-byte TGA header
    var idLength = bytes[0];
    var hasColormap = bytes[1];
    var dataType = bytes[2];
    var colorDepth = bytes[16];

    var tgaWidth = dv.getUint16(12, true);
    var tgaHeight = dv.getUint16(14, true);

    // ID section（46 字节，从 offset 18 开始）
    // "SOMH" magic at 18-21, real width at 22-23
    var realWidth = tgaWidth;
    if (idLength >= 6) {
      var magic = String.fromCharCode(bytes[18], bytes[19], bytes[20], bytes[21]);
      if (magic === "SOMH") {
        realWidth = dv.getUint16(22, true);
      }
    }

    var format;
    if (dataType === 1) format = "P";
    else if (dataType === 9) format = "RLP";
    else if (dataType === 2 && colorDepth === 16) format = "16";
    else if (dataType === 2 && colorDepth === 32) format = "32";
    else throw new Error("不支持的 TGA 格式 (dataType=" + dataType + ", depth=" + colorDepth + ")");

    var pixelCount = tgaWidth * tgaHeight;
    var dataOffset = 18 + idLength; // header + ID section

    var rgba = new Uint8ClampedArray(realWidth * tgaHeight * 4);

    if (format === "P" || format === "RLP") {
      // 调色板模式：先读 256 色调色板（1024 字节）
      var paletteSize = PALETTE_ENTRIES * 4;
      var paletteOffset = dataOffset;
      var pixelDataOffset = paletteOffset + paletteSize;

      // 检测编码模式：dialog (BGRA) or nxp (RGBA)
      // 无法从文件确定，默认按 dialog 解码
      var palette = [];
      for (var pi = 0; pi < PALETTE_ENTRIES; pi++) {
        var base = paletteOffset + pi * 4;
        // 默认 dialog 模式：BGRA
        var b = bytes[base];
        var g = bytes[base + 1];
        var r = bytes[base + 2];
        var a = bytes[base + 3];
        palette.push([r, g, b, a]);
      }

      // 解码像素索引
      var indices;
      if (format === "RLP") {
        var rleData = bytes.subarray(pixelDataOffset);
        indices = rleDecodeIndices(rleData, pixelCount);
      } else {
        indices = bytes.subarray(pixelDataOffset, pixelDataOffset + pixelCount);
      }

      // 将索引映射为 RGBA，处理 nxp 宽度填充
      for (var y = 0; y < tgaHeight; y++) {
        for (var x = 0; x < realWidth; x++) {
          var srcIdx = y * tgaWidth + x;
          var dstIdx = (y * realWidth + x) * 4;
          var color = palette[indices[srcIdx]] || [0, 0, 0, 255];
          rgba[dstIdx] = color[0];
          rgba[dstIdx + 1] = color[1];
          rgba[dstIdx + 2] = color[2];
          rgba[dstIdx + 3] = color[3];
        }
      }

    } else if (format === "16") {
      // RGB565: 2 bytes per pixel, little-endian
      for (var y2 = 0; y2 < tgaHeight; y2++) {
        for (var x2 = 0; x2 < realWidth; x2++) {
          var srcIdx2 = (y2 * tgaWidth + x2) * 2;
          var lo = bytes[srcIdx2];
          var hi = bytes[srcIdx2 + 1];
          var val = lo | (hi << 8);
          var r5 = (val >> 11) & 0x1F;
          var g6 = (val >> 5) & 0x3F;
          var b5 = val & 0x1F;
          var dstIdx2 = (y2 * realWidth + x2) * 4;
          rgba[dstIdx2] = Math.round((r5 / 31) * 255);
          rgba[dstIdx2 + 1] = Math.round((g6 / 63) * 255);
          rgba[dstIdx2 + 2] = Math.round((b5 / 31) * 255);
          rgba[dstIdx2 + 3] = 255;
        }
      }

    } else if (format === "32") {
      // BGRA: 4 bytes per pixel
      for (var y3 = 0; y3 < tgaHeight; y3++) {
        for (var x3 = 0; x3 < realWidth; x3++) {
          var srcIdx3 = (y3 * tgaWidth + x3) * 4;
          var dstIdx3 = (y3 * realWidth + x3) * 4;
          rgba[dstIdx3] = bytes[srcIdx3 + 2];     // R
          rgba[dstIdx3 + 1] = bytes[srcIdx3 + 1]; // G
          rgba[dstIdx3 + 2] = bytes[srcIdx3];     // B
          rgba[dstIdx3 + 3] = bytes[srcIdx3 + 3]; // A
        }
      }
    }

    return {
      width: realWidth,
      height: tgaHeight,
      data: rgba,
      format: format,
      tgaWidth: tgaWidth,
      tgaHeight: tgaHeight,
      dataType: dataType,
      colorDepth: colorDepth
    };
  }

  // ===========================================================================
  // Public API
  // ===========================================================================

  return {
    encodeTGA: encodeTGA,
    decodeTGA: decodeTGA,
    quantizeColors: quantizeColors,
    getFormatFromFilename: getFormatFromFilename
  };
});
