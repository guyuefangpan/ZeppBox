/**
 * quickjs-compiler.js - 浏览器兼容的 QuickJS 字节码编译器
 * -----------------------------------------------------------------------------
 * 将 quickjs-wasm 的 ES 模块转换为 UMD 格式，使其可以在浏览器和 WebView 中
 * 通过 <script> 标签加载。
 *
 * 用法：
 *   <script src="quickjs-compiler.js"></script>
 *   <script>
 *     const quickjs = await createQuickJS();
 *     const bytecode = quickjs.compileToByteCode(jsCode, "index.js");
 *   </script>
 * -----------------------------------------------------------------------------
 */

(function (root, factory) {
  "use strict";
  if (typeof module === "object" && module !== null && typeof module.exports === "object") {
    module.exports = factory(root);
  } else {
    root.createQuickJS = factory(root);
  }
})(typeof window !== "undefined" ? window : (typeof self !== "undefined" ? self : this), function (root) {
  "use strict";

  // ===========================================================================
  // WASI 实现（从 wasi.js 移植）
  // ===========================================================================

  var WASI_ESUCCESS = 0;
  var WASI_ERRNO_BADF = 8;

  var WASI_FILETYPE_CHARACTER_DEVICE = 2;

  var WASI_FDFLAGS_APPEND = 1;

  var WASI_RIGHTS_FD_WRITE = 64n;

  var STDOUT = 1;
  var STDERR = 2;

  function drainWriter(write, prev, current) {
    var text = prev + current;
    while (text.indexOf("\n") !== -1) {
      var idx = text.indexOf("\n");
      var line = text.substring(0, idx);
      var rest = text.substring(idx + 1);
      write(line);
      text = rest;
    }
    return text;
  }

  function WasiMemoryManager(memory, malloc, free) {
    this.memory = memory;
    this.malloc = malloc;
    this.free = free;
  }

  WasiMemoryManager.prototype.convertToString = function (ptr, length) {
    try {
      var array = new Uint8Array(this.memory.buffer, ptr, length);
      var decoder = new TextDecoder();
      return decoder.decode(array);
    } finally {
      this.free(ptr);
    }
  };

  WasiMemoryManager.prototype.convertFromString = function (string) {
    var encoder = new TextEncoder();
    var bytes = encoder.encode(string);
    var ptr = this.malloc(bytes.byteLength);
    var buffer = new Uint8Array(this.memory.buffer, ptr, bytes.byteLength + 1);
    buffer.set(bytes);
    return buffer;
  };

  function Wasi(env) {
    this.env = env;
    this.instance = null;
    this.wasiMemoryManager = null;
    this.stdoutText = "";
    this.stderrText = "";
    this.stdout = function () {};
    this.stderr = function () {};
  }

  Wasi.prototype.init = function (instance) {
    this.instance = instance;
    this.wasiMemoryManager = new WasiMemoryManager(
      instance.exports.memory,
      instance.exports.malloc,
      instance.exports.free
    );
  };

  Wasi.prototype.environ_get = function (environ, environBuf) {
    var encoder = new TextEncoder();
    var view = new DataView(this.wasiMemoryManager.memory.buffer);
    var environBufPos = environBuf;

    var keys = Object.keys(this.env);
    for (var i = 0; i < keys.length; i++) {
      var envVar = keys[i] + "=" + this.env[keys[i]];
      view.setUint32(environ + i * 4, environBufPos, true);
      var bytes = encoder.encode(envVar);
      var buf = new Uint8Array(
        this.wasiMemoryManager.memory.buffer,
        environBufPos,
        bytes.length + 1
      );
      buf.set(bytes);
      environBufPos += buf.byteLength;
    }
    return WASI_ESUCCESS;
  };

  Wasi.prototype.environ_sizes_get = function (environCount, environBufSize) {
    var encoder = new TextEncoder();
    var view = new DataView(this.wasiMemoryManager.memory.buffer);

    var keys = Object.keys(this.env);
    var size = 0;
    for (var i = 0; i < keys.length; i++) {
      var envVar = keys[i] + "=" + this.env[keys[i]];
      size += encoder.encode(envVar).byteLength + 1;
    }
    view.setUint32(environCount, keys.length, true);
    view.setUint32(environBufSize, size, true);
    return WASI_ESUCCESS;
  };

  Wasi.prototype.proc_exit = function (rval) {
    return WASI_ESUCCESS;
  };

  Wasi.prototype.fd_close = function (fd) {
    return WASI_ESUCCESS;
  };

  Wasi.prototype.fd_seek = function (fd, offset_low, offset_high, whence, newOffset) {
    return WASI_ESUCCESS;
  };

  Wasi.prototype.fd_write = function (fd, iovs, iovsLen, nwritten) {
    if (!((fd === 1) || (fd === 2))) {
      return WASI_ERRNO_BADF;
    }

    var view = new DataView(this.wasiMemoryManager.memory.buffer);
    var buffers = [];
    for (var i = 0; i < iovsLen; i++) {
      var ptr = iovs + i * 8;
      var buf = view.getUint32(ptr, true);
      var bufLen = view.getUint32(ptr + 4, true);
      buffers.push(new Uint8Array(this.wasiMemoryManager.memory.buffer, buf, bufLen));
    }

    var textDecoder = new TextDecoder();
    var written = 0;
    var text = "";
    for (var j = 0; j < buffers.length; j++) {
      text += textDecoder.decode(buffers[j]);
      written += buffers[j].byteLength;
    }
    view.setUint32(nwritten, written, true);

    if (fd === STDOUT) {
      this.stdoutText = drainWriter(this.stdout, this.stdoutText, text);
    } else if (fd === STDERR) {
      this.stderrText = drainWriter(this.stderr, this.stderrText, text);
    }

    return WASI_ESUCCESS;
  };

  Wasi.prototype.random_get = function () {
    return 0;
  };

  Wasi.prototype.fd_fdstat_get = function (fd, stat) {
    if (!((fd === 1) || (fd === 2))) {
      return WASI_ERRNO_BADF;
    }

    var view = new DataView(this.wasiMemoryManager.memory.buffer);
    view.setUint8(stat + 0, WASI_FILETYPE_CHARACTER_DEVICE);
    view.setUint32(stat + 2, WASI_FDFLAGS_APPEND, true);
    view.setBigUint64(stat + 8, WASI_RIGHTS_FD_WRITE, true);
    view.setBigUint64(stat + 16, WASI_RIGHTS_FD_WRITE, true);
    return WASI_ESUCCESS;
  };

  Wasi.prototype.clock_time_get = function (a) {
    // no-op
  };

  // ===========================================================================
  // QuickJS 实现（从 quickjs.js 移植）
  // ===========================================================================

  /* Tag values from quickjs.h */
  var JS_TAG_FIRST = -9;
  var JS_TAG_STRING = -7;
  var JS_TAG_STRING_ROPE = -6;
  var JS_TAG_OBJECT = -1;

  var JS_TAG_INT = 0;
  var JS_TAG_BOOL = 1;
  var JS_TAG_NULL = 2;
  var JS_TAG_UNDEFINED = 3;
  var JS_TAG_EXCEPTION = 6;
  var JS_TAG_FLOAT64 = 8;

  var JS_FLOAT64_TAG_ADDEND = BigInt(0x7ff80000 - JS_TAG_FIRST + 1);

  var float64scratch = new DataView(new ArrayBuffer(8));
  var textEncoder = new TextEncoder();
  var textDecoder = new TextDecoder();

  /* The compiled module is fetched and compiled once and then shared by every
     instance. */
  var compiledModulePromise = null;

  function getCompiledModule() {
    if (!compiledModulePromise) {
      compiledModulePromise = (async function () {
        // 在浏览器/WebView 中，WASM 文件相对于 HTML 页面加载
        var wasmUrl = "jseval.wasm";
        // 如果配置了自定义路径，使用它
        if (root._quickjsWasmUrl) {
          wasmUrl = root._quickjsWasmUrl;
        }
        var wasm = await fetch(wasmUrl).then(function (r) {
          return r.arrayBuffer();
        });
        return await WebAssembly.compile(wasm);
      })().catch(function (e) {
        compiledModulePromise = null;
        throw e;
      });
    }
    return compiledModulePromise;
  }

  function QuickJS() {
    this.hostFunctions = {};
    this.pendingAsyncInvocations = [];

    var self = this;

    this.wasmInstancePromise = (async function () {
      self.wasi = new Wasi({
        LANG: "en_GB.UTF-8",
        TERM: "xterm"
      });
      self.stdoutlines = [];
      self.stderrlines = [];
      self.wasi.stdout = function () {
        var args = Array.prototype.slice.call(arguments);
        self.stdoutlines.push(args.join(" "));
      };
      self.wasi.stderr = function () {
        var args = Array.prototype.slice.call(arguments);
        self.stderrlines.push(args.join(" "));
      };

      var mod = await WebAssembly.instantiate(await getCompiledModule(), {
        wasi_snapshot_preview1: self.wasi,
        env: {
          js_host_time_ms: function () {
            return Date.now();
          },
          js_call_host_async: async function (params, resolving_func) {
            self.pendingAsyncInvocations.push(
              new Promise(async function (resolvePendingInvocation) {
                try {
                  var hostFunctionName = self.getObjectPropertyValue(params, "function_name");
                  if (self.hostFunctions[hostFunctionName]) {
                    var result = await self.hostFunctions[hostFunctionName](params);
                    self.wasmInstance.promise_callback(resolving_func, result);
                  } else {
                    self.wasmInstance.promise_callback(resolving_func, null);
                  }
                } finally {
                  resolvePendingInvocation();
                }
              })
            );
          }
        }
      });

      self.wasi.init(mod);
      self.wasmInstance = mod.exports;
      self.wasmInstance.init();
      return mod.exports;
    })();
  }

  QuickJS.prototype.allocateString = function (str) {
    var instance = this.wasmInstance;
    var encoded = textEncoder.encode(str);
    var straddr = this.checkAllocation(
      instance.malloc(encoded.length + 1),
      encoded.length + 1
    );
    var buf = new Uint8Array(instance.memory.buffer, straddr, encoded.length + 1);
    buf.set(encoded);
    buf[encoded.length] = 0;
    return straddr;
  };

  QuickJS.prototype.allocateJSstring = function (str) {
    var strPtr = this.allocateString(str);
    var jsString = this.wasmInstance.new_js_string(strPtr);
    this.wasmInstance.free(strPtr);
    return jsString;
  };

  QuickJS.prototype.ptrToString = function (ptr) {
    var memorybuf = new Uint8Array(this.wasmInstance.memory.buffer);
    var end = memorybuf.indexOf(0, ptr);
    return textDecoder.decode(memorybuf.subarray(ptr, end));
  };

  QuickJS.prototype.withStrings = function (strings, fn) {
    var self = this;
    var ptrs = strings.map(function (str) {
      return self.allocateString(str);
    });
    try {
      return fn.apply(null, ptrs);
    } finally {
      for (var i = 0; i < ptrs.length; i++) {
        self.wasmInstance.free(ptrs[i]);
      }
    }
  };

  QuickJS.prototype.withBuf = function (binarydata, fn) {
    var allocated = this.allocateBuf(binarydata);
    try {
      return fn(allocated.addr, allocated.len);
    } finally {
      this.wasmInstance.free(allocated.addr);
    }
  };

  QuickJS.prototype.setMemoryLimit = function (bytes) {
    this.wasmInstance.set_memory_limit(bytes);
  };

  QuickJS.prototype.requestInterrupt = function () {
    this.wasmInstance.request_interrupt();
  };

  QuickJS.prototype.withEvalDeadline = function (timeoutMs, fn) {
    if (!timeoutMs) {
      return fn();
    }
    this.wasmInstance.set_eval_deadline(Date.now() + timeoutMs);
    try {
      return fn();
    } finally {
      this.wasmInstance.clear_interrupt();
    }
  };

  QuickJS.prototype.evalSource = function (src, modulefilename, timeoutMs) {
    modulefilename = modulefilename || "<evalsource>";
    timeoutMs = timeoutMs || 0;
    var instance = this.wasmInstance;
    var self = this;
    return this.withEvalDeadline(timeoutMs, function () {
      return self.withStrings([modulefilename, src], function (filenameptr, srcptr) {
        return self.convertReturnValue(
          instance.eval_js_source(filenameptr, srcptr, modulefilename !== "<evalsource>")
        );
      });
    });
  };

  QuickJS.prototype.getObjectPropertyValue = function (jsval, propertyname) {
    var self = this;
    return this.withStrings([propertyname], function (nameptr) {
      return self.convertReturnValue(
        self.wasmInstance.get_js_obj_property(jsval, nameptr)
      );
    });
  };

  QuickJS.prototype.getPromiseResult = function (jsval) {
    return this.convertReturnValue(this.wasmInstance.get_promise_result(jsval));
  };

  QuickJS.prototype.waitForPendingAsyncInvocations = async function () {
    while (this.pendingAsyncInvocations.length > 0) {
      var pending = this.pendingAsyncInvocations.slice();
      this.pendingAsyncInvocations = [];
      await Promise.all(pending);
    }
  };

  QuickJS.prototype.convertReturnValue = function (jsval) {
    var tag = Number(jsval >> 32n);
    if ((tag - JS_TAG_FIRST) >>> 0 >= JS_TAG_FLOAT64 - JS_TAG_FIRST) {
      float64scratch.setBigUint64(0, BigInt.asUintN(64, jsval + (JS_FLOAT64_TAG_ADDEND << 32n)));
      return float64scratch.getFloat64(0);
    }
    switch (tag) {
      case JS_TAG_INT:
        return Number(BigInt.asIntN(32, jsval));
      case JS_TAG_BOOL:
        return BigInt.asIntN(32, jsval) !== 0n;
      case JS_TAG_STRING:
      case JS_TAG_STRING_ROPE: {
        var strptr = this.wasmInstance.get_js_string(jsval);
        try {
          return this.ptrToString(strptr);
        } finally {
          this.wasmInstance.free_js_string(strptr);
          this.wasmInstance.free_js_value(jsval);
        }
      }
      case JS_TAG_OBJECT:
        return jsval;
      case JS_TAG_NULL:
        return null;
      case JS_TAG_UNDEFINED:
        return undefined;
      case JS_TAG_EXCEPTION:
        throw new Error(
          this.stdoutlines[this.stdoutlines.length - 1] || "Exception in QuickJS"
        );
    }
  };

  QuickJS.prototype.freeValue = function (handle) {
    if (typeof handle === "bigint") {
      this.wasmInstance.free_js_value(handle);
    }
  };

  QuickJS.prototype.checkAllocation = function (addr, size) {
    if (addr === 0) {
      throw new Error("QuickJS sandbox out of memory: could not allocate " + size + " bytes");
    }
    return addr;
  };

  QuickJS.prototype.allocateBuf = function (binarydata) {
    var instance = this.wasmInstance;
    var bufaddr = this.checkAllocation(
      instance.malloc(binarydata.length),
      binarydata.length
    );
    var buf = new Uint8Array(instance.memory.buffer, bufaddr, binarydata.length);
    for (var n = 0; n < binarydata.length; n++) {
      buf[n] = binarydata[n];
    }
    return { addr: bufaddr, len: buf.length };
  };

  QuickJS.prototype.loadByteCode = function (bytecode) {
    if (!bytecode || bytecode.length === 0) {
      throw new Error("Cannot load empty bytecode");
    }
    var self = this;
    return this.withBuf(bytecode, function (addr, len) {
      return self.wasmInstance.load_js_bytecode(addr, len);
    });
  };

  QuickJS.prototype.callModFunction = function (mod, functionname, timeoutMs) {
    timeoutMs = timeoutMs || 0;
    var self = this;
    return this.withEvalDeadline(timeoutMs, function () {
      return self.withStrings([functionname], function (nameptr) {
        return self.convertReturnValue(
          self.wasmInstance.call_js_function(mod, nameptr)
        );
      });
    });
  };

  QuickJS.prototype.evalByteCode = function (bytecode, timeoutMs) {
    timeoutMs = timeoutMs || 0;
    var self = this;
    return this.withEvalDeadline(timeoutMs, function () {
      return self.withBuf(bytecode, function (addr, len) {
        return self.convertReturnValue(self.wasmInstance.eval_js_bytecode(addr, len));
      });
    });
  };

  /**
   * 将 JavaScript 源代码编译为 QuickJS 字节码。
   *
   * @param {string} src - JavaScript 源代码
   * @param {string} modulefilename - 模块文件名（用于错误信息）
   * @return {Uint8Array} 编译后的字节码
   */
  QuickJS.prototype.compileToByteCode = function (src, modulefilename) {
    modulefilename = modulefilename || "<evalsource>";
    var instance = this.wasmInstance;
    var self = this;
    var buflenptr = instance.malloc(4);
    try {
      return this.withStrings([modulefilename, src], function (filenameptr, srcptr) {
        var bytecodeaddr = instance.compile_to_bytecode(
          filenameptr,
          srcptr,
          buflenptr,
          modulefilename !== "<evalsource>"
        );
        var buflen = new Uint32Array(instance.memory.buffer, buflenptr, 1)[0];

        if (bytecodeaddr === 0 || buflen === 0) {
          throw new Error(
            "Failed to compile " + modulefilename + ": " +
            (self.stdoutlines[self.stdoutlines.length - 1] || "no bytecode produced")
          );
        }
        try {
          return new Uint8Array(instance.memory.buffer, bytecodeaddr, buflen).slice();
        } finally {
          instance.free_js_bytecode(bytecodeaddr);
        }
      });
    } finally {
      instance.free(buflenptr);
    }
  };

  // ===========================================================================
  // 公开 API
  // ===========================================================================

  return async function createQuickJS() {
    var quickjs = new QuickJS();
    await quickjs.wasmInstancePromise;
    return quickjs;
  };
});
