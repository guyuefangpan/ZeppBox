/**
 * app.js - ZeppBox 主应用逻辑
 * 工具盒导航 + 11 个工具实现（仅支持 ZeppOS 1.0）
 */

// 注意：BLE 设备管理/程序安装/应用管理已移除

(function () {
  "use strict";

  // ===========================================================================
  // 工具定义 - 12个工具
  // ===========================================================================

  var ICONS = {
    "icon-converter": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    "tga-preview": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
    "image-crop": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6.13 1L6 16a2 2 0 0 0 2 2h15"/><path d="M1 6.13L16 6a2 2 0 0 1 2 2v15"/></svg>',
    "zepp-api": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="M4 9h16"/><path d="M9 9v11"/><path d="M14 14h6"/><path d="M14 17h4"/></svg>',
    "tga-export": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    "base-converter": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/><text x="12" y="15" text-anchor="middle" font-size="8" fill="currentColor" stroke="none">10</text></svg>',
    "hex-viewer": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    "js-bytecode": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    "app-json-editor": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13h6"/><path d="M9 17h4"/></svg>',
    "js-lint": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    "device-params": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    "code-templates": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    "zmake-build": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
    "ble-manager": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7l10 10-5 5V2l5 5L7 17"/></svg>',
  };

  // 工具图标颜色映射
  var TOOL_COLORS = {
    "zmake-build":     { bg: "rgba(255, 149, 0, 0.12)",  fg: "#ff9500" },
    "icon-converter":  { bg: "rgba(52, 199, 89, 0.12)",  fg: "#34c759" },
    "tga-preview":     { bg: "rgba(255, 59, 48, 0.12)",  fg: "#ff3b30" },
    "image-crop":      { bg: "rgba(175, 82, 222, 0.12)", fg: "#af52de" },
    "zepp-api":        { bg: "rgba(0, 122, 255, 0.12)",  fg: "#007aff" },
    "tga-export":      { bg: "rgba(52, 199, 89, 0.12)",  fg: "#34c759" },
    "base-converter":  { bg: "rgba(255, 149, 0, 0.12)",  fg: "#ff9500" },
    "hex-viewer":      { bg: "rgba(88, 86, 214, 0.12)",  fg: "#5856d6" },
    "js-bytecode":     { bg: "rgba(255, 204, 0, 0.12)",  fg: "#ffcc00" },
    "app-json-editor": { bg: "rgba(90, 200, 250, 0.12)", fg: "#5ac8fa" },
    "js-lint":         { bg: "rgba(52, 199, 89, 0.12)",  fg: "#34c759" },
    "device-params":   { bg: "rgba(255, 55, 95, 0.12)",  fg: "#ff375f" },
    "code-templates":  { bg: "rgba(175, 82, 222, 0.12)", fg: "#af52de" },
    "ble-manager":     { bg: "rgba(0, 122, 255, 0.12)",  fg: "#007aff" },
  };

  var TOOLS = [
    { id: "zmake-build",     name: "ZMake构建",   desc: "项目打包",      tpl: "tpl-zmake-build" },
    { id: "icon-converter",  name: "图标转换",   desc: "图片转TGA",     tpl: "tpl-icon-converter" },
    { id: "tga-preview",     name: "TGA预览",    desc: "查看TGA",       tpl: "tpl-tga-preview" },
    { id: "image-crop",      name: "图片裁剪",   desc: "裁剪缩放",      tpl: "tpl-image-crop" },
    { id: "zepp-api",        name: "API速查",    desc: "ZeppOS 1.0",    tpl: "tpl-zepp-api" },
    { id: "tga-export",      name: "TGA导出",    desc: "TGA转PNG",     tpl: "tpl-tga-export" },
    { id: "base-converter",  name: "进制转换",    desc: "多进制互转",    tpl: "tpl-base-converter" },
    { id: "hex-viewer",      name: "Hex查看",    desc: "十六进制",      tpl: "tpl-hex-viewer" },
    { id: "js-bytecode",     name: "字节码编译",  desc: "JS→二进制",    tpl: "tpl-js-bytecode" },
    { id: "app-json-editor", name: "JSON生成器",  desc: "app.json编辑",  tpl: "tpl-app-json-editor" },
    { id: "js-lint",         name: "JS校验",     desc: "语法检查",      tpl: "tpl-js-lint" },
    { id: "device-params",   name: "设备参数",   desc: "机型速查",      tpl: "tpl-device-params" },
    { id: "code-templates",  name: "代码模板",   desc: "API示例",      tpl: "tpl-code-templates" },
  ];

  // ===========================================================================
  // iOS 液态玻璃 · 弹簧物理引擎
  // 模拟 iOS Dock 的液态拉伸/回弹/过冲效果
  // ===========================================================================

  // ===========================================================================
  // 导航
  // ===========================================================================

  var currentNav = "tools"; // tools, device, settings
  var deviceInitialized = false;

  function updateBottomNav(nav) {
    if (currentNav === nav) return;
    var items = document.querySelectorAll(".bottom-nav-item");
    var navEl = document.getElementById("bottomNav");
    if (!navEl) return;

    var targetItem = null;
    items.forEach(function (item) {
      if (item.getAttribute("data-nav") === nav) {
        item.classList.add("active");
        targetItem = item;
      } else {
        item.classList.remove("active");
      }
    });

    if (!targetItem) return;
    currentNav = nav;

    // 激活项液态玻璃光扫
    requestAnimationFrame(function () {
      targetItem.classList.remove("shimmer");
      void targetItem.offsetWidth;
      targetItem.classList.add("shimmer");
      clearTimeout(targetItem._shimmerTimer);
      targetItem._shimmerTimer = setTimeout(function () {
        targetItem.classList.remove("shimmer");
      }, 750);

      // 导航栏整体光扫
      navEl.classList.remove("nav-shimmer");
      void navEl.offsetWidth;
      navEl.classList.add("nav-shimmer");
      clearTimeout(navEl._shimmerTimer);
      navEl._shimmerTimer = setTimeout(function () {
        navEl.classList.remove("nav-shimmer");
      }, 650);
    });
  }

  function hideAllViews() {
    document.getElementById("view-home").classList.remove("active");
    document.getElementById("view-tool").classList.remove("active");
    document.getElementById("view-about").classList.remove("active");
    document.getElementById("view-device").classList.remove("active");
    document.getElementById("view-settings").classList.remove("active");
  }

  // Miuix 视图切换动画（淡入 + 上移）
  function showViewWithAnimation(viewId) {
    var view = document.getElementById(viewId);
    view.classList.add("active");
    view.style.opacity = "0";
    view.style.transform = "translateY(8px)";
    view.style.transition = "opacity 0.3s cubic-bezier(0.22, 0.61, 0.36, 1), transform 0.3s cubic-bezier(0.22, 0.61, 0.36, 1)";
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        view.style.opacity = "1";
        view.style.transform = "translateY(0)";
      });
    });
    setTimeout(function () {
      view.style.transition = "";
      view.style.transform = "";
    }, 350);
  }

  function navigateTo(toolId) {
    var tool = null;
    for (var i = 0; i < TOOLS.length; i++) {
      if (TOOLS[i].id === toolId) { tool = TOOLS[i]; break; }
    }
    if (!tool) return;

    var toolTitle = document.getElementById("toolTitle");
    var toolContent = document.getElementById("toolContent");

    toolTitle.textContent = tool.name;
    toolContent.innerHTML = "";

    var tpl = document.getElementById(tool.tpl);
    if (tpl) {
      toolContent.appendChild(tpl.content.cloneNode(true));
    }

    hideAllViews();
    showViewWithAnimation("view-tool");
    updateBottomNav("tools");
    window.scrollTo(0, 0);

    setTimeout(function () {
      initTool(toolId);
    }, 0);
  }

  function navigateHome() {
    hideAllViews();
    showViewWithAnimation("view-home");
    updateBottomNav("tools");
    window.scrollTo(0, 0);
  }

  function navigateToDevice() {
    hideAllViews();
    showViewWithAnimation("view-device");
    updateBottomNav("device");
    window.scrollTo(0, 0);

    if (!deviceInitialized) {
      deviceInitialized = true;
      var deviceContent = document.getElementById("deviceContent");
      deviceContent.innerHTML = "";
      var tpl = document.getElementById("tpl-ble-manager");
      if (tpl) {
        deviceContent.appendChild(tpl.content.cloneNode(true));
      }
      setTimeout(function () {
        initTool("ble-manager");
      }, 0);
    } else {
      // 设备页面已初始化：检查是否有已保存设备但连接断开，自动重连
      try {
        if (window.AndroidBridge && window.BleBridge) {
          var savedJson = AndroidBridge.getSavedDevice();
          if (savedJson && savedJson !== "null") {
            var dev = JSON.parse(savedJson);
            var statusDot = document.querySelector(".oron-status-dot");
            if (statusDot && statusDot.classList.contains("disconnected")) {
              BleBridge.connect(dev.mac, dev.authKey);
            }
          }
        }
      } catch (e) {}
    }
  }

  function navigateToSettings() {
    hideAllViews();
    showViewWithAnimation("view-settings");
    updateBottomNav("settings");
    window.scrollTo(0, 0);
  }

  function navigateToAbout() {
    hideAllViews();
    showViewWithAnimation("view-about");
    updateBottomNav("");
    window.scrollTo(0, 0);
  }

  // ===========================================================================
  // 工具初始化分发
  // ===========================================================================

  function initTool(toolId) {
    switch (toolId) {
      case "zmake-build":     initZMakeBuild(); break;
      case "ble-manager":     initBleManager(); break;
      case "icon-converter":  initIconConverter(); break;
      case "tga-preview":     initTgaPreview(); break;
      case "image-crop":      initImageCrop(); break;
      case "zepp-api":        initZeppApi(); break;
      case "tga-export":      initTgaExport(); break;
      case "base-converter":  initBaseConverter(); break;
      case "hex-viewer":      initHexViewer(); break;
      case "js-bytecode":     initJsBytecode(); break;
      case "app-json-editor": initAppJsonEditor(); break;
      case "js-lint":         initJsLint(); break;
      case "device-params":   initDeviceParams(); break;
      case "code-templates":  initCodeTemplates(); break;
    }
  }

  // ===========================================================================
  // 通用辅助
  // ===========================================================================

  function $(id) { return document.getElementById(id); }

  function setupDropZone(zoneId, inputId, callback) {
    var zone = $(zoneId);
    var input = $(inputId);
    if (!zone || !input) return;

    zone.addEventListener("click", function () { input.click(); });
    input.addEventListener("change", function (e) {
      if (e.target.files && e.target.files.length > 0) callback(e.target.files);
      input.value = "";
    });
    zone.addEventListener("dragover", function (e) {
      e.preventDefault();
      zone.classList.add("drag-over");
    });
    zone.addEventListener("dragleave", function () { zone.classList.remove("drag-over"); });
    zone.addEventListener("drop", function (e) {
      e.preventDefault();
      zone.classList.remove("drag-over");
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) callback(e.dataTransfer.files);
    });
  }

  function downloadBlob(blob, filename, onSaved) {
    if (typeof window.AndroidFileSaver !== "undefined") {
      var reader = new FileReader();
      reader.onloadend = function () {
        var base64 = reader.result.split(",")[1];
        var mimeType = blob.type || "application/octet-stream";
        try {
          window.AndroidFileSaver.saveFile(base64, filename, mimeType);
          if (onSaved) onSaved(filename, mimeType);
        } catch (e) {
          fallbackDownload(blob, filename);
          if (onSaved) onSaved(filename, mimeType);
        }
      };
      reader.readAsDataURL(blob);
    } else {
      fallbackDownload(blob, filename);
      if (onSaved) onSaved(filename, blob.type || "application/octet-stream");
    }
  }

  function openDownloadedFile(filename, mimeType) {
    if (typeof window.AndroidFileSaver !== "undefined" && typeof window.AndroidFileSaver.openFile === "function") {
      window.AndroidFileSaver.openFile(filename, mimeType);
    } else {
      alert("当前环境不支持打开文件，请手动到下载目录查找: " + filename);
    }
  }

  function showOpenButton(btnId, filename, mimeType) {
    var btn = $(btnId);
    if (!btn) return;
    btn.hidden = false;
    btn.onclick = function () {
      openDownloadedFile(filename, mimeType);
    };
  }

  function fallbackDownload(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = filename; a.style.display = "none";
    document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 1000);
  }

  function logToArea(areaId, msg, level) {
    var area = $(areaId);
    if (!area) return;
    var line = document.createElement("div");
    line.className = "log-line log-" + (level || "info");
    line.textContent = msg;
    area.appendChild(line);
    area.scrollTop = area.scrollHeight;
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / 1048576).toFixed(1) + " MB";
  }

  function loadImageFromFile(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        resolve(img);
        URL.revokeObjectURL(url);
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error("图片加载失败: " + file.name));
      };
      img.src = url;
    });
  }

  /**
   * 检测文件是否为 TGA（包括伪装成 .png 的 TGA）。
   * 返回 Promise<boolean>，true 表示是 TGA。
   */
  function isTGAFile(file) {
    var name = (file.name || "").toLowerCase();

    // .tga 后缀直接判定
    if (name.substr(-4) === ".tga") {
      return Promise.resolve(true);
    }

    // 对于 .png 文件，校验文件头是否为真正的 PNG
    // PNG 魔数: 89 50 4E 47 0D 0A 1A 0A
    if (name.substr(-4) === ".png") {
      return file.arrayBuffer().then(function (buf) {
        if (buf.byteLength < 8) return true; // 太小，不是有效 PNG
        var bytes = new Uint8Array(buf);
        var isRealPNG = bytes[0] === 0x89 && bytes[1] === 0x50 &&
                        bytes[2] === 0x4E && bytes[3] === 0x47 &&
                        bytes[4] === 0x0D && bytes[5] === 0x0A &&
                        bytes[6] === 0x1A && bytes[7] === 0x0A;
        return !isRealPNG; // 不是真 PNG → 是伪装的 TGA
      });
    }

    return Promise.resolve(false);
  }

  // ===========================================================================
  // 工具1: TGA 图标转换器
  // ===========================================================================

  function initIconConverter() {
    var currentImage = null;

    setupDropZone("ic_dropZone", "ic_fileInput", function (files) {
      var file = files[0];
      loadImageFromFile(file).then(function (img) {
        currentImage = img;
        updatePreview();
      }).catch(function (e) {
        alert(e.message);
      });
    });

    $("ic_bgColor").addEventListener("input", function () {
      $("ic_bgColorText").textContent = this.value.toUpperCase();
      updatePreview();
    });

    $("ic_scaleMode").addEventListener("change", updatePreview);
    $("ic_sizeW").addEventListener("input", updatePreview);
    $("ic_sizeH").addEventListener("input", updatePreview);

    $("ic_convertBtn").addEventListener("click", function () {
      if (!currentImage) return;
      var canvas = $("ic_canvas");
      var ctx = canvas.getContext("2d");
      var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      var encodeMode = $("ic_deviceType").value;
      try {
        var tgaBuffer = window.TGAEncoder.encodeTGA(imageData, "P", encodeMode);
        var w = canvas.width;
        var h = canvas.height;
        var fileName = "icon_" + w + "x" + h + ".png";
        downloadBlob(new Blob([tgaBuffer], { type: "application/octet-stream" }), fileName, function (fn, mt) {
          showOpenButton("ic_openBtn", fn, mt);
        });
      } catch (e) {
        alert("TGA 转换失败: " + e.message);
      }
    });

    function updatePreview() {
      if (!currentImage) return;
      var w = parseInt($("ic_sizeW").value) || 100;
      var h = parseInt($("ic_sizeH").value) || 100;
      var mode = $("ic_scaleMode").value;
      var bgColor = $("ic_bgColor").value;

      var canvas = $("ic_canvas");
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext("2d");

      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, w, h);

      var img = currentImage;
      var imgRatio = img.width / img.height;
      var canvasRatio = w / h;
      var drawW, drawH, drawX, drawY;

      if (mode === "fill") {
        if (imgRatio > canvasRatio) {
          drawH = h; drawW = h * imgRatio;
          drawX = -(drawW - w) / 2; drawY = 0;
        } else {
          drawW = w; drawH = w / imgRatio;
          drawX = 0; drawY = -(drawH - h) / 2;
        }
      } else if (mode === "fit") {
        if (imgRatio > canvasRatio) {
          drawW = w; drawH = w / imgRatio;
          drawX = 0; drawY = (h - drawH) / 2;
        } else {
          drawH = h; drawW = h * imgRatio;
          drawX = (w - drawW) / 2; drawY = 0;
        }
      } else {
        drawW = w; drawH = h; drawX = 0; drawY = 0;
      }

      ctx.drawImage(img, drawX, drawY, drawW, drawH);
      $("ic_previewArea").hidden = false;
      var label = canvas.parentElement.querySelector(".preview-label");
      if (label) label.textContent = w + "×" + h;
    }
  }

  // ===========================================================================
  // 工具2: TGA 预览器
  // ===========================================================================

  function initTgaPreview() {
    setupDropZone("tp_dropZone", "tp_fileInput", async function (files) {
      var file = files[0];
      $("tp_logContainer").hidden = false;
      $("tp_logArea").innerHTML = "";
      $("tp_resultArea").hidden = true;

      try {
        logToArea("tp_logArea", "正在读取: " + file.name, "info");
        var buf = await file.arrayBuffer();
        logToArea("tp_logArea", "文件大小: " + formatSize(buf.byteLength), "info");
        logToArea("tp_logArea", "正在解码 TGA...", "info");

        var decoded = window.TGAEncoder.decodeTGA(buf);
        logToArea("tp_logArea", "解码成功！格式: TGA-" + decoded.format + ", 尺寸: " + decoded.width + "×" + decoded.height, "success");

        // 显示信息
        var formatNames = { "P": "TGA-P (调色板)", "RLP": "TGA-RLP (RLE调色板)", "16": "TGA-16 (RGB565)", "32": "TGA-32 (RGBA)" };
        $("tp_fileInfo").innerHTML =
          "文件: " + file.name + "<br>" +
          "格式: " + (formatNames[decoded.format] || decoded.format) + "<br>" +
          "尺寸: " + decoded.width + "×" + decoded.height + "<br>" +
          "存储宽度: " + decoded.tgaWidth + " (realWidth=" + decoded.width + ")<br>" +
          "位深: " + decoded.colorDepth + " bit<br>" +
          "大小: " + formatSize(buf.byteLength);

        // 绘制到 canvas
        var canvas = $("tp_canvas");
        canvas.width = decoded.width;
        canvas.height = decoded.height;
        var ctx = canvas.getContext("2d");
        var imageData = ctx.createImageData(decoded.width, decoded.height);
        imageData.data.set(decoded.data);
        ctx.putImageData(imageData, 0, 0);

        $("tp_sizeLabel").textContent = decoded.width + "×" + decoded.height;
        $("tp_resultArea").hidden = false;
      } catch (e) {
        logToArea("tp_logArea", "解码失败: " + e.message, "error");
      }
    });
  }

  // ===========================================================================
  // 工具3: 图片裁剪器（按比例缩放）
  // ===========================================================================

  function initImageCrop() {
    var currentImage = null;
    var imgRatio = 1; // 原图宽高比
    var updating = false; // 防止递归联动

    setupDropZone("cr_dropZone", "cr_fileInput", function (files) {
      var file = files[0];
      isTGAFile(file).then(function (isTGA) {
        if (isTGA) {
          alert("图片裁剪器不支持导入 TGA 文件（包括 .png 后缀的 TGA），请使用 PNG/JPEG/GIF/BMP 等格式");
          return;
        }
        loadImageFromFile(file).then(function (img) {
          currentImage = img;
          imgRatio = img.width / img.height;
          // 初始化为原图尺寸
          updating = true;
          $("cr_sizeW").value = img.width;
          $("cr_sizeH").value = img.height;
          updating = false;
          updateCropPreview();
        }).catch(function (e) { alert(e.message); });
      });
    });

    // 宽度变化 → 高度自动跟随
    $("cr_sizeW").addEventListener("input", function () {
      if (updating || !currentImage) return;
      var w = parseInt(this.value);
      if (w > 0) {
        updating = true;
        $("cr_sizeH").value = Math.round(w / imgRatio);
        updating = false;
      }
      updateCropPreview();
    });

    // 高度变化 → 宽度自动跟随
    $("cr_sizeH").addEventListener("input", function () {
      if (updating || !currentImage) return;
      var h = parseInt(this.value);
      if (h > 0) {
        updating = true;
        $("cr_sizeW").value = Math.round(h * imgRatio);
        updating = false;
      }
      updateCropPreview();
    });

    $("cr_bgColor").addEventListener("input", function () {
      $("cr_bgColorText").textContent = this.value.toUpperCase();
      updateCropPreview();
    });

    $("cr_downloadBtn").addEventListener("click", function () {
      if (!currentImage) return;
      var canvas = $("cr_canvas");
      canvas.toBlob(function (blob) {
        if (!blob) { alert("导出失败"); return; }
        var name = "crop_" + canvas.width + "x" + canvas.height + ".png";
        downloadBlob(blob, name, function (fn, mt) {
          showOpenButton("cr_openBtn", fn, mt);
        });
      }, "image/png");
    });

    function updateCropPreview() {
      if (!currentImage) return;
      var w = parseInt($("cr_sizeW").value) || 1;
      var h = parseInt($("cr_sizeH").value) || 1;
      w = Math.max(1, w);
      h = Math.max(1, h);
      var bgColor = $("cr_bgColor").value;

      var canvas = $("cr_canvas");
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext("2d");

      // 按比例缩放，直接铺满（因为宽高比已锁定）
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(currentImage, 0, 0, w, h);

      $("cr_previewArea").hidden = false;
      $("cr_sizeLabel").textContent = w + "×" + h;
    }
  }

  // ===========================================================================
  // 工具4: ZeppOS 1.0 API 速查
  // ===========================================================================

  function initZeppApi() {
    var tabs = document.querySelectorAll(".api-tab");
    tabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        var target = this.getAttribute("data-tab");
        tabs.forEach(function (t) { t.classList.remove("active"); });
        this.classList.add("active");
        document.querySelectorAll(".api-section").forEach(function (sec) {
          sec.classList.remove("active");
        });
        var section = $("tab-" + target);
        if (section) section.classList.add("active");
      });
    });

    var searchInput = $("api_search");
    if (searchInput) {
      searchInput.addEventListener("input", function () {
        var query = this.value.trim().toLowerCase();
        document.querySelectorAll(".api-item").forEach(function (item) {
          if (!query) {
            item.style.display = "";
            return;
          }
          var text = item.textContent.toLowerCase();
          item.style.display = text.indexOf(query) !== -1 ? "" : "none";
        });
        // 隐藏没有可见项的 section 标题
        document.querySelectorAll(".api-section").forEach(function (sec) {
          var visible = sec.querySelectorAll('.api-item:not([style*="display: none"])');
          var title = sec.querySelector(".api-section-title");
          if (title) {
            title.style.display = (query && visible.length === 0) ? "none" : "";
          }
          sec.style.display = (query && visible.length === 0) ? "none" : "";
        });
      });
    }
  }

  // ===========================================================================
  // 工具5: TGA 反向导出为 PNG
  // ===========================================================================

  function initTgaExport() {
    var currentDecoded = null;
    var currentFileName = "";

    setupDropZone("te_dropZone", "te_fileInput", async function (files) {
      var file = files[0];
      currentFileName = file.name.replace(/\.tga$/i, "");
      $("te_previewArea").hidden = true;

      try {
        var buf = await file.arrayBuffer();
        var decoded = window.TGAEncoder.decodeTGA(buf);
        currentDecoded = decoded;

        var formatNames = {
          "P": "TGA-P (调色板)",
          "RLP": "TGA-RLP (RLE调色板)",
          "16": "TGA-16 (RGB565)",
          "32": "TGA-32 (RGBA)"
        };

        $("te_info").innerHTML =
          "格式: " + (formatNames[decoded.format] || decoded.format) + "<br>" +
          "尺寸: " + decoded.width + "×" + decoded.height + "<br>" +
          "位深: " + decoded.colorDepth + " bit<br>" +
          "大小: " + formatSize(buf.byteLength);

        var canvas = $("te_canvas");
        canvas.width = decoded.width;
        canvas.height = decoded.height;
        var ctx = canvas.getContext("2d");
        var imageData = ctx.createImageData(decoded.width, decoded.height);
        imageData.data.set(decoded.data);
        ctx.putImageData(imageData, 0, 0);

        $("te_sizeLabel").textContent = decoded.width + "×" + decoded.height;
        $("te_previewArea").hidden = false;
      } catch (e) {
        alert("TGA 解码失败: " + e.message);
      }
    });

    $("te_exportBtn").addEventListener("click", function () {
      if (!currentDecoded) return;
      var canvas = $("te_canvas");
      canvas.toBlob(function (blob) {
        downloadBlob(blob, currentFileName + ".png");
      }, "image/png");
    });
  }

  // ===========================================================================
  // 工具6: 进制转换器
  // ===========================================================================

  function initBaseConverter() {
    var input = $("bc_input");
    var fromBase = $("bc_fromBase");
    var convertBtn = $("bc_convertBtn");

    function doConvert() {
      var val = input.value.trim();
      if (!val) {
        ["bc_bin", "bc_oct", "bc_dec", "bc_hex", "bc_result"].forEach(function (id) {
          $(id).textContent = id === "bc_result" ? "" : "-";
        });
        return;
      }

      var from = parseInt(fromBase.value);
      // 自动补全前缀
      var cleaned = val.replace(/^0x/i, "").replace(/^0b/i, "").replace(/^0o/i, "");

      var decimal;
      try {
        decimal = parseInt(cleaned, from);
        if (isNaN(decimal)) throw new Error("无效数字");
      } catch (e) {
        ["bc_bin", "bc_oct", "bc_dec", "bc_hex", "bc_result"].forEach(function (id) {
          $(id).textContent = id === "bc_result" ? "输入无效" : "-";
        });
        return;
      }

      var to = parseInt($("bc_toBase").value);
      var result = decimal.toString(to).toUpperCase();

      $("bc_result").value = result;
      $("bc_bin").textContent = decimal.toString(2);
      $("bc_oct").textContent = decimal.toString(8);
      $("bc_dec").textContent = decimal.toString(10);
      $("bc_hex").textContent = decimal.toString(16).toUpperCase();
    }

    input.addEventListener("input", doConvert);
    fromBase.addEventListener("change", doConvert);
    $("bc_toBase").addEventListener("change", doConvert);
    convertBtn.addEventListener("click", doConvert);

    // 复制结果
    $("bc_copyBtn").addEventListener("click", function () {
      var result = $("bc_result").value;
      if (!result) return;
      if (navigator.clipboard) {
        navigator.clipboard.writeText(result);
      } else {
        $("bc_result").select();
        document.execCommand("copy");
      }
      var btn = this;
      var orig = btn.textContent;
      btn.textContent = "已复制";
      setTimeout(function () { btn.textContent = orig; }, 1500);
    });
  }

  // ===========================================================================
  // 工具7: Hex 查看器
  // ===========================================================================

  function initHexViewer() {
    var fileData = null;
    var fileName = "";
    var pageSize = 256; // 每页 256 字节 (16行 × 16列)
    var currentPage = 0;
    var totalPages = 0;

    setupDropZone("hx_dropZone", "hx_fileInput", async function (files) {
      var file = files[0];
      fileName = file.name;
      fileData = new Uint8Array(await file.arrayBuffer());

      totalPages = Math.ceil(fileData.length / pageSize);
      if (totalPages === 0) totalPages = 1;
      currentPage = 0;

      $("hx_fileInfo").innerHTML =
        "文件: " + fileName + "<br>" +
        "大小: " + formatSize(fileData.length) + " (" + fileData.length + " 字节)<br>" +
        "总页数: " + totalPages;
      $("hx_infoArea").hidden = false;
      $("hx_ctrlArea").hidden = totalPages <= 1;
      $("hx_hexArea").hidden = false;

      renderHexPage();
    });

    $("hx_prevBtn").addEventListener("click", function () {
      if (currentPage > 0) {
        currentPage--;
        renderHexPage();
      }
    });

    $("hx_nextBtn").addEventListener("click", function () {
      if (currentPage < totalPages - 1) {
        currentPage++;
        renderHexPage();
      }
    });

    function renderHexPage() {
      if (!fileData) return;
      var start = currentPage * pageSize;
      var end = Math.min(start + pageSize, fileData.length);
      var lines = [];
      var bytesPerLine = 16;

      for (var i = start; i < end; i += bytesPerLine) {
        var lineEnd = Math.min(i + bytesPerLine, end);
        var hexPart = "";
        var asciiPart = "";

        // 偏移地址
        var offset = i.toString(16).toUpperCase().padStart(8, "0");

        for (var j = i; j < i + bytesPerLine; j++) {
          if (j < lineEnd) {
            var byte = fileData[j];
            hexPart += byte.toString(16).toUpperCase().padStart(2, "0") + " ";
            // ASCII 可见字符范围
            if (byte >= 32 && byte <= 126) {
              asciiPart += String.fromCharCode(byte);
            } else {
              asciiPart += ".";
            }
          } else {
            hexPart += "   ";
            asciiPart += " ";
          }
        }

        lines.push(
          '<div class="hex-line">' +
          '<span class="hex-offset">' + offset + '</span>' +
          '<span class="hex-bytes">' + hexPart + '</span>' +
          '<span class="hex-ascii">' + asciiPart + '</span>' +
          '</div>'
        );
      }

      $("hx_hexArea").innerHTML = lines.join("");
      $("hx_pageInfo").textContent = (currentPage + 1) + " / " + totalPages;
    }
  }

  // ===========================================================================
  // 工具8: JS 字节码编译器（支持多文件）
  // ===========================================================================

  function initJsBytecode() {
    var pendingFiles = [];
    var compiledResults = [];

    setupDropZone("js_dropZone", "js_fileInput", function (files) {
      for (var i = 0; i < files.length; i++) {
        pendingFiles.push(files[i]);
      }
      renderFileList();
    });

    function renderFileList() {
      var list = $("js_fileList");
      list.innerHTML = "";
      pendingFiles.forEach(function (f, idx) {
        var item = document.createElement("div");
        item.className = "file-item";
        item.innerHTML =
          '<span class="file-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span>' +
          '<div class="file-item-info"><div class="file-item-name">' + f.name + '</div>' +
          '<div class="file-item-size">' + formatSize(f.size) + '</div></div>';
        var del = document.createElement("button");
        del.className = "btn btn-small btn-ghost";
        del.textContent = "✕";
        (function (index) {
          del.addEventListener("click", function () {
            pendingFiles.splice(index, 1);
            renderFileList();
          });
        })(idx);
        item.appendChild(del);
        list.appendChild(item);
      });
      list.hidden = pendingFiles.length === 0;
      $("js_compileBtn").hidden = pendingFiles.length === 0;
    }

    $("js_compileBtn").addEventListener("click", async function () {
      if (pendingFiles.length === 0) return;
      $("js_compileBtn").disabled = true;
      $("js_logContainer").hidden = false;
      $("js_logArea").innerHTML = "";
      $("js_resultArea").hidden = true;
      compiledResults = [];

      logToArea("js_logArea", "正在初始化 QuickJS 编译器...", "info");

      try {
        var quickjs = await window.createQuickJS();
        logToArea("js_logArea", "编译器就绪，开始处理 " + pendingFiles.length + " 个文件...", "info");

        for (var i = 0; i < pendingFiles.length; i++) {
          var file = pendingFiles[i];
          try {
            logToArea("js_logArea", "正在编译: " + file.name, "info");
            var code = await file.text();
            var bytecode = quickjs.compileToByteCode(code, file.name);
            var outName = /\.js$/i.test(file.name) ? file.name.replace(/\.js$/i, ".bin") : file.name + ".bin";
            compiledResults.push({
              name: outName,
              blob: new Blob([bytecode], { type: "application/octet-stream" }),
              size: bytecode.length
            });
            logToArea("js_logArea", "  ✓ 成功: " + outName + " (" + formatSize(bytecode.length) + ")", "success");
          } catch (e) {
            logToArea("js_logArea", "  ✗ 失败: " + file.name + " - " + e.message, "error");
          }
        }

        // 显示结果列表
        var resultList = $("js_resultList");
        resultList.innerHTML = "";
        compiledResults.forEach(function (f) {
          var item = document.createElement("div");
          item.className = "file-item";
          item.innerHTML =
            '<span class="file-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg></span>' +
            '<div class="file-item-info"><div class="file-item-name">' + f.name + '</div>' +
            '<div class="file-item-size">' + formatSize(f.size) + '</div></div>';
          var btn = document.createElement("button");
          btn.className = "btn btn-small btn-download";
          btn.textContent = "下载";
          (function (fileObj) {
            btn.addEventListener("click", function () {
              downloadBlob(fileObj.blob, fileObj.name);
            });
          })(f);
          item.appendChild(btn);
          resultList.appendChild(item);
        });
        $("js_resultArea").hidden = compiledResults.length === 0;

        var failCount = pendingFiles.length - compiledResults.length;
        logToArea("js_logArea", "编译完成！成功 " + compiledResults.length + " 个，失败 " + failCount + " 个", "success");
      } catch (e) {
        logToArea("js_logArea", "编译器初始化失败: " + e.message, "error");
      } finally {
        $("js_compileBtn").disabled = false;
      }
    });

    $("js_downloadAllBtn").addEventListener("click", async function () {
      if (compiledResults.length === 0) return;
      var JSZip = window.JSZip;
      var zip = new JSZip();
      compiledResults.forEach(function (f) {
        zip.file(f.name, f.blob);
      });
      var zipBlob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
      downloadBlob(zipBlob, "bytecode_batch.zip");
    });
  }


  // ===========================================================================
  // 工具9: app.json 编辑生成器
  // ===========================================================================

  function initAppJsonEditor() {
    var previewEl = $("aj_preview");
    var errorEl = $("aj_error");

    // 设备列表
    var deviceList = [
      { name: "gtr-3-pro", label: "GTR 3 Pro", designWidth: 480, sources: [229, 230] },
      { name: "gtr-3", label: "GTR 3", designWidth: 480, sources: [226, 227] },
      { name: "gts-3", label: "GTS 3", designWidth: 390, sources: [224, 225] },
      { name: "gts-4-mini", label: "GTS 4 mini", designWidth: 336, sources: [252, 253] },
      { name: "band-7", label: "Amazfit Band 7", designWidth: 194, sources: [252, 253, 254] },
      { name: "mi-band-7", label: "小米手环7", designWidth: 192, sources: [252, 253, 254] },
    ];

    var selectedDevices = {};

    // 填充设备选择
    var deviceChecksEl = $("aj_deviceChecks");
    deviceList.forEach(function (d) {
      var label = document.createElement("label");
      label.className = "aj-check-item";
      label.innerHTML = '<input type="checkbox" value="' + d.name + '"> ' + d.label;
      deviceChecksEl.appendChild(label);
      label.querySelector("input").addEventListener("change", function () {
        if (this.checked) {
          selectedDevices[d.name] = d;
        } else {
          delete selectedDevices[d.name];
        }
        updatePreview();
      });
    });

    // 实时更新
    ["aj_appId", "aj_appName", "aj_appType", "aj_versionCode", "aj_versionName",
     "aj_icon", "aj_vender", "aj_description", "aj_defaultLang",
     "aj_pagePath", "aj_appSidePath", "aj_settingPath"].forEach(function (id) {
      var el = $(id);
      if (el) el.addEventListener("input", updatePreview);
    });

    function updatePreview() {
      errorEl.textContent = "";
      try {
        var json = buildJson();
        previewEl.textContent = JSON.stringify(json, null, 2);
        $("aj_downloadBtn").disabled = false;
      } catch (e) {
        errorEl.textContent = e.message;
        previewEl.textContent = "";
        $("aj_downloadBtn").disabled = true;
      }
    }

    function buildJson() {
      var appId = parseInt($("aj_appId").value) || 0;
      var appName = $("aj_appName").value.trim() || "MyApp";
      var appType = $("aj_appType").value;
      var versionCode = parseInt($("aj_versionCode").value) || 1;
      var versionName = $("aj_versionName").value.trim() || "1.0.0";
      var icon = $("aj_icon").value.trim();
      var vender = $("aj_vender").value.trim() || "unknown";
      var description = $("aj_description").value.trim();
      var defaultLang = $("aj_defaultLang").value || "zh-CN";
      var pagePath = $("aj_pagePath").value.trim();
      var appSidePath = $("aj_appSidePath").value.trim();
      var settingPath = $("aj_settingPath").value.trim();

      var obj = {};

      // ZeppOS 1.0 格式
      obj.appId = appId;
      obj.appName = appName;
      obj.appType = appType === "watchface" ? 1 : 0;
      obj.version = versionName;
      obj.vender = vender;
      obj.description = description;
      if (icon) obj.icon = icon;

      // targets
      var targets = {};
      var deviceNames = Object.keys(selectedDevices);
      if (deviceNames.length === 0) throw new Error("请至少选择一个目标设备");

      deviceNames.forEach(function (dn) {
        var d = selectedDevices[dn];
        var target = {};
        target.designWidth = d.designWidth;

        // module
        var module = {};
        if (appType === "app") {
          if (pagePath) {
            module.page = { pages: [pagePath] };
          }
          if (appSidePath) {
            module["app-side"] = { path: appSidePath };
          }
          if (settingPath) {
            module.setting = { path: settingPath };
          }
        } else if (appType === "watchface") {
          module.watchface = { path: "watchface/index" };
        }
        target.module = module;

        // platforms
        target.platforms = d.sources.map(function (s) {
          return { name: dn, deviceSource: s };
        });

        targets[dn] = target;
      });
      obj.targets = targets;

      // i18n
      var i18n = {};
      i18n[defaultLang] = { appName: appName };
      i18n["en-US"] = { appName: appName };
      obj.i18n = i18n;
      obj.defaultLanguage = defaultLang;

      // permissions
      obj.permissions = [];

      return obj;
    }

    // 下载
    $("aj_downloadBtn").addEventListener("click", function () {
      try {
        var json = buildJson();
        var text = JSON.stringify(json, null, 2);
        var fileName = "app.json";
        downloadBlob(new Blob([text], { type: "application/json" }), fileName, function (fn, mt) {
          showOpenButton("aj_openBtn", fn, mt);
        });
      } catch (e) {
        errorEl.textContent = e.message;
      }
    });

    // 初始化预览
    updatePreview();
  }


  // ===========================================================================
  // 工具10: JS 语法校验
  // ===========================================================================

  function initJsLint() {
    var checkBtn = $("jl_checkBtn");
    var resultArea = $("jl_result");
    var fileInfo = $("jl_fileInfo");
    var fileNameEl = $("jl_fileName");
    var fileSizeEl = $("jl_fileSize");
    var loadedCode = "";
    var loadedFileName = "";

    setupDropZone("jl_dropZone", "jl_fileInput", function (files) {
      var file = files[0];
      if (!file.name.match(/\.js$/i)) {
        alert("请上传 .js 文件");
        return;
      }
      loadJsFile(file);
    });

    function loadJsFile(file) {
      loadedFileName = file.name;
      fileNameEl.textContent = file.name;
      fileSizeEl.textContent = formatSize(file.size);
      fileInfo.hidden = false;
      resultArea.hidden = true;
      checkBtn.disabled = true;

      var reader = new FileReader();
      reader.onload = function (e) {
        loadedCode = e.target.result;
        checkBtn.disabled = false;
        // 自动执行检查
        runCheck();
      };
      reader.onerror = function () {
        resultArea.hidden = false;
        resultArea.innerHTML = '<div class="log-line log-error">文件读取失败</div>';
      };
      reader.readAsText(file);
    }

    checkBtn.addEventListener("click", function () {
      runCheck();
    });

    function runCheck() {
      var code = loadedCode;
      if (!code || !code.trim()) {
        resultArea.hidden = false;
        resultArea.innerHTML = '<div class="log-line log-error">文件内容为空</div>';
        return;
      }

      var errors = [];
      var warnings = [];

      // 1. 基本括号匹配
      var stack = [];
      var pairs = { "(": ")", "[": "]", "{": "}" };
      var lineNum = 1;
      var inString = false;
      var stringChar = "";
      var inComment = false;
      var inLineComment = false;

      for (var i = 0; i < code.length; i++) {
        var ch = code[i];
        var prev = i > 0 ? code[i - 1] : "";
        if (ch === "\n") { lineNum++; inLineComment = false; continue; }
        if (inLineComment) continue;
        if (inComment) {
          if (ch === "*" && code[i + 1] === "/") { inComment = false; i++; }
          continue;
        }
        if (inString) {
          if (ch === "\\") { i++; continue; }
          if (ch === stringChar) { inString = false; }
          continue;
        }
        if (ch === "/" && code[i + 1] === "/") { inLineComment = true; continue; }
        if (ch === "/" && code[i + 1] === "*") { inComment = true; i++; continue; }
        if (ch === '"' || ch === "'" || ch === "`") { inString = true; stringChar = ch; continue; }
        if (ch === "(" || ch === "[" || ch === "{") {
          stack.push({ ch: ch, line: lineNum });
        } else if (ch === ")" || ch === "]" || ch === "}") {
          if (stack.length === 0) {
            errors.push("第" + lineNum + "行: 多余的 '" + ch + "'");
          } else {
            var top = stack.pop();
            if (pairs[top.ch] !== ch) {
              errors.push("第" + top.line + "行: '" + top.ch + "' 与 '" + ch + "' 不匹配 (第" + lineNum + "行)");
            }
          }
        }
      }
      while (stack.length > 0) {
        var item = stack.pop();
        errors.push("第" + item.line + "行: 未闭合的 '" + item.ch + "'");
      }

      // 2. 检查常见错误
      // 赋值在条件中
      if (/\bif\s*\([^=]*=[^=]/.test(code) && !/[=!]==/.test(code)) {
        warnings.push("可能存在条件中使用赋值 (=) 而非比较 (==)");
      }

      // 使用 new Function 尝试解析
      try {
        new Function(code);
      } catch (e) {
        var msg = e.message;
        // 提取行号
        var match = msg.match(/line (\d+)/);
        var lineInfo = match ? " (第" + match[1] + "行)" : "";
        errors.push("语法错误" + lineInfo + ": " + msg);
      }

      // 3. ZeppOS 特定检查
      // 检查是否使用了不支持的 API
      if (/\beval\s*\(/.test(code)) {
        errors.push("ZeppOS 不支持 eval()");
      }
      if (/new\s+Function\s*\(/.test(code) && !/new\s+Function\s*\(\s*['"]return this['"]\s*\)/.test(code)) {
        warnings.push("ZeppOS 不支持 new Function()（除 new Function('return this')外）");
      }
      if (/\bPromise\b/.test(code)) {
        warnings.push("ZeppOS 1.0 不原生支持 Promise，需 polyfill");
      }
      if (/function\s*\*/.test(code)) {
        errors.push("ZeppOS 不支持 Generator 函数");
      }
      // 检查 createWidget 参数
      if (/createWidget\s*\([^,]+,\s*\{\s*\}/.test(code)) {
        warnings.push("createWidget 传入了空配置对象，可能缺少必要属性");
      }

      // 统计代码行数
      var totalLines = code.split("\n").length;

      // 渲染结果
      var html = "";
      html += '<div class="log-line log-info">文件: ' + loadedFileName + ' (' + totalLines + ' 行)</div>';
      if (errors.length === 0 && warnings.length === 0) {
        html += '<div class="log-line log-success">✓ 语法检查通过，未发现问题</div>';
      } else {
        errors.forEach(function (e) {
          html += '<div class="log-line log-error">✗ ' + e + '</div>';
        });
        warnings.forEach(function (w) {
          html += '<div class="log-line log-warning">⚠ ' + w + '</div>';
        });
      }
      html += '<div class="log-line log-info" style="margin-top:8px">检查完成: ' + errors.length + ' 错误, ' + warnings.length + ' 警告</div>';
      resultArea.innerHTML = html;
      resultArea.hidden = false;
    }
  }

  // ===========================================================================
  // 工具11: ZeppOS 1.0 设备参数
  // ===========================================================================

  function initDeviceParams() {
    var container = $("dp_table");
    var deviceData = [
      { name: "GTR 3 Pro", w: 480, h: 480, shape: "圆形", radius: "-", keys: 2, sources: "229*, 230, 242*, 6095106*", designWidth: 480, preview: "324×324" },
      { name: "GTR 3", w: 454, h: 454, shape: "圆形", radius: "-", keys: 2, sources: "226*, 227", designWidth: 480, preview: "306×306" },
      { name: "GTS 3", w: 390, h: 450, shape: "方形", radius: 86, keys: 1, sources: "224*, 225", designWidth: 390, preview: "266×307" },
      { name: "GTS 4 mini", w: 336, h: 384, shape: "方形", radius: 80, keys: 1, sources: "246*, 247", designWidth: 336, preview: "228×260" },
      { name: "Amazfit Band 7", w: 194, h: 368, shape: "手环", radius: 25, keys: 0, sources: "252, 253, 254", designWidth: 194, preview: "152×288" },
      { name: "小米手环7", w: 192, h: 490, shape: "手环", radius: 25, keys: 0, sources: "252, 253, 254 (共用)", designWidth: 192, preview: "152×288" },
    ];

    var html = '<table class="dp-table"><thead><tr>' +
      '<th>设备名称</th><th>分辨率</th><th>形状</th>' +
      '<th>圆角</th><th>按键</th><th>designWidth</th>' +
      '<th>预览图</th><th>deviceSource</th>' +
      '</tr></thead><tbody>';

    deviceData.forEach(function (d) {
      html += '<tr>' +
        '<td class="dp-name">' + d.name + '</td>' +
        '<td>' + d.w + '×' + d.h + '</td>' +
        '<td>' + d.shape + '</td>' +
        '<td>' + d.radius + '</td>' +
        '<td>' + (d.keys === 0 ? '-' : d.keys) + '</td>' +
        '<td>' + d.designWidth + '</td>' +
        '<td>' + d.preview + '</td>' +
        '<td class="dp-src">' + d.sources + '</td>' +
        '</tr>';
    });

    html += '</tbody></table>';
    html += '<div class="dp-note">' +
      '<p><strong>* 标记为中国大陆版本</strong>，在 app.json 中填写数字即可（不带星号）</p>' +
      '<p><strong>deviceSource</strong>：用于 app.json → targets → platforms 配置</p>' +
      '<p><strong>designWidth</strong>：设计稿宽度，供运行时 px() 函数做屏幕适配</p>' +
      '<p><strong>预览图</strong>：app.json 中 preview 图片的推荐分辨率</p>' +
      '<div style="margin-top:8px;padding:8px 10px;background:var(--bg-input);border-radius:var(--radius-xs);border-left:2px solid var(--accent)">' +
      '<p style="font-size:11px;color:var(--accent);margin-bottom:4px">小米手环7 说明</p>' +
      '<p style="font-size:11px;color:var(--text-muted);line-height:1.5">小米手环7 由华米（Huami/Zepp Health）代工，底层运行 Zepp OS 1.0，与 Amazfit Band 7 共享同一硬件平台和 deviceSource（252/253/254）。小米通过软件层面限制了开发者模式，需使用社区修改版 ZEPP 应用解锁后才能安装第三方应用。</p>' +
      '</div>' +
      '<div style="margin-top:8px;padding:8px 10px;background:var(--bg-input);border-radius:var(--radius-xs)">' +
      '<p style="font-size:11px;color:var(--accent);font-family:monospace;margin-bottom:4px">app.json 示例：</p>' +
      '<pre style="font-size:10px;color:var(--text-secondary);white-space:pre-wrap;line-height:1.5">"targets": {\n  "gtr-3-pro": {\n    "platforms": [\n      { "name": "gtr3pro", "deviceSource": 229 },\n      { "name": "gtr3pro", "deviceSource": 230 }\n    ],\n    "designWidth": 480\n  }\n}</pre>' +
      '</div>' +
      '</div>';

    container.innerHTML = html;
  }

  // ===========================================================================
  // 工具12: 代码模板库（ZeppOS 1.0 全 API 示例）
  // ===========================================================================

  function initCodeTemplates() {
    var TEMPLATES = [
      { cat: "framework", catName: "框架接口", items: [
        { t: "App() 注册小程序", d: "app.js 入口", c: [
          "App({",
          "  globalData: {",
          "    appName: 'MyApp',",
          "    count: 0",
          "  },",
          "  onCreate(param) {",
          "    console.log('app onCreate, param:', param)",
          "  },",
          "  onDestroy() {",
          "    console.log('app onDestroy')",
          "  }",
          "})"
        ].join("\n") },
        { t: "Page() 注册页面", d: "页面注册与生命周期", c: [
          "Page({",
          "  state: {",
          "    pageName: 'Home'",
          "  },",
          "  onInit(param) {",
          "    console.log('page onInit, param:', param)",
          "  },",
          "  build() {",
          "    hmUI.createWidget(hmUI.widget.TEXT, {",
          "      x: 96, y: 120, w: 288, h: 46,",
          "      color: 0xffffff, text_size: 36,",
          "      align_h: hmUI.align.CENTER_H,",
          "      align_v: hmUI.align.CENTER_V,",
          "      text: 'HELLO ZEPPOS'",
          "    })",
          "  },",
          "  onDestroy() {",
          "    console.log('page onDestroy')",
          "  }",
          "})"
        ].join("\n") },
        { t: "getApp() 获取全局实例", d: "跨页面共享数据", c: [
          "var app = getApp()",
          "console.log(app.globalData.appName)",
          "app.globalData.count++"
        ].join("\n") },
        { t: "px() 屏幕适配", d: "多设备尺寸适配", c: [
          "// px() 将设计稿尺寸转为实际像素",
          "var width = px(480)",
          "var fontSize = px(36)",
          "",
          "hmUI.createWidget(hmUI.widget.TEXT, {",
          "  x: px(0), y: px(120),",
          "  w: px(480), h: px(46),",
          "  text_size: px(20),",
          "  text: 'Screen Adapted'",
          "})"
        ].join("\n") }
      ]},

      { cat: "hmui", catName: "hmUI 方法", items: [
        { t: "createWidget 创建组件", d: "创建 UI 组件", c: [
          "var text = hmUI.createWidget(hmUI.widget.TEXT, {",
          "  x: 96, y: 120, w: 288, h: 46,",
          "  color: 0xffffff, text_size: 36,",
          "  align_h: hmUI.align.CENTER_H,",
          "  align_v: hmUI.align.CENTER_V,",
          "  text_style: hmUI.text_style.NONE,",
          "  text: 'HELLO ZEPPOS'",
          "})"
        ].join("\n") },
        { t: "deleteWidget 删除组件", d: "移除已创建的组件", c: [
          "var img = hmUI.createWidget(hmUI.widget.IMG, {",
          "  x: 125, y: 125,",
          "  src: 'zeppos.png'",
          "})",
          "hmUI.deleteWidget(img)"
        ].join("\n") },
        { t: "setProperty 设置属性", d: "修改组件属性/显隐", c: [
          "// 设置可见性",
          "button.setProperty(hmUI.prop.VISIBLE, false)",
          "",
          "// 批量设置属性",
          "text.setProperty(hmUI.prop.MORE, {",
          "  x: 0, y: 0, w: 200, h: 200,",
          "  text: 'hello', color: 0x34e073,",
          "  align_h: hmUI.align.LEFT",
          "})"
        ].join("\n") },
        { t: "getProperty 获取属性", d: "读取组件属性", c: [
          "var prop = widget.getProperty(hmUI.prop.MORE, {})",
          "var h = widget.getProperty(hmUI.prop.H)",
          "// 部分组件不支持，建议手动维护变量"
        ].join("\n") },
        { t: "addEventListener 事件监听", d: "注册触摸事件", c: [
          "// 事件类型: CLICK_DOWN / CLICK_UP / MOVE / MOVE_IN / MOVE_OUT",
          "widget.addEventListener(hmUI.event.CLICK_DOWN, function(info) {",
          "  console.log(info.x, info.y)",
          "})"
        ].join("\n") },
        { t: "setEnable 手势开关", d: "控制组件是否响应手势", c: [
          "// false: 不响应手势，让下层组件接收",
          "widget.setEnable(false)"
        ].join("\n") },
        { t: "createDialog 对话框", d: "系统弹窗", c: [
          "var dialog = hmUI.createDialog({",
          "  title: 'HELLO ZEPP OS',",
          "  auto_hide: false,",
          "  click_linster: function(info) {",
          "    dialog.show(false)",
          "    console.log('type', info.type)",
          "  }",
          "})",
          "dialog.show(true)"
        ].join("\n") },
        { t: "showToast 提示", d: "Toast 消息", c: [
          "hmUI.showToast({",
          "  text: 'Hello\\nZepp OS'",
          "})"
        ].join("\n") },
        { t: "setScrollView 分页滑动", d: "整页 Swipe 模式", c: [
          "// 启用分页滑动: 每页480px, 共20页, 垂直方向",
          "hmUI.setScrollView(true, px(480), 20, true)",
          "",
          "// 在各页创建内容",
          "for (var i = 0; i < 20; i++) {",
          "  hmUI.createWidget(hmUI.widget.FILL_RECT, {",
          "    x: 0, y: px(480) * i,",
          "    w: px(480), h: px(480),",
          "    color: 0xfc6950",
          "  })",
          "}"
        ].join("\n") },
        { t: "scrollToPage 页面跳转", d: "跳转到指定页", c: [
          "var current = hmUI.getScrollCurrentPage()",
          "console.log('current page:', current)",
          "// 跳转到第5页, false=无动画",
          "hmUI.scrollToPage(5, false)"
        ].join("\n") },
        { t: "setLayerScrolling 层滚动", d: "默认层连续滚动", c: [
          "// 关闭默认层连续滚动",
          "hmUI.setLayerScrolling(false)"
        ].join("\n") },
        { t: "setLayerVisible 层显隐", d: "显示/隐藏页面层", c: [
          "// 隐藏当前页面层",
          "hmUI.setLayerVisible(false)",
          "",
          "// 显示当前页面层",
          "hmUI.setLayerVisible(true)"
        ].join("\n") },
        { t: "getTextLayout 文本布局", d: "计算文本尺寸", c: [
          "var layout = hmUI.getTextLayout('turn right', {",
          "  text_size: 30,",
          "  text_width: 200",
          "})",
          "console.log('width:', layout.width)",
          "console.log('height:', layout.height)",
          "",
          "// 单行不换行",
          "var single = hmUI.getTextLayout('hello', {",
          "  text_size: 30,",
          "  text_width: 0,",
          "  wrapped: 0",
          "})"
        ].join("\n") },
        { t: "状态栏控制", d: "显示/隐藏状态栏（方屏）", c: [
          "// 隐藏状态栏",
          "hmUI.setStatusBarVisible(false)",
          "",
          "// 设置状态栏标题",
          "hmUI.updateStatusBarTitle('My App')"
        ].join("\n") }
      ]},

      { cat: "widget", catName: "hmUI 组件", items: [
        { t: "TEXT 文本", d: "显示文字", c: [
          "var text = hmUI.createWidget(hmUI.widget.TEXT, {",
          "  x: 96, y: 120, w: 288, h: 46,",
          "  color: 0xffffff, text_size: 36,",
          "  align_h: hmUI.align.CENTER_H,",
          "  align_v: hmUI.align.CENTER_V,",
          "  text_style: hmUI.text_style.NONE,",
          "  text: 'HELLO ZEPPOS'",
          "})"
        ].join("\n") },
        { t: "IMG 图片", d: "显示图片", c: [
          "var img = hmUI.createWidget(hmUI.widget.IMG, {",
          "  x: 125, y: 125,",
          "  src: 'zeppos.png'",
          "})"
        ].join("\n") },
        { t: "IMG 旋转（时钟指针）", d: "旋转图片", c: [
          "var imgHour = hmUI.createWidget(hmUI.widget.IMG, {",
          "  x: 0, y: 0, w: 454, h: 454,",
          "  pos_x: 454 / 2 - 27,",
          "  pos_y: 50 + 50,",
          "  center_x: 454 / 2,",
          "  center_y: 454 / 2,",
          "  src: 'hour.png',",
          "  angle: 30",
          "})"
        ].join("\n") },
        { t: "ARC 圆弧", d: "绘制弧线", c: [
          "var arc = hmUI.createWidget(hmUI.widget.ARC, {",
          "  x: 100, y: 100, w: 200, h: 200,",
          "  radius: 80,",
          "  start_angle: 0,",
          "  end_angle: 150,",
          "  line_width: 20,",
          "  color: 0xfc6950",
          "})"
        ].join("\n") },
        { t: "FILL_RECT 填充矩形", d: "实心矩形/圆角", c: [
          "var rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {",
          "  x: 125, y: 125, w: 230, h: 150,",
          "  radius: 20,",
          "  color: 0xfc6950",
          "})",
          "// 修改时必须传 x,y,w,h",
          "rect.setProperty(hmUI.prop.MORE, {",
          "  x: 125, y: 200, w: 230, h: 150",
          "})"
        ].join("\n") },
        { t: "STROKE_RECT 描边矩形", d: "空心矩形边框", c: [
          "hmUI.createWidget(hmUI.widget.STROKE_RECT, {",
          "  x: 125, y: 125, w: 230, h: 150,",
          "  radius: 20,",
          "  line_width: 4,",
          "  color: 0xfc6950",
          "})"
        ].join("\n") },
        { t: "CIRCLE 圆形", d: "绘制圆", c: [
          "hmUI.createWidget(hmUI.widget.CIRCLE, {",
          "  center_x: 240,",
          "  center_y: 240,",
          "  radius: 120,",
          "  color: 0xfc6950,",
          "  alpha: 200  // 0-255, 0为全透明",
          "})"
        ].join("\n") },
        { t: "BUTTON 按钮", d: "可点击按钮", c: [
          "// 纯色背景按钮",
          "hmUI.createWidget(hmUI.widget.BUTTON, {",
          "  x: 40, y: 240, w: 400, h: 100,",
          "  radius: 12,",
          "  normal_color: 0xfc6950,",
          "  press_color: 0xfeb4a8,",
          "  text: 'Click Me',",
          "  click_func: function() {",
          "    console.log('button clicked')",
          "  }",
          "})",
          "",
          "// 图片背景按钮 (w/h 设 -1 用图片尺寸)",
          "hmUI.createWidget(hmUI.widget.BUTTON, {",
          "  x: 192, y: 120, w: -1, h: -1,",
          "  text: 'Hello',",
          "  normal_src: 'btn_normal.png',",
          "  press_src: 'btn_press.png',",
          "  click_func: function() {",
          "    console.log('img button clicked')",
          "  }",
          "})"
        ].join("\n") },
        { t: "IMG_ANIM 帧动画", d: "播放序列帧", c: [
          "// 资源: anim/animation_0.png ~ animation_5.png",
          "var anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {",
          "  anim_path: 'anim',",
          "  anim_prefix: 'animation',",
          "  anim_ext: 'png',",
          "  anim_fps: 60,",
          "  anim_size: 36,",
          "  repeat_count: 1,  // 0=无限 1=单次",
          "  anim_status: 3,",
          "  x: 208, y: 230,",
          "  anim_complete_call: function() {",
          "    console.log('animation complete')",
          "  }",
          "})",
          "// 启动动画",
          "anim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START)",
          "// 状态: START / PAUSE / RESUME / STOP"
        ].join("\n") },
        { t: "QRCODE 二维码", d: "生成二维码（小米手环7不支持）", c: [
          "hmUI.createWidget(hmUI.widget.QRCODE, {",
          "  content: 'Hello Zepp OS',",
          "  x: 140, y: 140, w: 200, h: 200,",
          "  bg_x: 120, bg_y: 120,",
          "  bg_w: 240, bg_h: 240",
          "})"
        ].join("\n") },
        { t: "DIALOG 对话框组件", d: "自定义弹窗", c: [
          "// 需设置两次: 先按钮文字, 再内容",
          "var dialog = hmUI.createWidget(hmUI.widget.DIALOG, {",
          "  ok_text: 'OK',",
          "  cancel_text: 'CANCEL'",
          "})",
          "dialog.setProperty(hmUI.prop.MORE, {",
          "  text: 'DIALOG',",
          "  content_text_size: 40,",
          "  content_bg_color: 0x000000,",
          "  content_text_color: 0xffffff,",
          "  dialog_align_h: hmUI.align.CENTER_H,",
          "  ok_func: function() { console.log('OK') },",
          "  cancel_func: function() { console.log('CANCEL') }",
          "})",
          "dialog.setProperty(hmUI.prop.SHOW, true)"
        ].join("\n") },
        { t: "RADIO_GROUP 单选组", d: "单选按钮", c: [
          "var group = hmUI.createWidget(hmUI.widget.RADIO_GROUP, {",
          "  x: 0, y: 0, w: 480, h: 64,",
          "  select_src: 'selected.png',",
          "  unselect_src: 'unselected.png',",
          "  check_func: function(group, index, checked) {",
          "    console.log('index:', index, 'checked:', checked)",
          "  }",
          "})",
          "var btn1 = group.createWidget(hmUI.widget.STATE_BUTTON, {",
          "  x: 40, y: 200, w: 64, h: 64",
          "})",
          "var btn2 = group.createWidget(hmUI.widget.STATE_BUTTON, {",
          "  x: 190, y: 200, w: 64, h: 64",
          "})",
          "// 必须初始化才能渲染",
          "group.setProperty(hmUI.prop.INIT, btn1)"
        ].join("\n") },
        { t: "CHECKBOX_GROUP 多选组", d: "多选按钮", c: [
          "var group = hmUI.createWidget(hmUI.widget.CHECKBOX_GROUP, {",
          "  x: 0, y: 0, w: 480, h: 64,",
          "  select_src: 'selected.png',",
          "  unselect_src: 'unselected.png',",
          "  check_func: function(group, index, checked) {",
          "    console.log('index:', index, 'checked:', checked)",
          "  }",
          "})",
          "var btn1 = group.createWidget(hmUI.widget.STATE_BUTTON, {",
          "  x: 40, y: 200, w: 64, h: 64",
          "})",
          "var btn2 = group.createWidget(hmUI.widget.STATE_BUTTON, {",
          "  x: 190, y: 200, w: 64, h: 64",
          "})",
          "group.setProperty(hmUI.prop.INIT, btn1)",
          "group.setProperty(hmUI.prop.CHECKED, btn2)"
        ].join("\n") },
        { t: "SLIDE_SWITCH 滑动开关", d: "开关切换", c: [
          "var sw = hmUI.createWidget(hmUI.widget.SLIDE_SWITCH, {",
          "  x: 200, y: 200, w: 96, h: 64,",
          "  select_bg: 'switch_on.png',",
          "  un_select_bg: 'switch_off.png',",
          "  slide_src: 'radio_select.png',",
          "  slide_select_x: 40,",
          "  slide_un_select_x: 8,",
          "  checked: true,",
          "  checked_change_func: function(sw, checked) {",
          "    console.log('checked:', checked)",
          "  }",
          "})",
          "// 获取状态",
          "var isChecked = sw.getProperty(hmUI.prop.CHECKED)"
        ].join("\n") },
        { t: "SCROLL_LIST 滑动列表", d: "可滚动数据列表", c: [
          "var data = [",
          "  { name: 'a', age: 12 },",
          "  { name: 'b', age: 13 },",
          "  { name: 'c', age: 13 }",
          "]",
          "var list = hmUI.createWidget(hmUI.widget.SCROLL_LIST, {",
          "  x: 10, y: 10, w: 200, h: 454,",
          "  item_space: 10,",
          "  item_config: [{",
          "    type_id: 1,",
          "    item_bg_color: 0xef5350,",
          "    item_bg_radius: 10,",
          "    text_view: [{",
          "      x: 0, y: 0, w: 100, h: 100,",
          "      key: 'name', color: 0xffffff,",
          "      text_size: 20",
          "    }],",
          "    text_view_count: 1,",
          "    item_height: 130",
          "  }],",
          "  item_config_count: 1,",
          "  data_array: data,",
          "  data_count: data.length,",
          "  item_click_func: function(list, index) {",
          "    console.log('click:', index)",
          "  }",
          "})",
          "// 刷新数据",
          "list.setProperty(hmUI.prop.UPDATE_DATA, {",
          "  data_array: newData,",
          "  data_count: newData.length",
          "})"
        ].join("\n") },
        { t: "CYCLE_LIST 循环列表", d: "无限循环滚动", c: [
          "var imgArray = [",
          "  'number-img/0.png',",
          "  'number-img/1.png',",
          "  'number-img/2.png'",
          "]",
          "hmUI.createWidget(hmUI.widget.CYCLE_LIST, {",
          "  x: 230, y: 120, h: 300, w: 30,",
          "  data_array: imgArray,",
          "  data_size: 3,",
          "  item_height: 100,",
          "  item_bg_color: 0xffffff,",
          "  item_click_func: function(list, index) {",
          "    console.log(index)",
          "  }",
          "})"
        ].join("\n") },
        { t: "CYCLE_IMAGE_TEXT_LIST 图文循环", d: "图文滚动列表", c: [
          "var data = [",
          "  { text: '0' }, { text: '1' },",
          "  { text: '2' }, { text: '3' }",
          "]",
          "var list = hmUI.createWidget(hmUI.widget.CYCLE_IMAGE_TEXT_LIST, {",
          "  x: 0, y: 0, w: 480, h: 300,",
          "  data_array: data,",
          "  data_size: 4,",
          "  item_height: 50,",
          "  item_text_color: 0xffffff,",
          "  item_text_size: 18",
          "})",
          "// 设置顶部显示索引",
          "list.setProperty(hmUI.prop.LIST_TOP, { index: 3 })",
          "// 修改单项样式",
          "list.setProperty(hmUI.prop.ITEM_MORE, {",
          "  index: 0,",
          "  item_text_color: 0x2f4988,",
          "  item_text_size: 50",
          "})"
        ].join("\n") },
        { t: "HISTOGRAM 柱状图", d: "数据可视化", c: [
          "var chart = hmUI.createWidget(hmUI.widget.HISTOGRAM, {",
          "  x: 100, y: 120, h: 300, w: 300,",
          "  item_width: 20,",
          "  item_space: 10,",
          "  item_radius: 10,",
          "  item_start_y: 50,",
          "  item_max_height: 230,",
          "  item_color: 0x304ffe,",
          "  data_array: [20, 30, 40, 50, 60, 100, 80, 90],",
          "  data_count: 8,",
          "  data_min_value: 10,",
          "  data_max_value: 100",
          "})",
          "// 更新数据",
          "chart.setProperty(hmUI.prop.UPDATE_DATA, {",
          "  data_array: [100, 50, 80, 60],",
          "  data_count: 4",
          "})"
        ].join("\n") },
        { t: "PICK_DATE 日期选择器", d: "选择日期", c: [
          "var picker = hmUI.createWidget(hmUI.widget.PICK_DATE)",
          "picker.setProperty(hmUI.prop.MORE, {",
          "  w: 480, x: 20, y: 120,",
          "  startYear: 2000,",
          "  endYear: 2030,",
          "  initYear: 2021,",
          "  initMonth: 2,",
          "  initDay: 3",
          "})",
          "// 获取选择的日期",
          "var date = picker.getProperty(hmUI.prop.MORE, {})",
          "console.log(date.year, date.month, date.day)"
        ].join("\n") },
        { t: "GROUP 分组容器", d: "组件分组管理", c: [
          "var group = hmUI.createWidget(hmUI.widget.GROUP, {",
          "  x: 0, y: 0, w: 200, h: 200",
          "})",
          "",
          "// 创建属于该 group 的子控件",
          "group.createWidget(hmUI.widget.TEXT, {",
          "  x: 0, y: 0, w: 100, h: 50,",
          "  text: 'Hello'",
          "})"
        ].join("\n") }
      ]},

      { cat: "sensor", catName: "传感器", items: [
        { t: "TIME 时间传感器", d: "获取当前时间", c: [
          "var time = hmSensor.createSensor(hmSensor.id.TIME)",
          "console.log('year:', time.year)",
          "console.log('month:', time.month)",
          "console.log('day:', time.day)",
          "console.log('hour:', time.hour)",
          "console.log('minute:', time.minute)",
          "console.log('second:', time.second)",
          "console.log('week:', time.week)  // 1-7",
          "console.log('is24Hour:', time.is24Hour)",
          "",
          "// 注册每分钟结束事件",
          "time.addEventListener(time.event.MINUTEEND, function() {",
          "  console.log('minute end')",
          "})",
          "",
          "// 注册日期变更事件",
          "time.addEventListener(time.event.DAYCHANGE, function() {",
          "  console.log('day change')",
          "})"
        ].join("\n") },
        { t: "HEART 心率传感器", d: "读取心率数据", c: [
          "var heart = hmSensor.createSensor(hmSensor.id.HEART)",
          "",
          "// 读取心率值",
          "console.log('current:', heart.current)  // 连续测量值",
          "console.log('last:', heart.last)        // 最近测量值",
          "",
          "// 注册连续心率事件",
          "heart.addEventListener(heart.event.CURRENT, function() {",
          "  console.log('heart rate:', heart.current)",
          "})",
          "",
          "// 注册最新心率事件",
          "heart.addEventListener(heart.event.LAST, function() {",
          "  console.log('last heart rate:', heart.last)",
          "})",
          "",
          "// onDestroy 中取消注册",
          "// heart.removeEventListener(heart.event.CURRENT, callback)"
        ].join("\n") },
        { t: "STEP 步数传感器", d: "读取步数", c: [
          "var step = hmSensor.createSensor(hmSensor.id.STEP)",
          "console.log('current:', step.current)",
          "console.log('target:', step.target)",
          "",
          "// 注册步数变化事件",
          "step.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('step changed:', step.current)",
          "})"
        ].join("\n") },
        { t: "WEATHER 天气传感器", d: "获取天气预报", c: [
          "var weather = hmSensor.createSensor(hmSensor.id.WEATHER)",
          "var data = weather.getForecastWeather()",
          "console.log('city:', data.cityName)",
          "",
          "// 天气预报",
          "var forecast = data.forecastData",
          "for (var i = 0; i < forecast.count; i++) {",
          "  var f = forecast.data[i]",
          "  console.log('day', i, 'high:', f.high, 'low:', f.low)",
          "  // index: 0=阴 3=晴 4=多云 5=小雨",
          "}",
          "",
          "// 日出日落",
          "var tide = data.tideData",
          "for (var i = 0; i < tide.count; i++) {",
          "  var t = tide.data[i]",
          "  console.log('sunrise:', t.sunrise.hour + ':' + t.sunrise.minute)",
          "  console.log('sunset:', t.sunset.hour + ':' + t.sunset.minute)",
          "}"
        ].join("\n") },
        { t: "BATTERY 电池传感器", d: "获取电量/充电状态", c: [
          "var battery = hmSensor.createSensor(hmSensor.id.BATTERY)",
          "",
          "// current: 当前电量 0-100",
          "console.log('battery:', battery.current)",
          "",
          "// charging: 0=未充电 1=充电中 2=已充满",
          "console.log('charging:', battery.charging)",
          "",
          "// 注册电量变化事件",
          "battery.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('battery:', battery.current)",
          "})"
        ].join("\n") },
        { t: "CALORIE 卡路里传感器", d: "获取卡路里消耗", c: [
          "var calorie = hmSensor.createSensor(hmSensor.id.CALORIE)",
          "",
          "// current: 当日累计卡路里（千卡）",
          "console.log('calorie:', calorie.current)",
          "",
          "// 注册变化事件",
          "calorie.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('calorie:', calorie.current)",
          "})"
        ].join("\n") },
        { t: "PAI 健康活动指数", d: "获取 PAI 值", c: [
          "var pai = hmSensor.createSensor(hmSensor.id.PAI)",
          "",
          "// today: 今日 PAI",
          "// total: 总 PAI（近7天）",
          "// weekPAI: 本周每日 PAI 数组",
          "console.log('today:', pai.today)",
          "console.log('total:', pai.total)",
          "",
          "// 注册变化事件",
          "pai.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('today PAI:', pai.today)",
          "})"
        ].join("\n") },
        { t: "DISTANCE 距离传感器", d: "获取当日运动距离", c: [
          "var distance = hmSensor.createSensor(hmSensor.id.DISTANCE)",
          "",
          "// current: 当日累计距离（米）",
          "console.log('distance:', distance.current)",
          "",
          "// 注册变化事件",
          "distance.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('distance:', distance.current, 'm')",
          "})"
        ].join("\n") },
        { t: "STAND 站立传感器", d: "获取站立时长/次数", c: [
          "var stand = hmSensor.createSensor(hmSensor.id.STAND)",
          "",
          "// current: 当日站立分钟数",
          "console.log('stand:', stand.current)",
          "",
          "// target: 站立目标（分钟）",
          "console.log('target:', stand.target)",
          "",
          "// 注册变化事件",
          "stand.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('stand:', stand.current)",
          "})"
        ].join("\n") },
        { t: "SPO2 血氧传感器", d: "获取血氧饱和度", c: [
          "var spo2 = hmSensor.createSensor(hmSensor.id.SPO2)",
          "",
          "// current: 当前血氧值（%）",
          "console.log('spo2:', spo2.current)",
          "",
          "// 注册变化事件",
          "spo2.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('spo2:', spo2.current, '%')",
          "})"
        ].join("\n") },
        { t: "BODY_TEMP 体温传感器", d: "获取体温数据", c: [
          "var bodyTemp = hmSensor.createSensor(hmSensor.id.BODY_TEMP)",
          "",
          "// current: 当前体温（摄氏度）",
          "console.log('body temp:', bodyTemp.current)",
          "",
          "// 注册变化事件",
          "bodyTemp.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('body temp:', bodyTemp.current)",
          "})"
        ].join("\n") },
        { t: "STRESS 压力传感器", d: "获取压力指数", c: [
          "var stress = hmSensor.createSensor(hmSensor.id.STRESS)",
          "",
          "// current: 当前压力值（0-100）",
          "console.log('stress:', stress.current)",
          "",
          "// 注册变化事件",
          "stress.addEventListener(hmSensor.event.CHANGE, function() {",
          "  console.log('stress:', stress.current)",
          "})"
        ].join("\n") },
        { t: "SLEEP 睡眠传感器", d: "获取睡眠数据", c: [
          "var sleep = hmSensor.createSensor(hmSensor.id.SLEEP)",
          "",
          "// 获取今日睡眠数据",
          "var data = sleep.getRecentDay()",
          "",
          "// data.sleepTotal: 总睡眠时长（分钟）",
          "// data.deepSleep: 深睡时长（分钟）",
          "// data.lightSleep: 浅睡时长（分钟）",
          "// data.awakeSleep: 清醒时长（分钟）",
          "// data.score: 睡眠评分",
          "console.log('total:', data.sleepTotal, 'min')",
          "console.log('deep:', data.deepSleep, 'min')",
          "console.log('score:', data.score)",
          "",
          "// 获取历史睡眠记录",
          "var history = sleep.getRecentHistory()",
          "for (var i = 0; i < history.length; i++) {",
          "  var h = history[i]",
          "  console.log('day', i, 'total:', h.sleepTotal)",
          "}"
        ].join("\n") },
      ]},

      { cat: "hmapp", catName: "应用控制", items: [
        { t: "startApp 启动应用", d: "启动另一个小程序", c: [
          "hmApp.startApp({",
          "  appid: 1000001,",
          "  url: 'pages/index2',",
          "  param: '...'  // 传给 App onCreate",
          "})"
        ].join("\n") },
        { t: "gotoPage 页面跳转", d: "跳转到另一个页面", c: [
          "hmApp.gotoPage({",
          "  url: 'pages/index2',",
          "  param: '...'  // 传给 Page onInit",
          "})"
        ].join("\n") },
        { t: "gotoHome 返回表盘", d: "退出到表盘", c: [
          "hmApp.gotoHome()"
        ].join("\n") },
        { t: "reloadPage 重新加载", d: "重载当前页面", c: [
          "hmApp.reloadPage({",
          "  url: 'pages/index3',",
          "  param: '...'",
          "})"
        ].join("\n") },
        { t: "goBack 返回上一页", d: "返回上一页", c: [
          "// 返回上一页，第一页则退出小程序",
          "hmApp.goBack()"
        ].join("\n") },
        { t: "exit 退出应用", d: "退出到应用列表", c: [
          "hmApp.exit()"
        ].join("\n") },
        { t: "setScreenKeep 保持运行", d: "息屏后保持小程序", c: [
          "// true: 重新唤醒时恢复到小程序页面",
          "hmApp.setScreenKeep(true)"
        ].join("\n") },
        { t: "setLayerY/getLayerY 滚动", d: "页面层滚动位置", c: [
          "// 设置 y 坐标偏移",
          "hmApp.setLayerY(100)",
          "",
          "// 获取当前 y 坐标偏移",
          "var y = hmApp.getLayerY()",
          "console.log('layerY:', y)"
        ].join("\n") },
        { t: "registerGestureEvent 手势事件", d: "注册手势监听", c: [
          "// 返回 true 跳过默认行为, false 不跳过",
          "hmApp.registerGestureEvent(function(event) {",
          "  switch (event) {",
          "    case hmApp.gesture.UP:",
          "      console.log('up'); break",
          "    case hmApp.gesture.DOWN:",
          "      console.log('down'); break",
          "    case hmApp.gesture.LEFT:",
          "      console.log('left'); break",
          "    case hmApp.gesture.RIGHT:",
          "      console.log('right'); break",
          "  }",
          "  return false",
          "})"
        ].join("\n") },
        { t: "registerKeyEvent 按键事件", d: "注册按键监听", c: [
          "// key: hmApp.key.BACK/SELECT/HOME/UP/DOWN/SHORTCUT",
          "// action: hmApp.action.CLICK/LONG_PRESS/DOUBLE_CLICK/RELEASE/PRESS",
          "hmApp.registerKeyEvent(function(key, action) {",
          "  console.log('key:', key, 'action:', action)",
          "  if (key === hmApp.key.HOME) {",
          "    return true  // 跳过默认 HOME 处理",
          "  }",
          "  return false",
          "})"
        ].join("\n") },
        { t: "registerSpinEvent 表冠旋转", d: "注册旋转事件", c: [
          "// degree: 正=逆时针, 负=顺时针",
          "hmApp.registerSpinEvent(function(key, degree) {",
          "  console.log('key:', key, 'degree:', degree)",
          "})",
          "",
          "// 取消注册",
          "hmApp.unregisterSpinEvent()"
        ].join("\n") },
        { t: "alarmNew 定时唤醒", d: "定时唤醒小程序", c: [
          "// 10秒后唤醒应用",
          "var alarm = hmApp.alarmNew({",
          "  file: 'pages/index',",
          "  appid: 1000001,",
          "  delay: 10",
          "})",
          "",
          "// 取消唤醒",
          "hmApp.alarmCancel(alarm)"
        ].join("\n") }
      ]},

      { cat: "hmfs", catName: "文件系统", items: [
        { t: "open/close 打开关闭文件", d: "文件操作基础", c: [
          "// 打开文件（可读写，不存在则创建）",
          "var fileId = hmFS.open('test.txt', hmFS.O_RDWR | hmFS.O_CREAT)",
          "",
          "// 文件标志位:",
          "// O_RDONLY 只读 / O_WRONLY 只写 / O_RDWR 读写",
          "// O_APPEND 追加 / O_CREAT 创建 / O_TRUNC 截断",
          "",
          "hmFS.close(fileId)"
        ].join("\n") },
        { t: "read 读取文件", d: "读取文件内容", c: [
          "var buf = new ArrayBuffer(10)",
          "var view = new Uint8Array(buf)",
          "var file = hmFS.open('test.txt', hmFS.O_RDONLY)",
          "var result = hmFS.read(file, buf, 0, 10)",
          "hmFS.close(file)",
          "// result 为 0 表示成功"
        ].join("\n") },
        { t: "write 写入文件", d: "写入数据到文件", c: [
          "var content = 'Hello Zepp OS'",
          "var buf = new ArrayBuffer(content.length)",
          "var view = new Uint8Array(buf)",
          "for (var i = 0; i < content.length; i++) {",
          "  view[i] = content.charCodeAt(i)",
          "}",
          "var file = hmFS.open('test.txt', hmFS.O_RDWR | hmFS.O_CREAT)",
          "hmFS.write(file, buf, 0, content.length)",
          "hmFS.close(file)"
        ].join("\n") },
        { t: "seek 移动指针", d: "定位文件读写位置", c: [
          "var fileId = hmFS.open('test.txt', hmFS.O_RDWR)",
          "// 移动到起始位置",
          "hmFS.seek(fileId, 0, hmFS.SEEK_SET)",
          "// SEEK_SET / SEEK_CUR / SEEK_END",
          "hmFS.close(fileId)"
        ].join("\n") },
        { t: "stat_asset 资源文件信息", d: "获取 assets 文件大小", c: [
          "var result = hmFS.stat_asset('raw/test.txt')",
          "if (result[1] === 0) {",
          "  var stat = result[0]",
          "  console.log('size:', stat.size)",
          "  console.log('mtime:', stat.mtime)",
          "} else {",
          "  console.log('error:', result[1])",
          "}"
        ].join("\n") },
        { t: "SysPro 临时数据存储", d: "键值对存储（重启清除）", c: [
          "// 整数",
          "hmFS.SysProSetInt('count', 100)",
          "console.log(hmFS.SysProGetInt('count'))  // 100",
          "",
          "// 字符串",
          "hmFS.SysProSetChars('name', 'hello')",
          "console.log(hmFS.SysProGetChars('name'))  // hello",
          "",
          "// 其他: SysProSetBool/GetBool",
          "//       SysProSetInt64/GetInt64",
          "//       SysProSetDouble/GetDouble"
        ].join("\n") },
        { t: "stat 获取文件信息", d: "获取 /data 目录文件信息", c: [
          "var result = hmFS.stat('test.txt')",
          "var stat = result[0]",
          "var err = result[1]",
          "if (err === 0) {",
          "  console.log('size:', stat.size)",
          "  console.log('mtime:', stat.mtime)",
          "} else {",
          "  console.log('error:', err)",
          "}"
        ].join("\n") },
        { t: "open_asset 打开资源文件", d: "打开 /assets 目录文件（只读）", c: [
          "var fileId = hmFS.open_asset('test.txt', hmFS.O_RDONLY)",
          "// 读取操作...",
          "hmFS.close(fileId)"
        ].join("\n") },
        { t: "remove 删除文件", d: "删除 /data 目录文件", c: [
          "var result = hmFS.remove('test.txt')",
          "console.log(result)  // 0=成功"
        ].join("\n") },
        { t: "rename 重命名文件", d: "重命名 /data 目录文件", c: [
          "var result = hmFS.rename('old.txt', 'new.txt')",
          "console.log(result)  // 0=成功"
        ].join("\n") }
      ]},

      { cat: "hmble", catName: "蓝牙通信", items: [
        { t: "createConnect 蓝牙连接", d: "建立 BLE 连接", c: [
          "hmBle.createConnect(function(index, data, size) {",
          "  // index: 分包序号",
          "  // data: 接收到的数据",
          "  // size: 数据长度",
          "  console.log('received, index:', index, 'size:', size)",
          "  // 原样返回",
          "  hmBle.send(data, size)",
          "})",
          "",
          "// 发送消息",
          "var data = new ArrayBuffer(4)",
          "hmBle.send(data, 4)",
          "",
          "// 断开连接",
          "hmBle.disConnect()"
        ].join("\n") },
        { t: "连接状态监听", d: "监听蓝牙状态变化", c: [
          "// 查询连接状态",
          "console.log(hmBle.connectStatus())  // true=已连接",
          "",
          "// 注册状态监听",
          "hmBle.addListener(function(status) {",
          "  console.log('status:', status)",
          "})",
          "",
          "// 取消监听",
          "hmBle.removeListener()"
        ].join("\n") }
      ]},

      { cat: "hmsetting", catName: "系统设置", items: [
        { t: "屏幕亮度控制", d: "调节亮度", c: [
          "// 设置自动亮度",
          "hmSetting.setScreenAutoBright(true)",
          "var isAuto = hmSetting.getScreenAutoBright()",
          "",
          "// 设置手动亮度（0-100，需先关自动亮度）",
          "hmSetting.setScreenAutoBright(false)",
          "hmSetting.setBrightness(50)",
          "var brightness = hmSetting.getBrightness()"
        ].join("\n") },
        { t: "屏幕常亮", d: "保持亮屏", c: [
          "// 设置亮屏10秒",
          "hmSetting.setBrightScreen(10)",
          "",
          "// 取消常亮",
          "hmSetting.setBrightScreenCancel()",
          "",
          "// 关闭屏幕",
          "hmSetting.setScreenOff()"
        ].join("\n") },
        { t: "getDeviceInfo 设备信息", d: "获取屏幕尺寸等", c: [
          "var info = hmSetting.getDeviceInfo()",
          "console.log('width:', info.width)",
          "console.log('height:', info.height)",
          "console.log('screenShape:', info.screenShape)  // 0=方 1=圆",
          "console.log('deviceName:', info.deviceName)",
          "console.log('deviceSource:', info.deviceSource)"
        ].join("\n") },
        { t: "getScreenType 屏幕类型", d: "判断当前运行环境", c: [
          "var type = hmSetting.getScreenType()",
          "// hmSetting.screen_type.APP       - 在JS应用中",
          "// hmSetting.screen_type.WATCHFACE - 在表盘中",
          "// hmSetting.screen_type.SETTINGS  - 在配置页中",
          "// hmSetting.screen_type.AOD       - 在息屏中"
        ].join("\n") },
        { t: "语言与格式", d: "获取系统语言和格式", c: [
          "var lang = hmSetting.getLanguage()",
          "var mileageUnit = hmSetting.getMileageUnit()",
          "var dateFormat = hmSetting.getDateFormat()",
          "var timeFormat = hmSetting.getTimeFormat()"
        ].join("\n") },
        { t: "getUserData 用户数据", d: "获取年龄/身高/体重/性别", c: [
          "var user = hmSetting.getUserData()",
          "console.log('age:', user.age)",
          "console.log('height:', user.height)",
          "console.log('weight:', user.weight)",
          "console.log('gender:', user.gender)",
          "console.log('nickName:', user.nickName)"
        ].join("\n") },
        { t: "getDiskInfo 磁盘信息", d: "获取磁盘空间信息", c: [
          "var disk = hmSetting.getDiskInfo()",
          "console.log('total:', disk.total / 1024 / 1024, 'MB')",
          "console.log('free:', disk.free / 1024 / 1024, 'MB')",
          "console.log('app:', disk.app / 1024 / 1024, 'MB')",
          "console.log('watchface:', disk.watchface / 1024 / 1024, 'MB')"
        ].join("\n") },
        { t: "getWeightTarget 体重目标", d: "获取体重目标（kg）", c: [
          "var target = hmSetting.getWeightTarget()",
          "console.log('weight target:', target)"
        ].join("\n") },
        { t: "getSleepTarget 睡眠目标", d: "获取睡眠目标（分钟）", c: [
          "var target = hmSetting.getSleepTarget()",
          "console.log('sleep target:', target, 'min')"
        ].join("\n") },
        { t: "getWeightUnit 体重单位", d: "获取体重单位设置", c: [
          "var unit = hmSetting.getWeightUnit()",
          "// 0=千克 1=斤 2=磅 3=英石"
        ].join("\n") },
        { t: "setScreenOff 关闭屏幕", d: "主动息屏", c: [
          "var result = hmSetting.setScreenOff()",
          "// 返回 0 表示成功"
        ].join("\n") },
        { t: "getStandTarget 站立目标", d: "获取站立目标（分钟）", c: [
          "var target = hmSetting.getStandTarget()",
          "console.log('stand target:', target, 'min')"
        ].join("\n") },
        { t: "getCaloriesTarget 卡路里目标", d: "获取卡路里目标（千卡）", c: [
          "var target = hmSetting.getCaloriesTarget()",
          "console.log('calories target:', target, 'kcal')"
        ].join("\n") },
        { t: "getDistanceTarget 距离目标", d: "获取运动距离目标（米）", c: [
          "var target = hmSetting.getDistanceTarget()",
          "console.log('distance target:', target, 'm')"
        ].join("\n") },
        { t: "getRunTime 运动时长", d: "获取当日运动时长（分钟）", c: [
          "var minutes = hmSetting.getRunTime()",
          "console.log('run time:', minutes, 'min')"
        ].join("\n") }
      ]},

      { cat: "timer", catName: "定时器", items: [
        { t: "createTimer 创建定时器", d: "定时执行回调", c: [
          "var timer1 = timer.createTimer(",
          "  500,   // delay: 延迟毫秒",
          "  1000,  // repeat: 重复周期毫秒",
          "  function(option) {",
          "    console.log('timer callback')",
          "  },",
          "  {}  // 传给回调的参数",
          ")",
          "",
          "// 停止定时器",
          "timer.stopTimer(timer1)"
        ].join("\n") }
      ]},

      { cat: "example", catName: "综合示例", items: [
        { t: "完整应用：心率+步数表盘", d: "传感器+UI+定时器综合", c: [
          "// app.js",
          "App({",
          "  globalData: { count: 0 },",
          "  onCreate(param) {",
          "    console.log('App created')",
          "  },",
          "  onDestroy() {",
          "    console.log('App destroyed')",
          "  }",
          "})",
          "",
          "// pages/index.js",
          "Page({",
          "  build() {",
          "    var heart = hmSensor.createSensor(hmSensor.id.HEART)",
          "    var step = hmSensor.createSensor(hmSensor.id.STEP)",
          "    var time = hmSensor.createSensor(hmSensor.id.TIME)",
          "",
          "    // 显示时间",
          "    var timeText = hmUI.createWidget(hmUI.widget.TEXT, {",
          "      x: px(0), y: px(100), w: px(480), h: px(60),",
          "      color: 0xffffff, text_size: px(48),",
          "      align_h: hmUI.align.CENTER_H,",
          "      text: time.hour + ':' + time.minute",
          "    })",
          "",
          "    // 显示心率",
          "    var heartText = hmUI.createWidget(hmUI.widget.TEXT, {",
          "      x: px(0), y: px(200), w: px(480), h: px(40),",
          "      color: 0xff6b6b, text_size: px(24),",
          "      align_h: hmUI.align.CENTER_H,",
          "      text: 'HR: ' + heart.last + ' bpm'",
          "    })",
          "",
          "    // 显示步数",
          "    var stepText = hmUI.createWidget(hmUI.widget.TEXT, {",
          "      x: px(0), y: px(260), w: px(480), h: px(40),",
          "      color: 0x4ecdc4, text_size: px(24),",
          "      align_h: hmUI.align.CENTER_H,",
          "      text: 'Steps: ' + step.current",
          "    })",
          "",
          "    // 步数变化更新",
          "    step.addEventListener(hmSensor.event.CHANGE, function() {",
          "      stepText.setProperty(hmUI.prop.MORE, {",
          "        text: 'Steps: ' + step.current",
          "      })",
          "    })",
          "",
          "    // 定时刷新心率",
          "    var t = timer.createTimer(500, 3000, function() {",
          "      heartText.setProperty(hmUI.prop.MORE, {",
          "        text: 'HR: ' + heart.last + ' bpm'",
          "      })",
          "    }, {})",
          "",
          "    // 返回表盘按钮",
          "    hmUI.createWidget(hmUI.widget.BUTTON, {",
          "      x: px(80), y: px(380), w: px(300), h: px(60),",
          "      radius: px(12),",
          "      normal_color: 0x333333,",
          "      press_color: 0x666666,",
          "      text: 'Go Home',",
          "      click_func: function() {",
          "        hmApp.gotoHome()",
          "      }",
          "    })",
          "  },",
          "  onDestroy() {",
          "    // 清理资源",
          "  }",
          "})"
        ].join("\n") }
      ]}
    ];

    // 渲染分类标签
    var tabContainer = $("ct_tabs");
    var listContainer = $("ct_list");
    var searchInput = $("ct_search");
    var currentCat = "all";

    function renderTabs() {
      tabContainer.innerHTML = "";
      var allTab = document.createElement("button");
      allTab.className = "ct-tab active";
      allTab.textContent = "全部";
      allTab.setAttribute("data-cat", "all");
      tabContainer.appendChild(allTab);

      TEMPLATES.forEach(function (cat) {
        var tab = document.createElement("button");
        tab.className = "ct-tab";
        tab.textContent = cat.catName;
        tab.setAttribute("data-cat", cat.cat);
        tabContainer.appendChild(tab);
      });

      tabContainer.querySelectorAll(".ct-tab").forEach(function (tab) {
        tab.addEventListener("click", function () {
          tabContainer.querySelectorAll(".ct-tab").forEach(function (t) {
            t.classList.remove("active");
          });
          this.classList.add("active");
          currentCat = this.getAttribute("data-cat");
          renderList();
        });
      });
    }

    function escapeHTML(str) {
      return str.replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function renderList() {
      var query = (searchInput.value || "").trim().toLowerCase();
      listContainer.innerHTML = "";
      var count = 0;

      TEMPLATES.forEach(function (cat) {
        if (currentCat !== "all" && currentCat !== cat.cat) return;

        var visibleItems = cat.items.filter(function (item) {
          if (!query) return true;
          var text = (item.t + " " + item.d + " " + item.c).toLowerCase();
          return text.indexOf(query) !== -1;
        });

        if (visibleItems.length === 0) return;

        var catTitle = document.createElement("div");
        catTitle.className = "ct-cat-title";
        catTitle.textContent = cat.catName;
        listContainer.appendChild(catTitle);

        visibleItems.forEach(function (item) {
          var card = document.createElement("div");
          card.className = "ct-item";
          card.innerHTML =
            '<div class="ct-item-header">' +
              '<span class="ct-item-title">' + escapeHTML(item.t) + '</span>' +
              '<span class="ct-item-desc">' + escapeHTML(item.d) + '</span>' +
            '</div>' +
            '<pre class="ct-code">' + escapeHTML(item.c) + '</pre>' +
            '<div class="ct-item-actions">' +
              '<button class="btn btn-small btn-ghost ct-copy-btn">复制</button>' +
              '<button class="btn btn-small btn-ghost ct-save-btn">保存</button>' +
            '</div>';
          listContainer.appendChild(card);

          var code = item.c;
          card.querySelector(".ct-copy-btn").addEventListener("click", function () {
            copyToClipboard(code);
          });
          card.querySelector(".ct-save-btn").addEventListener("click", function () {
            var safeName = item.t.replace(/[^\w]/g, "_") + ".js";
            downloadBlob(new Blob([code], { type: "text/javascript" }), safeName, function (fn, mt) {
              showOpenButton("ct_openBtn", fn, mt);
            });
          });

          count++;
        });
      });

      if (count === 0) {
        listContainer.innerHTML = '<div class="ct-empty">没有找到匹配的模板</div>';
      }
    }

    function copyToClipboard(text) {
      if (typeof window.AndroidFileSaver !== "undefined" &&
          typeof window.AndroidFileSaver.copyText === "function") {
        window.AndroidFileSaver.copyText(text);
        hmUI.showToast({ text: "已复制到剪贴板" });
      } else {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); hmUI.showToast({ text: "已复制" }); }
        catch (e) { hmUI.showToast({ text: "复制失败" }); }
        document.body.removeChild(ta);
      }
    }

    renderTabs();
    renderList();

    searchInput.addEventListener("input", function () {
      renderList();
    });
  }

  // ===========================================================================
  // 工具: ZMake 构建
  // ===========================================================================

  function initZMakeBuild() {
    var buildMode = "zip";
    var projectZip = null;
    var projectEntries = [];
    var zmakeConfig = {
      def_format: "TGA-P",
      auto_rgba: true,
      encode_mode: "dialog",
      package_extension: "bin"
    };

    var zoneFiles = {
      appJson: null,
      appJs: null,
      page: [],
      assets: []
    };

    function zlog(msg, type) {
      var area = $("zm_logArea");
      if (area) {
        var line = document.createElement("div");
        line.className = "log-line log-" + (type || "info");
        line.textContent = msg;
        area.appendChild(line);
        area.scrollTop = area.scrollHeight;
      }
    }

    function zclearLog() {
      var area = $("zm_logArea");
      if (area) area.innerHTML = "";
    }

    function switchMode(mode) {
      buildMode = mode;
      if (mode === "zip") {
        $("zm_modeZip").classList.add("active");
        $("zm_modeFiles").classList.remove("active");
        $("zm_zipMode").classList.add("active");
        $("zm_filesMode").classList.remove("active");
      } else {
        $("zm_modeFiles").classList.add("active");
        $("zm_modeZip").classList.remove("active");
        $("zm_filesMode").classList.add("active");
        $("zm_zipMode").classList.remove("active");
        updateZoneStats();
      }
      updateModeIndicator($("zm_modeZip").parentElement);
    }

    // iOS 风格：更新模式切换滑动玻璃指示器位置
    function updateModeIndicator(toggle) {
      if (!toggle) return;
      var activeBtn = toggle.querySelector(".mode-btn.active");
      if (!activeBtn) return;
      requestAnimationFrame(function () {
        var toggleRect = toggle.getBoundingClientRect();
        var btnRect = activeBtn.getBoundingClientRect();
        toggle.style.setProperty("--mg-left", (btnRect.left - toggleRect.left) + "px");
        toggle.style.setProperty("--mg-width", btnRect.width + "px");
      });
    }

    $("zm_modeZip").addEventListener("click", function () { switchMode("zip"); });
    $("zm_modeFiles").addEventListener("click", function () { switchMode("files"); });

    // 初始化模式切换滑动玻璃指示器位置
    setTimeout(function () {
      updateModeIndicator($("zm_modeZip").parentElement);
    }, 100);

    $("zm_fileInput").addEventListener("change", function (e) {
      if (!e.target.files || e.target.files.length === 0) return;
      handleProjectZip(e.target.files[0]);
    });

    function handleProjectZip(file) {
      zclearLog();
      zlog("正在读取项目 ZIP ...", "info");
      projectZip = new JSZip();
      projectZip.loadAsync(file).then(function (zip) {
        projectEntries = [];
        var imgCount = 0, jsCount = 0, otherCount = 0;
        zip.forEach(function (path, entry) {
          if (entry.dir) return;
          var lp = path.toLowerCase();
          var isPng = lp.endsWith(".png");
          var isJs = lp.endsWith(".js");
          projectEntries.push({ path: path, entry: entry, isPng: isPng, isJs: isJs });
          if (isPng) imgCount++; else if (isJs) jsCount++; else otherCount++;
        });
        var hasAppJson = false;
        for (var i = 0; i < projectEntries.length; i++) {
          if (projectEntries[i].path.toLowerCase().endsWith("app.json")) { hasAppJson = true; break; }
        }
        if (!hasAppJson) zlog("警告: 未找到 app.json", "warning");
        zlog("项目加载完成", "success");
        zlog("  文件总数: " + projectEntries.length, "info");
        zlog("  PNG 图片: " + imgCount, "info");
        zlog("  JS 脚本: " + jsCount, "info");
        $("zm_fileStats").hidden = false;
        $("zm_fileStats").innerHTML =
          '<div class="file-stats-title">已加载项目</div>' +
          '<div class="file-stats-row">文件总数: ' + projectEntries.length + '</div>' +
          '<div class="file-stats-row">PNG 图片: ' + imgCount + '</div>' +
          '<div class="file-stats-row">JS 脚本: ' + jsCount + '</div>';
        $("zm_buildBtn").disabled = false;
        zlog("", "info");
        zlog("点击「构建项目」开始打包", "info");
      }).catch(function (err) {
        zlog("读取 ZIP 失败: " + err.message, "error");
      });
    }

    function makeFakeEntry(file) {
      return {
        _file: file,
        async: function (type) {
          if (type === "string") return file.text();
          return file.arrayBuffer();
        }
      };
    }

    function handleAppJson(file) {
      zoneFiles.appJson = file;
      $("zm_appJsonFiles").hidden = false;
      $("zm_appJsonFiles").innerHTML =
        '<div class="zone-file-item"><span class="zone-file-name">' + file.name + '</span>' +
        '<span class="zone-file-remove" data-zone="appJson">移除</span></div>';
      updateZoneStats();
    }

    function handleAppJs(file) {
      zoneFiles.appJs = file;
      $("zm_appJsFiles").hidden = false;
      $("zm_appJsFiles").innerHTML =
        '<div class="zone-file-item"><span class="zone-file-name">' + file.name + '</span>' +
        '<span class="zone-file-remove" data-zone="appJs">移除</span></div>';
      updateZoneStats();
    }

    function handlePageFiles(fileList) {
      for (var i = 0; i < fileList.length; i++) {
        zoneFiles.page.push({ file: fileList[i], name: fileList[i].name });
      }
      renderZoneList("zm_pageFiles", zoneFiles.page, "page");
      updateZoneStats();
    }

    function handleAssetsFiles(fileList) {
      for (var i = 0; i < fileList.length; i++) {
        zoneFiles.assets.push({ file: fileList[i], name: fileList[i].name });
      }
      renderZoneList("zm_assetsFiles", zoneFiles.assets, "assets");
      updateZoneStats();
    }

    function renderZoneList(containerId, arr, zoneName) {
      var container = $(containerId);
      if (arr.length === 0) { container.hidden = true; container.innerHTML = ""; return; }
      container.hidden = false;
      var html = "";
      for (var i = 0; i < arr.length; i++) {
        html += '<div class="zone-file-item"><span class="zone-file-name">' + arr[i].name + '</span>' +
          '<span class="zone-file-remove" data-zone="' + zoneName + '" data-idx="' + i + '">移除</span></div>';
      }
      container.innerHTML = html;
    }

    var toolContent = document.getElementById("toolContent");
    toolContent.querySelectorAll(".zone-files").forEach(function (container) {
      container.addEventListener("click", function (e) {
        if (e.target.classList.contains("zone-file-remove")) {
          var zone = e.target.getAttribute("data-zone");
          var idx = e.target.getAttribute("data-idx");
          if (zone === "appJson") {
            zoneFiles.appJson = null;
            $("zm_appJsonFiles").hidden = true;
            $("zm_appJsonFiles").innerHTML = "";
            $("zm_appJsonInput").value = "";
          } else if (zone === "appJs") {
            zoneFiles.appJs = null;
            $("zm_appJsFiles").hidden = true;
            $("zm_appJsFiles").innerHTML = "";
            $("zm_appJsInput").value = "";
          } else if (zone === "page") {
            zoneFiles.page.splice(parseInt(idx), 1);
            renderZoneList("zm_pageFiles", zoneFiles.page, "page");
          } else if (zone === "assets") {
            zoneFiles.assets.splice(parseInt(idx), 1);
            renderZoneList("zm_assetsFiles", zoneFiles.assets, "assets");
          }
          updateZoneStats();
        }
      });
    });

    function updateZoneStats() {
      var total = 0;
      if (zoneFiles.appJson) total++;
      if (zoneFiles.appJs) total++;
      total += zoneFiles.page.length;
      total += zoneFiles.assets.length;
      if (total === 0) {
        $("zm_fileStats").hidden = true;
        $("zm_buildBtn").disabled = true;
        return;
      }
      $("zm_fileStats").hidden = false;
      $("zm_fileStats").innerHTML =
        '<div class="file-stats-title">已选择 ' + total + ' 个文件</div>' +
        '<div class="file-stats-row">app.json: ' + (zoneFiles.appJson ? "1" : "0") + '</div>' +
        '<div class="file-stats-row">app.js: ' + (zoneFiles.appJs ? "1" : "0") + '</div>' +
        '<div class="file-stats-row">page/: ' + zoneFiles.page.length + '</div>' +
        '<div class="file-stats-row">assets/: ' + zoneFiles.assets.length + '</div>';
      $("zm_buildBtn").disabled = false;
    }

    $("zm_appJsonInput").addEventListener("change", function (e) {
      if (e.target.files && e.target.files.length > 0) handleAppJson(e.target.files[0]);
    });
    $("zm_appJsInput").addEventListener("change", function (e) {
      if (e.target.files && e.target.files.length > 0) handleAppJs(e.target.files[0]);
    });
    $("zm_pageInput").addEventListener("change", function (e) {
      if (e.target.files && e.target.files.length > 0) { handlePageFiles(e.target.files); e.target.value = ""; }
    });
    $("zm_assetsInput").addEventListener("change", function (e) {
      if (e.target.files && e.target.files.length > 0) { handleAssetsFiles(e.target.files); e.target.value = ""; }
    });

    $("zm_format").addEventListener("change", function () {
      zmakeConfig.def_format = this.value;
      updateConfigVisibility();
    });
    $("zm_autoRgba").addEventListener("change", function () {
      zmakeConfig.auto_rgba = this.checked;
    });
    $("zm_encodeMode").addEventListener("change", function () {
      zmakeConfig.encode_mode = this.value;
    });

    function updateConfigVisibility() {
      var isNone = zmakeConfig.def_format === "NONE";
      var wrap = $("zm_autoRgbaWrap");
      var encWrap = $("zm_encodeMode").closest(".form-half");
      if (wrap) wrap.style.display = isNone ? "none" : "";
      if (encWrap) encWrap.style.display = isNone ? "none" : "";
    }

    $("zm_buildBtn").addEventListener("click", function () {
      if (buildMode === "files") {
        buildFromZones();
      } else {
        if (projectEntries.length === 0) return;
        $("zm_buildBtn").disabled = true;
        zclearLog();
        zlog("开始构建项目 ...", "info");
        doBuild();
      }
    });

    function buildFromZones() {
      var entries = [];
      if (zoneFiles.appJson) {
        entries.push({ path: "app.json", entry: makeFakeEntry(zoneFiles.appJson), isPng: false, isJs: false });
      }
      if (zoneFiles.appJs) {
        entries.push({ path: "app.js", entry: makeFakeEntry(zoneFiles.appJs), isPng: false, isJs: true });
      }
      for (var i = 0; i < zoneFiles.page.length; i++) {
        var pf = zoneFiles.page[i];
        entries.push({ path: "page/" + pf.name, entry: makeFakeEntry(pf.file), isPng: false, isJs: true });
      }
      for (var j = 0; j < zoneFiles.assets.length; j++) {
        var af = zoneFiles.assets[j];
        var an = af.name.toLowerCase();
        entries.push({ path: "assets/" + af.name, entry: makeFakeEntry(af.file), isPng: an.endsWith(".png"), isJs: false });
      }
      projectEntries = entries;
      projectZip = null;
      zclearLog();
      zlog("开始构建（分区域模式）...", "info");
      zlog("  文件总数: " + entries.length, "info");
      doBuild();
    }

    function doBuild() {
      var outputZip = new JSZip();
      var defaultFormat = zmakeConfig.def_format === "NONE" ? "NONE" :
        { "TGA-P": "P", "TGA-RLP": "RLP", "TGA-16": "16", "TGA-32": "32" }[zmakeConfig.def_format] || "P";
      var encodeMode = zmakeConfig.encode_mode;
      var skipTga = (defaultFormat === "NONE");
      var imgTotal = 0, converted = 0, errors = 0;
      if (skipTga) zlog("已选择「不转换」模式，所有文件原样打包", "warning");

      function processEntry(idx) {
        if (idx >= projectEntries.length) {
          finishBuild(imgTotal, converted, errors, outputZip);
          return;
        }
        var item = projectEntries[idx];
        var path = item.path;
        var lp = path.toLowerCase();
        if (lp.endsWith(".png") && !skipTga) {
          imgTotal++;
          zlog("处理: " + path, "info");
          item.entry.async("arraybuffer").then(function (ab) {
            return loadImageFromArrayBuffer(ab, path);
          }).then(function (imageData) {
            var tgaFormat = TGAEncoder.getFormatFromFilename(path);
            if (!lp.match(/\.(p|rlp|rgb|rgba)\.png$/)) tgaFormat = defaultFormat;
            if (zmakeConfig.auto_rgba && checkHasAlpha(imageData)) {
              if (tgaFormat === "P" || tgaFormat === "RLP") {
                tgaFormat = "32";
                zlog("  -> 检测到透明通道，切换为 TGA-32", "warning");
              }
            }
            var tgaBuffer = TGAEncoder.encodeTGA(imageData, tgaFormat, encodeMode);
            outputZip.file(path, tgaBuffer);
            converted++;
            zlog("  -> TGA-" + tgaFormat + " (" + tgaBuffer.byteLength + " bytes)", "success");
            processEntry(idx + 1);
          }).catch(function (err) {
            zlog("  -> 转换失败: " + err.message + "，保留原文件", "error");
            errors++;
            item.entry.async("arraybuffer").then(function (ab) {
              outputZip.file(path, ab);
              processEntry(idx + 1);
            }).catch(function (e2) {
              zlog("  -> 读取也失败: " + path, "error");
              processEntry(idx + 1);
            });
          });
        } else {
          item.entry.async("arraybuffer").then(function (ab) {
            outputZip.file(path, ab);
            processEntry(idx + 1);
          }).catch(function (err) {
            zlog("  -> 读取失败: " + path + " (" + err.message + ")", "error");
            errors++;
            processEntry(idx + 1);
          });
        }
      }
      processEntry(0);
    }

    function finishBuild(imgTotal, converted, errors, outputZip) {
      zlog("", "info");
      zlog("构建完成!", "success");
      zlog("  图片转换: " + converted + " / " + imgTotal, "success");
      if (errors > 0) zlog("  错误: " + errors, "error");
      zlog("正在生成 .bin ...", "info");
      outputZip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 6 } }).then(function (blob) {
        var outputName = "project.bin";
        var found = false;
        for (var i = 0; i < projectEntries.length; i++) {
          if (projectEntries[i].path.toLowerCase().endsWith("app.json")) {
            projectEntries[i].entry.async("string").then(function (jsonStr) {
              try {
                var aj = JSON.parse(jsonStr);
                if (aj.app && aj.app.appName) outputName = aj.app.appName + ".bin";
              } catch (e) {}
              downloadBlob(blob, outputName);
              zlog("已保存: " + outputName, "success");
              $("zm_buildBtn").disabled = false;
            });
            found = true;
            break;
          }
        }
        if (!found) {
          downloadBlob(blob, outputName);
          zlog("已保存: " + outputName, "success");
          $("zm_buildBtn").disabled = false;
        }
      });
    }

    function loadImageFromArrayBuffer(arrayBuffer, filename) {
      return new Promise(function (resolve, reject) {
        var blob = new Blob([arrayBuffer]);
        var url = URL.createObjectURL(blob);
        var img = new Image();
        img.onload = function () {
          var canvas = document.createElement("canvas");
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          var ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0);
          try {
            var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            URL.revokeObjectURL(url);
            resolve(imageData);
          } catch (e) {
            URL.revokeObjectURL(url);
            reject(new Error("无法读取像素: " + filename));
          }
        };
        img.onerror = function () {
          URL.revokeObjectURL(url);
          reject(new Error("无法加载图片: " + filename));
        };
        img.src = url;
      });
    }

    function checkHasAlpha(imageData) {
      var data = imageData.data;
      for (var i = 3; i < data.length; i += 4) {
        if (data[i] < 255) return true;
      }
      return false;
    }

    $("zm_newProjectBtn").addEventListener("click", async function () {
      zclearLog();
      var type = $("zm_projectType").value;
      zlog("创建" + (type === "watchface" ? "表盘" : "应用") + "模板项目...", "info");
      try {
        await createNewProject(type, zlog);
        zlog("项目模板已生成并下载", "success");
      } catch (e) {
        zlog("创建失败: " + e.message, "error");
      }
    });
  }

  async function createNewProject(type, zlog) {
    var JSZip = window.JSZip;
    if (!JSZip) throw new Error("JSZip 未加载");
    var zip = new JSZip();
    var isWatchface = (type === "watchface");
    var appId = Math.floor(Math.random() * 2147483647);
    var appJson;
    if (isWatchface) {
      appJson = {
        "configVersion": "v2",
        "app": { "appIdType": 0, "appType": "watchface", "version": { "code": 1, "name": "1.0.0" }, "appId": appId, "appName": "MyWatchface", "icon": "icon.png", "vender": "", "description": "" },
        "permissions": [], "runtime": { "apiVersion": { "compatible": "1.0.0", "target": "1.0.1", "minVersion": "1.0.0" } }, "i18n": {}, "debug": false, "module": {}
      };
    } else {
      appJson = {
        "configVersion": "v2",
        "app": { "appIdType": 0, "appType": "app", "version": { "code": 1, "name": "1.0.0" }, "appId": appId, "appName": "MyApp", "icon": "icon.png", "vender": "", "description": "" },
        "permissions": [], "runtime": { "apiVersion": { "compatible": "1.0.0", "target": "1.0.1", "minVersion": "1.0.0" } }, "i18n": {}, "debug": false,
        "module": { "page": { "pages": ["page/index"], "window": { "navigationBarBackgroundColor": "#ffffff", "navigationBarTextStyle": "black", "navigationBarTitleText": "", "backgroundColor": "#eeeeee", "backgroundTextStyle": "light" } } }
      };
    }
    zip.file("app.json", JSON.stringify(appJson, null, 2));
    var appJs = "(() => {\n    var __$$app$$__ = __$$hmAppManager$$__.currentApp;\n    __$$app$$__.app = DeviceRuntimeCore.App({\n        globalData: {},\n        onCreate(options) {},\n        onShow(options) {},\n        onHide(options) {},\n        onDestroy(options) {},\n        onError(error) {},\n        onPageNotFound(obj) {},\n        onUnhandledRejection(obj) {}\n    });\n})()";
    zip.file("app.js", appJs);
    var indexJs;
    if (isWatchface) {
      indexJs = "let __$$app$$__ = __$$hmAppManager$$__.currentApp;\nlet __$$module$$__ = __$$app$$__.current;\n__$$module$$__.module = DeviceRuntimeCore.WatchFace({\n  onInit() {\n\n    // Create widgets, timers, call functions here\n\n  },\n  onDestroy() {\n\n    // On destroy, remove if not required\n\n  }\n});";
      zip.file("index.js", indexJs);
    } else {
      indexJs = "let __$$app$$__ = __$$hmAppManager$$__.currentApp;\nlet __$$module$$__ = __$$app$$__.current;\n__$$module$$__.module = DeviceRuntimeCore.Page({\n  onInit() {\n\n    // Create widgets, timers, call functions here\n\n  },\n  onDestroy() {\n\n    // On destroy, remove if not required\n\n  }\n});";
      zip.folder("page").file("index.js", indexJs);
    }
    zip.folder("assets");
    var zmakeJson = { "def_format": "TGA-P", "auto_rgba": true, "package_extension": "bin", "encode_mode": "dialog", "overrides": {}, "esbuild": false, "with_uglifyjs": false, "with_adb": false, "common_files": ["README.txt", "LICENSE.txt"], "ignore_files": [".gitignore", ".DS_Store", "Thumbs.db"] };
    zip.file("zmake.json", JSON.stringify(zmakeJson, null, 2));
    zip.file("README.txt", "ZeppOS " + (isWatchface ? "表盘" : "应用") + "项目\n使用 ZeppBox ZMake 构建工具打包\n将图片放入 assets/ 目录，编辑 app.json 和 JS 文件\n选择项目 ZIP 或分区域选择文件后点击构建即可生成 .bin\n");
    zlog("  app.json - appId: " + appId, "info");
    zlog("  app.js - 应用入口", "info");
    zlog("  " + (isWatchface ? "index.js" : "page/index.js") + " - 模板", "info");
    zlog("  assets/ - 资源目录", "info");
    zlog("  zmake.json - 构建配置", "info");
    var blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
    var projectName = isWatchface ? "new_watchface" : "new_app";
    downloadBlob(blob, projectName + ".zip");
  }

  // ===========================================================================
  // 蓝牙管理
  // ===========================================================================

  function initBleManager() {
    var bleLog = $("ble_logArea");
    var scanResults = $("ble_scanResults");
    var appCard = $("ble_appCard");
    var connectBtn = $("ble_connectBtn");
    var disconnectBtn = $("ble_disconnectBtn");
    var scanBtn = $("ble_scanBtn");
    var scanAllBtn = $("ble_scanAllBtn");
    var stopScanBtn = $("ble_stopScanBtn");
    var scanDevices = [];
    var savedDevice = null;
    var autoReconnectAttempted = false;

    // OronBox 风格: 新 UI 元素
    var devicePanel = $("ble_devicePanel");
    var statusGrid = $("ble_statusGrid");
    var queueCard = $("ble_queueCard");
    var queueList = $("ble_queueList");
    var queueStartBtn = $("ble_queueStartBtn");
    var queueClearBtn = $("ble_queueClearBtn");
    var deviceNameEl = $("ble_deviceName");
    var statusDot = document.querySelector(".oron-status-dot");
    var statusText = $("ble_statusText");
    var installAppBtn = $("ble_installAppBtn");
    var installWfBtn = $("ble_installWfBtn");
    var connectCard = $("ble_connectCard");
    var connectToggle = $("ble_connectToggle");
    var connectBody = $("ble_connectBody");
    var queueIsRunning = false;
    var installQueue = [];

    // ============= 持久化设备 =============

    function loadSavedDevice() {
      try {
        if (window.AndroidBridge) {
          var json = AndroidBridge.getSavedDevice();
          if (json && json !== "null") {
            savedDevice = JSON.parse(json);
            return savedDevice;
          }
        }
      } catch (e) {}
      return null;
    }

    function saveDevice(mac, authKey, name) {
      savedDevice = { mac: mac, authKey: authKey, name: name };
      if (window.AndroidBridge) {
        AndroidBridge.saveDevice(mac, authKey, name);
      }
    }

    function clearSavedDevice() {
      savedDevice = null;
      if (window.AndroidBridge) {
        AndroidBridge.clearSavedDevice();
      }
    }

    // ============= OronBox 风格: 连接阶段显示 =============

    function updateConnectionPhase(phase) {
      var steps = document.querySelectorAll(".oron-phase-step");
      var phases = ["preparing", "transport", "protocol", "auth", "done"];
      var idx = phases.indexOf(phase);
      if (idx < 0) return;
      steps.forEach(function(step, i) {
        step.classList.remove("active", "done");
        if (i < idx) step.classList.add("done");
        if (i === idx) step.classList.add("active");
      });
    }

    function resetConnectionPhases() {
      var steps = document.querySelectorAll(".oron-phase-step");
      steps.forEach(function(step) {
        step.classList.remove("active", "done");
      });
      var first = steps[0];
      if (first) first.classList.add("active");
    }

    // ============= OronBox 风格: 状态网格更新 =============

    function updateBattery(batteryPct, charging) {
      var val = $("ble_batteryValue");
      var bar = $("ble_batteryBar");
      if (val) val.textContent = (batteryPct != null) ? (batteryPct + "%" + (charging ? " ⚡" : "")) : "--";
      if (bar) bar.style.width = (batteryPct != null) ? batteryPct + "%" : "0%";
      // 更新小组件电量
      if (batteryPct != null) {
        _updateWidget(null, null, batteryPct + "%" + (charging ? " ⚡" : ""));
      }
    }

    function updateSignalStrength(rssi) {
      var el = $("ble_signalStrength");
      var bar = $("ble_signalBar");
      var row = $("ble_signalRow");
      if (!el || rssi == null) return;
      // 确保信号行可见
      if (row) row.style.display = "";
      // RSSI 范围: -30 (最强) 到 -100 (最弱)
      var pct = Math.max(0, Math.min(100, (rssi + 100) * 100 / 70));
      var bars = pct >= 80 ? 4 : pct >= 55 ? 3 : pct >= 30 ? 2 : pct >= 10 ? 1 : 0;
      var label = bars >= 4 ? "优秀" : bars >= 3 ? "良好" : bars >= 2 ? "一般" : bars >= 1 ? "弱" : "无信号";
      if (el) el.textContent = rssi + " dBm (" + label + ")";
      if (bar) {
        bar.style.width = pct + "%";
        bar.className = "oron-signal-fill s" + bars;
      }
      blog("信号强度: " + rssi + " dBm (" + label + ")", "info");
    }

    var deviceInfoData = {
      manufacturer: null,
      model: null,
      serial: null,
      firmware: null
    };

    function updateDeviceInfoCard(model) {
      var val = $("ble_deviceModel");
      if (val) val.textContent = model || "--";
    }

    function updateDeviceInfo(mfr, model, sn, fw) {
      if (mfr != null) { deviceInfoData.manufacturer = mfr; window._deviceInfoManufacturer = mfr; }
      if (model != null) { deviceInfoData.model = model; window._deviceInfoModel = model; }
      if (sn != null) { deviceInfoData.serial = sn; window._deviceInfoSerial = sn; }
      if (fw != null) { deviceInfoData.firmware = fw; window._deviceInfoFirmware = fw; }
      updateDeviceInfoCard(deviceInfoData.model);
    }

    function updateAppsCount(count) {
      var val = $("ble_appsCount");
      if (val) val.textContent = (count != null) ? count : "0";
    }

    function updateWatchfacesCount(count) {
      var val = $("ble_watchfacesCount");
      if (val) val.textContent = (count != null) ? count : "0";
    }

    function formatSize(bytes) {
      if (!bytes || bytes < 0) return "0 B";
      if (bytes < 1024) return bytes + " B";
      if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
      return (bytes / 1048576).toFixed(1) + " MB";
    }

    function updateTransferRate(uploadBps, downloadBps) {
      // 传输速率已移除
    }

    // ============= 安装队列管理 =============
    // 原生层 (BleManager) 完全管理队列: addToQueue → processQueue → 自动串行安装
    // JS 层只负责: 渲染队列 UI + 转发用户操作到原生层

    function renderQueueList() {
      if (!queueList) return;
      if (installQueue.length === 0) {
        queueList.innerHTML = '<div style="color:var(--text-muted);text-align:center;padding:16px 0;font-size:13px">队列为空</div>';
        if (queueCard) queueCard.style.display = "none";
        return;
      }
      if (queueCard) queueCard.style.display = "";
      var html = "";
      for (var i = 0; i < installQueue.length; i++) {
        var item = installQueue[i];
        var isRunning = (item.status === "安装中" || item.status === "INSTALLING" || item.status === "installing");
        var iconSvg = item.type === "watchface"
          ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg>'
          : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="3" width="8" height="8" rx="1.5"/><rect x="14" y="3" width="8" height="8" rx="1.5"/><rect x="2" y="14" width="8" height="8" rx="1.5"/><rect x="14" y="14" width="8" height="8" rx="1.5"/></svg>';
        var runningClass = isRunning ? ' oron-queue-item-running' : '';
        html += '<div class="oron-queue-item' + runningClass + '" data-qidx="' + i + '">';
        html += '<div class="oron-queue-item-icon">' + iconSvg + '</div>';
        html += '<div class="oron-queue-item-info">';
        html += '<div class="oron-queue-item-name">' + escapeHtml(item.name || "未知") + '</div>';
        html += '<div class="oron-queue-item-status">' + (item.status || "等待中") + '</div>';
        if (item.percent != null && item.percent > 0) {
          html += '<div class="oron-queue-item-progress"><div class="oron-queue-item-progress-fill" style="width:' + item.percent + '%"></div></div>';
        }
        html += '</div>';
        if (item.status === "等待中" || item.status === "PENDING" || item.status === "pending") {
          html += '<button class="oron-queue-item-remove" data-qidx="' + i + '"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>';
        }
        html += '</div>';
      }
      queueList.innerHTML = html;

      var removeBtns = queueList.querySelectorAll(".oron-queue-item-remove");
      for (var j = 0; j < removeBtns.length; j++) {
        removeBtns[j].addEventListener("click", function(e) {
          e.stopPropagation();
          var qidx = parseInt(this.getAttribute("data-qidx"));
          var removed = installQueue[qidx];
          if (removed && removed.id && window.AndroidBridge) {
            AndroidBridge.cancelQueueItem(removed.id);
          }
          installQueue.splice(qidx, 1);
          renderQueueList();
          blog("已从队列移除: " + (removed ? removed.name : ""), "info");
        });
      }
    }

    function addToQueue(name, itemId, type) {
      installQueue.push({
        id: itemId,
        name: name,
        type: type || "app",
        status: "等待中",
        percent: null
      });
      renderQueueList();
      blog("已加入安装队列: " + name, "info");
    }

    function updateQueueItemProgress(itemId, percent, status) {
      for (var i = 0; i < installQueue.length; i++) {
        var item = installQueue[i];
        if (item.id === itemId || item.name === itemId) {
          item.percent = percent;
          item.status = status || "安装中...";
          renderQueueList();
          updateInstallProgress(percent, status);
          return;
        }
      }
    }

    function _markQueueItemDone(itemId, status, msg) {
      for (var i = 0; i < installQueue.length; i++) {
        if (installQueue[i].id === itemId) {
          installQueue[i].status = status;
          installQueue[i].percent = (status === "完成") ? 100 : 0;
          break;
        }
      }
      renderQueueList();
    }

    // ============= OronBox 风格: 长按卸载菜单 =============

    var contextMenuEl = null;

    function dismissContextMenu() {
      if (contextMenuEl) {
        contextMenuEl.remove();
        contextMenuEl = null;
      }
    }

    function showContextMenu(x, y, appId, appName, idx) {
      dismissContextMenu();
      var menu = document.createElement("div");
      menu.className = "oron-app-context-menu";
      menu.style.left = Math.min(x, window.innerWidth - 160) + "px";
      menu.style.top = Math.min(y, window.innerHeight - 140) + "px";
      menu.innerHTML =
        '<button class="oron-context-menu-item" data-action="info">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>' +
        '查看详情</button>' +
        '<div class="oron-context-menu-divider"></div>' +
        '<button class="oron-context-menu-item danger" data-action="uninstall">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
        '卸载应用</button>';
      document.body.appendChild(menu);
      contextMenuEl = menu;

      menu.querySelector('[data-action="uninstall"]').addEventListener("click", function() {
        dismissContextMenu();
        if (confirm("确定要卸载 " + appName + " 吗?")) {
          blog("正在卸载应用: " + appName + " (ID:" + appId + ")", "info");
          if (window.BleBridge) BleBridge.uninstallApp(appId);
        }
      });
      menu.querySelector('[data-action="info"]').addEventListener("click", function() {
        dismissContextMenu();
        blog("应用 " + appName + " ID: " + appId + " 索引: " + idx, "info");
      });

      setTimeout(function() {
        document.addEventListener("click", dismissContextMenu, { once: true });
        document.addEventListener("touchstart", dismissContextMenu, { once: true });
      }, 50);
    }

    // ============= 连接设置面板折叠 =============

    if (connectToggle && connectBody) {
      connectToggle.addEventListener("click", function() {
        if (connectCard.classList.contains("collapsed")) {
          connectCard.classList.remove("collapsed");
        } else {
          connectCard.classList.add("collapsed");
        }
      });
    }

    function autoCollapseConnectCard() {
      if (connectCard) connectCard.classList.add("collapsed");
    }

    // ============= 日志 =============

    function blog(msg, type) {
      if (!bleLog) return;
      // 日志级别过滤
      var t = type || "info";
      if (_logLevel === "error" && t !== "error") return;
      if (_logLevel === "info" && t !== "info" && t !== "success" && t !== "warning" && t !== "error") return;
      var line = document.createElement("div");
      line.className = "log-line log-" + t;
      var time = new Date().toTimeString().substring(0, 8);
      line.textContent = "[" + time + "] " + msg;
      bleLog.appendChild(line);
      bleLog.scrollTop = bleLog.scrollHeight;
    }

    function clearLog() {
      if (bleLog) bleLog.innerHTML = "";
    }

    function setConnectedState(state) {
      if (state === "connected" || state === "authenticated") {
        connectBtn.disabled = true;
        disconnectBtn.disabled = false;
      } else {
        connectBtn.disabled = false;
        disconnectBtn.disabled = true;
      }
      if (state === "authenticated") {
        // iOS 风格通知：设备已连接
        _updateNotification(
          "ZeppBox",
          "\u5df2\u8fde\u63a5\uff1a" + (savedDevice ? (savedDevice.name || savedDevice.mac) : "")
        );
        // 更新小组件
        _updateWidget(
          savedDevice ? (savedDevice.name || savedDevice.mac) : "ZeppBox",
          "connected",
          _widgetBattery
        );
        // OronBox 风格: 显示设备面板和状态网格
        if (devicePanel) devicePanel.style.display = "";
        if (statusGrid) statusGrid.style.display = "";
        if (appCard) appCard.style.display = "";

        // 绑定电量卡片点击刷新（在认证成功后立即绑定，确保超时后也能点击刷新）
        var batteryCard = document.getElementById("ble_batteryCard");
        if (batteryCard && !batteryCard._clickBound) {
          batteryCard._clickBound = true;
          batteryCard.style.cursor = "pointer";
          batteryCard.addEventListener("click", function(e) {
            _manualRefreshBattery();
          });
        }
        if (statusDot) {
          statusDot.classList.remove("disconnected", "connecting");
          statusDot.classList.add("connected");
        }
        if (statusText) statusText.textContent = "已连接";
        // 显示信号强度行
        var signalRow = $("ble_signalRow");
        if (signalRow) signalRow.style.display = "";
        // 显示传输速率
        updateTransferRate(0, 0);
        // 启动 RSSI 定时轮询（每5秒一次）
        if (_rssiTimer) { clearInterval(_rssiTimer); _rssiTimer = null; }
        _rssiTimer = setInterval(function() {
          if (window.BleBridge) {
            try { BleBridge.requestRssi(); } catch(e) {}
          }
        }, 5000);
        // 立即请求一次
        if (window.BleBridge) {
          try { BleBridge.requestRssi(); } catch(e) {}
        }
        // 更新连接阶段为就绪
        updateConnectionPhase("done");
        // 自动折叠连接设置面板
        autoCollapseConnectCard();
        blog("认证成功，设备已就绪", "success");
        var mac = ($("ble_mac").value || "").trim();
        var authKey = ($("ble_authkey").value || "").trim();
        if (mac && authKey) {
          var name = "";
          for (var i = 0; i < scanDevices.length; i++) {
            if (scanDevices[i].mac === mac) {
              name = scanDevices[i].name;
              break;
            }
          }
          saveDevice(mac, authKey, name);
          if (deviceNameEl && name) deviceNameEl.textContent = name;
          blog("设备信息已保存，下次打开自动连接", "info");
        }
      } else if (state === "connected") {
        if (statusDot) {
          statusDot.classList.remove("disconnected", "connected");
          statusDot.classList.add("connecting");
        }
        if (statusText) statusText.textContent = "正在认证...";
        updateConnectionPhase("auth");
        // iOS 风格通知：正在认证
        _updateNotification("ZeppBox", "\u6b63\u5728\u8ba4\u8bc1...");
        // 更新小组件
        _updateWidget(null, "connecting", "");
      } else if (state === "disconnected") {
        if (statusDot) {
          statusDot.classList.remove("connected", "connecting");
          statusDot.classList.add("disconnected");
        }
        if (statusText) statusText.textContent = "未连接";
        // 隐藏信号强度行
        var signalRow = $("ble_signalRow");
        if (signalRow) signalRow.style.display = "none";
        // 停止 RSSI 轮询
        if (_rssiTimer) { clearInterval(_rssiTimer); _rssiTimer = null; }
        // 隐藏传输速率
        updateTransferRate(null, null);
        resetConnectionPhases();
        updateConnectionPhase("preparing");
        // 如果有已保存设备，保持设备面板显示并尝试自动重连
        if (savedDevice) {
          // iOS 风格通知：断线重连
          _updateNotification("ZeppBox", "\u5df2\u65ad\u5f00\u8fde\u63a5\uff0c\u6b63\u5728\u91cd\u65b0\u8fde\u63a5...");
          // 更新小组件
          _updateWidget(null, "disconnected", "");
          blog("连接已断开，正在尝试重新连接...", "warning");
          // 保持设备面板可见，不清空设备信息
          if (deviceNameEl) {
            var macSuffix2 = "";
            if (savedDevice && savedDevice.mac) {
              macSuffix2 = " (" + savedDevice.mac.replace(/:/g, "").slice(-4) + ")";
            }
            deviceNameEl.textContent = "Xiaomi Smart Band 7" + macSuffix2;
          }
          // 延迟重连
          setTimeout(function () {
            if (window.BleBridge) {
              clearLog();
              setConnectedState("connecting");
              BleBridge.connect(savedDevice.mac, savedDevice.authKey);
            }
          }, 1500);
        } else {
          // 无已保存设备：隐藏面板，展开连接面板，取消通知
          _cancelNotification();
          // 更新小组件
          _updateWidget("ZeppBox", "disconnected", "");
          if (devicePanel) devicePanel.style.display = "none";
          if (statusGrid) statusGrid.style.display = "none";
          if (appCard) appCard.style.display = "none";
          if (queueCard) queueCard.style.display = "none";
          if (connectCard) connectCard.classList.remove("collapsed");
        }
      } else if (state === "connecting") {
        if (statusDot) {
          statusDot.classList.remove("disconnected", "connected");
          statusDot.classList.add("connecting");
        }
        if (statusText) statusText.textContent = "连接中...";
        if (devicePanel) devicePanel.style.display = "";
        updateConnectionPhase("transport");
        // iOS 风格通知：正在连接
        _updateNotification("ZeppBox", "\u6b63\u5728\u8fde\u63a5\u8bbe\u5907...");
        // 更新小组件
        _updateWidget(null, "connecting", "");
      }
    }

    // ============= iOS 风格通知辅助函数 =============
    function _updateNotification(title, text) {
      if (window.AndroidBridge && window.AndroidBridge.showNotification) {
        try {
          AndroidBridge.showNotification(title, text);
        } catch (e) {}
      }
    }

    function _cancelNotification() {
      if (window.AndroidBridge && window.AndroidBridge.cancelNotification) {
        try {
          AndroidBridge.cancelNotification();
        } catch (e) {}
      }
    }

    // ============= 屏幕小组件更新 =============
    var _widgetDeviceName = "ZeppBox";
    var _widgetStatus = "disconnected";
    var _widgetBattery = "";

    function _updateWidget(name, status, battery) {
      if (name != null) _widgetDeviceName = name;
      if (status != null) _widgetStatus = status;
      if (battery !== undefined) _widgetBattery = battery;
      var displayName = _widgetDeviceName;
      if (savedDevice && savedDevice.mac) {
        var macClean = savedDevice.mac.replace(/:/g, "");
        var macLast4 = macClean.slice(-4);
        displayName = "Xiaomi Smart Band 7 (" + macLast4 + ")";
      }
      if (window.AndroidBridge && window.AndroidBridge.updateWidget) {
        try {
          AndroidBridge.updateWidget(displayName, _widgetStatus, _widgetBattery);
        } catch (e) {}
      }
    }

    function _requestPinWidget() {
      if (window.AndroidBridge && window.AndroidBridge.requestPinWidget) {
        try {
          AndroidBridge.requestPinWidget();
          blog("正在请求添加桌面小组件...", "info");
        } catch (e) {
          blog("添加小组件失败: " + e, "error");
        }
      } else {
        blog("当前系统不支持一键添加小组件，请长按桌面手动添加", "warning");
      }
    }

    // ============= OronBox 风格: 连接后自动刷新设备信息 =============
    var _autoRefreshTimer = null;
    var _autoRefreshRetryCount = 0;
    var _autoRefreshMaxRetry = 5;  // 添加重试次数，适配慢速设备
    var _deviceInfoReceived = false;
    var _batteryInfoReceived = false;
    var _manualRefreshing = false;  // 手动刷新标志，跳过自动重试限制
    var _rssiTimer = null;  // RSSI 定时轮询

    function _autoRefreshOnConnect() {
      _deviceInfoReceived = false;
      _batteryInfoReceived = false;
      _autoRefreshRetryCount = 0;
      _manualRefreshing = false;
      // 清除之前的定时器
      if (_autoRefreshTimer) { clearTimeout(_autoRefreshTimer); _autoRefreshTimer = null; }
      // 立即请求一次
      _doAutoRefresh();
    }

    function _doAutoRefresh() {
      if (!_manualRefreshing && _autoRefreshRetryCount >= _autoRefreshMaxRetry) {
        if (!_deviceInfoReceived) blog("设备信息获取超时，请点击设备信息卡片手动刷新", "warning");
        if (!_batteryInfoReceived) blog("电量信息获取超时，请点击电量卡片手动刷新", "warning");
        return;
      }
      _autoRefreshRetryCount++;
      if (!_deviceInfoReceived && window.BleBridge) {
        try { BleBridge.requestDeviceInfo(); } catch(e) { blog("请求设备信息失败: " + e, "error"); }
      }
      if (!_batteryInfoReceived && window.BleBridge) {
        try { BleBridge.requestBattery(); } catch(e) { blog("请求电量失败: " + e, "error"); }
      }
      // 请求信号强度
      if (window.BleBridge) {
        try { BleBridge.requestRssi(); } catch(e) {}
      }
      // 3秒后如果还没收到，重试
      _autoRefreshTimer = setTimeout(function() {
        if (!_deviceInfoReceived || !_batteryInfoReceived) {
          _doAutoRefresh();
        }
      }, 3000);
    }

    // 手动刷新电量（点击电量卡片触发）
    function _manualRefreshBattery() {
      if (!window.BleBridge) { blog("BLE 桥接不可用", "error"); return; }
      _manualRefreshing = true;
      _batteryInfoReceived = false;
      _autoRefreshRetryCount = 0;
      if (_autoRefreshTimer) { clearTimeout(_autoRefreshTimer); _autoRefreshTimer = null; }
      blog("手动刷新电量...", "info");
      try { BleBridge.requestBattery(); } catch(e) { blog("请求电量失败: " + e, "error"); }
      // 如果3秒后还没收到，重试
      _autoRefreshTimer = setTimeout(function() {
        if (!_batteryInfoReceived) {
          _doAutoRefresh();
        }
      }, 3000);
    }

    // 手动刷新设备信息（点击设备信息卡片触发）
    function _manualRefreshDeviceInfo() {
      if (!window.BleBridge) { blog("BLE 桥接不可用", "error"); return; }
      _manualRefreshing = true;
      _deviceInfoReceived = false;
      _autoRefreshRetryCount = 0;
      if (_autoRefreshTimer) { clearTimeout(_autoRefreshTimer); _autoRefreshTimer = null; }
      blog("手动刷新设备信息...", "info");
      try { BleBridge.requestDeviceInfo(); } catch(e) { blog("请求设备信息失败: " + e, "error"); }
      _autoRefreshTimer = setTimeout(function() {
        if (!_deviceInfoReceived) {
          _doAutoRefresh();
        }
      }, 3000);
    }

    // 标记数据已收到（在对应回调中调用）
    function _markDeviceInfoReceived() {
      _deviceInfoReceived = true;
      _manualRefreshing = false;
    }
    function _markBatteryInfoReceived() {
      _batteryInfoReceived = true;
      _manualRefreshing = false;
      
      // 更新电池卡片点击事件（仅在首次收到电量后绑定）
      var batteryCard = document.getElementById("ble_batteryCard");
      if (batteryCard && !batteryCard._clickBound) {
        batteryCard._clickBound = true;
        batteryCard.style.cursor = "pointer";
        batteryCard.addEventListener("click", function(e) {
          _manualRefreshBattery();
        });
      }
    }

    // ============= BLE 事件 =============

    window.bleEvent = {
      scanResult: function (name, mac, rssi) {
        for (var i = 0; i < scanDevices.length; i++) {
          if (scanDevices[i].mac === mac) {
            scanDevices[i].rssi = rssi;
            scanDevices[i].name = name;
            renderScanResults();
            return;
          }
        }
        scanDevices.push({ name: name, mac: mac, rssi: rssi });
        renderScanResults();
        // 自动重连：如果扫描到已保存的设备，自动连接
        tryAutoReconnect(mac, name);
      },
      connected: function () {
        blog("BLE 已连接，正在发现服务...", "success");
        setConnectedState("connected");
        updateConnectionPhase("protocol");
      },
      disconnected: function () {
        blog("设备已断开", "warning");
        setConnectedState("disconnected");
      },
      authSuccess: function () {
        setConnectedState("authenticated");
        // OronBox 风格: 连接成功后立即自动刷新设备信息和电量
        _autoRefreshOnConnect();
      },
      authFail: function (reason) {
        blog("认证失败: " + reason, "error");
        setConnectedState("disconnected");
      },
      deviceInfo: function (fw, sn, model, mfr) {
        updateDeviceInfo(mfr, model, sn, fw);
        _markDeviceInfoReceived();
        if (deviceNameEl && model) {
          var macSuffix = "";
          if (savedDevice && savedDevice.mac) {
            macSuffix = " (" + savedDevice.mac.replace(/:/g, "").slice(-4) + ")";
          }
          deviceNameEl.textContent = "Xiaomi Smart Band 7" + macSuffix;
        }
        if (fw) blog("固件: " + fw, "info");
        if (sn) blog("序列号: " + sn, "info");
        if (model) blog("型号: " + model, "info");
        if (mfr) blog("制造商: " + mfr, "info");
      },
      batteryInfo: function (level, charging) {
        updateBattery(level, charging);
        _markBatteryInfoReceived();
      },
      rssiRead: function (rssi) {
        updateSignalStrength(rssi);
      },
      appList: function (appsJson) {
        renderAppList(appsJson);
      },
      // === 队列事件（原生层管理队列，JS 只渲染） ===
      queueItemAdded: function (data) {
        var parts = data.split(":");
        var itemId = parts[0], appName = parts[1] || "未知", appType = parts[4] || parts[2] || "app";
        addToQueue(appName, itemId, appType === "watchface" ? "watchface" : "app");
        blog("队列新增: " + appName + " (" + appType + ")", "info");
      },
      queueItemCompleted: function (data) {
        var parts = data.split(":");
        var itemId = parts[0], msg = parts[1] || "安装成功";
        _markQueueItemDone(itemId, "完成", msg);
        blog("安装完成: " + msg, "success");
      },
      queueItemFailed: function (data) {
        var parts = data.split(":");
        var itemId = parts[0], msg = parts[1] || "安装失败";
        _markQueueItemDone(itemId, "失败", msg);
        blog("安装失败: " + msg, "error");
      },
      queueProgress: function (data) {
        var parts = data.split(":");
        if (parts.length >= 2) {
          var percent = parseInt(parts[1]) || 0;
          var status = parts.slice(2).join(":") || "安装中...";
          updateQueueItemProgress(parts[0], percent, status);
        }
      },
      queueChanged: function (queueJson) {
        // 队列变化由 installQueue 和 renderQueueList 处理
      },
      queueItemRemoved: function (itemId) {
        // 从 JS 队列中移除对应项
        for (var i = 0; i < installQueue.length; i++) {
          if (installQueue[i].id === itemId) {
            installQueue.splice(i, 1);
            break;
          }
        }
        renderQueueList();
        blog("队列项已移除", "info");
      },
      queueCleared: function () {
        installQueue = [];
        queueIsRunning = false;
        if (queueStartBtn) queueStartBtn.textContent = "开始";
        renderQueueList();
        blog("队列已清空", "info");
      },
      log: function (msg) {
        blog(msg, "info");
      },
      error: function (msg) {
        blog(msg, "error");
      }
    };

    // ============= 自动重连（类似 OronBox 的自动连接） =============

    function tryAutoReconnect(mac, name) {
      if (autoReconnectAttempted || !savedDevice) return;
      if (mac === savedDevice.mac) {
        autoReconnectAttempted = true;
        blog("发现已保存的设备 " + (name || mac) + "，正在自动连接...", "info");
        $("ble_mac").value = mac;
        $("ble_authkey").value = savedDevice.authKey;
        setTimeout(function () {
          connectBtn.click();
        }, 500);
      }
    }

    // ============= 扫描结果渲染 =============

    function renderScanResults() {
      scanResults.style.display = "";
      scanResults.innerHTML = "";
      scanDevices.forEach(function (dev) {
        var item = document.createElement("div");
        item.className = "ble-scan-result";
        var isSaved = savedDevice && dev.mac === savedDevice.mac;
        var savedBadge = isSaved ? '<span style="font-size:11px;color:var(--success);margin-left:6px">已保存</span>' : "";
        item.innerHTML =
          '<div class="ble-scan-result-info">' +
          '<div class="ble-scan-result-name">' + (dev.name || "(未知)") + savedBadge + '</div>' +
          '<div class="ble-scan-result-mac">' + dev.mac + '</div>' +
          '</div>' +
          '<div class="ble-scan-result-rssi">' + dev.rssi + ' dBm</div>';
        item.addEventListener("click", function () {
          $("ble_mac").value = dev.mac;
          if (savedDevice && dev.mac === savedDevice.mac) {
            $("ble_authkey").value = savedDevice.authKey;
          }
          if (dev.name) {
            blog("已选择: " + dev.name + " (" + dev.mac + ")", "info");
          } else {
            blog("已选择: " + dev.mac, "info");
          }
        });
        scanResults.appendChild(item);
      });
    }

    // ============= 按钮事件 =============

    connectBtn.addEventListener("click", function () {
      var mac = ($("ble_mac").value || "").trim();
      var authKey = ($("ble_authkey").value || "").trim();
      if (!mac) {
        blog("请输入 MAC 地址", "error");
        return;
      }
      if (!authKey) {
        blog("请输入 Auth Key (16字节十六进制)", "error");
        return;
      }
      clearLog();
      blog("正在连接 " + mac + "...", "info");
      setConnectedState("connecting");
      BleBridge.connect(mac, authKey);
    });

    disconnectBtn.addEventListener("click", function () {
      blog("正在断开...", "info");
      BleBridge.disconnect();
    });

    scanBtn.addEventListener("click", function () {
      scanDevices = [];
      renderScanResults();
      blog("正在扫描 Zepp 设备...", "info");
      scanBtn.style.display = "none";
      scanAllBtn.style.display = "none";
      stopScanBtn.style.display = "";
      BleBridge.scan();
    });

    scanAllBtn.addEventListener("click", function () {
      scanDevices = [];
      renderScanResults();
      blog("正在扫描所有 BLE 设备...", "info");
      scanBtn.style.display = "none";
      scanAllBtn.style.display = "none";
      stopScanBtn.style.display = "";
      BleBridge.scanAll();
    });

    stopScanBtn.addEventListener("click", function () {
      BleBridge.stopScan();
      scanBtn.style.display = "";
      scanAllBtn.style.display = "";
      stopScanBtn.style.display = "none";
      blog("扫描已停止，发现 " + scanDevices.length + " 个设备", "info");
    });

    // 停止扫描时恢复按钮
    var origLog = window.bleEvent.log;
    window.bleEvent.log = function (msg) {
      origLog(msg);
      if (msg && msg.indexOf("Scan stopped") >= 0) {
        scanBtn.style.display = "";
        scanAllBtn.style.display = "";
        stopScanBtn.style.display = "none";
      }
    };

    // 刷新信息按钮
    var refreshInfoBtn = $("ble_refreshInfoBtn");
    if (refreshInfoBtn) {
      refreshInfoBtn.addEventListener("click", function () {
        blog("正在请求设备信息...", "info");
        BleBridge.requestDeviceInfo();
      });
    }

    // ============= 应用管理 =============

    var installProgress = $("ble_installProgress");
    var installBar = $("ble_installBar");
    var installPercent = $("ble_installPercent");
    var installStatus = $("ble_installStatus");
    var appListDiv = $("ble_appList");
    var localApps = [];

    function renderAppList(appsJson) {
      try {
        localApps = JSON.parse(appsJson);
      } catch (e) {
        localApps = [];
      }
      updateAppsCount(localApps.length);
      renderAppListInternal();
    }

    function renderAppListInternal() {
      if (!appListDiv) return;
      if (localApps.length === 0) {
        appListDiv.innerHTML = '<div style="color:var(--text-muted);text-align:center;padding:20px 0">暂无已安装的应用</div>';
        return;
      }
      var html = "";
      for (var i = 0; i < localApps.length; i++) {
        var app = localApps[i];
        html += '<div class="oron-app-list-item" data-appid="' + (app.appId || i) + '" data-idx="' + i + '">';
        html += '<div class="oron-app-list-item-info">';
        html += '<div class="oron-app-list-item-name">' + escapeHtml(app.appName || "未知") + '</div>';
        html += '<div class="oron-app-list-item-meta">v' + escapeHtml(app.version || "1.0") + ' · ID: ' + (app.appId || "--") + '</div>';
        html += '</div>';
        html += '<div class="oron-app-list-item-action">';
        html += '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color:var(--text-muted)"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>';
        html += '</div>';
        html += '</div>';
      }
      appListDiv.innerHTML = html;

      // OronBox 风格: 长按打开上下文菜单，短按显示详情
      var items = appListDiv.querySelectorAll(".oron-app-list-item");
      for (var j = 0; j < items.length; j++) {
        (function(itemEl, app, idx) {
          var longPressTimer;

          itemEl.addEventListener("touchstart", function(e) {
            longPressTimer = setTimeout(function() {
              var touch = e.touches ? e.touches[0] : e;
              showContextMenu(touch.clientX, touch.clientY, app.appId, app.appName, idx);
            }, 500);
          });

          itemEl.addEventListener("touchend", function() {
            clearTimeout(longPressTimer);
          });

          itemEl.addEventListener("touchmove", function() {
            clearTimeout(longPressTimer);
          });

          itemEl.addEventListener("click", function(e) {
            if (contextMenuEl) return;
            blog("应用 " + (app.appName || "未知") + " ID: " + (app.appId || "--") + " v" + (app.version || "1.0"), "info");
          });
        })(items[j], localApps[j], j);
      }
    }

    function escapeHtml(s) {
      if (!s) return "";
      return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    function updateInstallProgress(percent, status) {
      if (installProgress) installProgress.style.display = "";
      if (installBar) installBar.style.width = percent + "%";
      if (installPercent) installPercent.textContent = percent + "%";
      if (installStatus) installStatus.textContent = status || "安装中...";
    }

    // ============= 开发者密码锁 =============
    var DEV_PASSWORD = "Hongshusen";
    var installUnlocked = false;

    function showDevPasswordDialog() {
      document.getElementById("devPasswordInput").value = "";
      document.getElementById("devPasswordError").style.display = "none";
      document.getElementById("devPasswordInput").classList.remove("error");
      document.getElementById("devPasswordDialog").style.display = "flex";
      setTimeout(function () {
        document.getElementById("devPasswordInput").focus();
      }, 100);
    }

    function hideDevPasswordDialog() {
      document.getElementById("devPasswordDialog").style.display = "none";
    }

    window.hideDevPasswordDialog = hideDevPasswordDialog;

    document.getElementById("devPasswordConfirmBtn").addEventListener("click", function () {
      var input = document.getElementById("devPasswordInput").value;
      if (input === DEV_PASSWORD) {
        installUnlocked = true;
        hideDevPasswordDialog();
        blog("开发者验证通过，安装功能已解锁", "success");
        // 解锁后自动触发对应的安装操作
        if (window._pendingInstallAction) {
          var action = window._pendingInstallAction;
          window._pendingInstallAction = null;
          if (action === "app") {
            BleBridge.selectAppFile();
          } else if (action === "wf") {
            BleBridge.selectAppFile();
          }
        }
      } else {
        var errEl = document.getElementById("devPasswordError");
        errEl.style.display = "block";
        var inputEl = document.getElementById("devPasswordInput");
        inputEl.classList.add("error");
        inputEl.value = "";
        inputEl.focus();
        setTimeout(function () {
          inputEl.classList.remove("error");
        }, 400);
      }
    });

    // 回车键也可提交
    document.getElementById("devPasswordInput").addEventListener("keydown", function (e) {
      if (e.key === "Enter") {
        document.getElementById("devPasswordConfirmBtn").click();
      }
    });

    // 点击遮罩关闭
    document.getElementById("devPasswordDialog").addEventListener("click", function (e) {
      if (e.target === this) {
        hideDevPasswordDialog();
      }
    });

    if (installAppBtn) {
      installAppBtn.addEventListener("click", function () {
        if (!installUnlocked) {
          window._pendingInstallAction = "app";
          showDevPasswordDialog();
          return;
        }
        if (window.BleBridge) {
          BleBridge.selectAppFile();
        }
      });
    }

    // OronBox 风格: 表盘安装按钮（与安装应用使用同一文件选择器，原生层自动识别类型）
    if (installWfBtn) {
      installWfBtn.addEventListener("click", function () {
        if (!installUnlocked) {
          window._pendingInstallAction = "wf";
          showDevPasswordDialog();
          return;
        }
        if (window.BleBridge) {
          BleBridge.selectAppFile();
        }
      });
    }

    // OronBox 风格: 队列开始/暂停按钮
    // 原生层 (BleManager) 在 addToQueue 后自动调用 processQueue 串行安装
    // JS 层只负责 UI 状态展示，不干预原生层的队列调度
    if (queueStartBtn) {
      queueStartBtn.addEventListener("click", function () {
        if (queueIsRunning) {
          queueIsRunning = false;
          queueStartBtn.textContent = "开始";
          blog("安装队列已暂停（UI标记）", "warning");
        } else {
          if (installQueue.length === 0) {
            blog("队列为空，请先添加安装任务", "warning");
            return;
          }
          queueIsRunning = true;
          queueStartBtn.textContent = "暂停";
          blog("安装队列运行中（原生层自动管理）", "success");
        }
      });
    }

    // OronBox 风格: 队列清空按钮
    if (queueClearBtn) {
      queueClearBtn.addEventListener("click", function () {
        if (installQueue.length === 0) return;
        if (confirm("确定要清空安装队列吗?")) {
          installQueue = [];
          queueIsRunning = false;
          if (queueStartBtn) queueStartBtn.textContent = "开始";
          renderQueueList();
          blog("队列已清空", "info");
          if (window.AndroidBridge) AndroidBridge.clearInstallQueue();
        }
      });
    }

    // 复制日志
    var copyLogBtn = $("ble_copyLogBtn");
    if (copyLogBtn) {
      copyLogBtn.addEventListener("click", function () {
        var lines = bleLog.querySelectorAll(".log-line");
        var text = "";
        for (var i = 0; i < lines.length; i++) {
          text += lines[i].textContent + "\n";
        }
        if (navigator.clipboard) {
          navigator.clipboard.writeText(text).then(function () {
            copyLogBtn.textContent = "已复制!";
            setTimeout(function () { copyLogBtn.textContent = "复制日志"; }, 2000);
          });
        } else {
          if (window.AndroidFileSaver) {
            AndroidFileSaver.copyText(text);
            copyLogBtn.textContent = "已复制!";
            setTimeout(function () { copyLogBtn.textContent = "复制日志"; }, 2000);
          }
        }
      });
    }

    // 清空日志
    var clearLogBtn = $("ble_clearLogBtn");
    if (clearLogBtn) {
      clearLogBtn.addEventListener("click", function () {
        if (bleLog) bleLog.innerHTML = "";
      });
    }

    // ============= 初始化：加载已保存设备 + 自动连接 =============

    loadSavedDevice();
    if (savedDevice) {
      // 有已保存设备：直接进入设备管理页面，后台自动连接
      $("ble_mac").value = savedDevice.mac;
      $("ble_authkey").value = savedDevice.authKey;
      var macSuffix3 = "";
      if (savedDevice && savedDevice.mac) {
        macSuffix3 = " (" + savedDevice.mac.replace(/:/g, "").slice(-4) + ")";
      }
      if (deviceNameEl) {
        deviceNameEl.textContent = "Xiaomi Smart Band 7" + macSuffix3;
      }
      // 隐藏连接设置面板，直接显示设备面板
      if (connectCard) connectCard.classList.add("collapsed");
      if (devicePanel) devicePanel.style.display = "";
      // 显示连接阶段指示器
      setConnectedState("connecting");
      blog("正在连接 " + ("Xiaomi Smart Band 7" + macSuffix3) + "...", "info");
      // 直接发起连接，无需扫描
      clearLog();
      BleBridge.connect(savedDevice.mac, savedDevice.authKey);
    } else {
      // 无已保存设备：显示连接面板，等待用户手动操作
      blog("请扫描设备或输入 MAC 地址和 Auth Key 进行连接", "info");
    }
  }

  // ===========================================================================
  // 日志级别 — 全局
  // ===========================================================================

  var _logLevel = "verbose";  // verbose | info | error

  function setLogLevel(level) {
    _logLevel = level;
    try { localStorage.setItem("zeppbox_logLevel", level); } catch (e) {}
    // 更新分段控制器 UI
    var seg = document.getElementById("setting_logLevel");
    if (seg) {
      var btns = seg.querySelectorAll(".settings-segment-btn");
      btns.forEach(function (b) {
        b.classList.toggle("active", b.getAttribute("data-level") === level);
      });
    }
  }

  function initLogLevel() {
    var saved = "verbose";
    try { saved = localStorage.getItem("zeppbox_logLevel") || "verbose"; } catch (e) {}
    setLogLevel(saved);
  }

  // ===========================================================================
  // 初始化
  // ===========================================================================

  function init() {
    var grid = $("toolGrid");
    TOOLS.forEach(function (tool, index) {
      var colors = TOOL_COLORS[tool.id] || { bg: "rgba(0, 122, 255, 0.12)", fg: "#007aff" };
      var card = document.createElement("div");
      card.className = "tool-card";
      // Miuix Folme 弹簧交错动画
      card.style.opacity = "0";
      card.style.transform = "translateY(12px) scale(0.95)";
      card.style.transition = "opacity 0.4s cubic-bezier(0.22, 0.61, 0.36, 1), transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)";
      card.innerHTML =
        '<div class="tool-card-icon" style="background:' + colors.bg + ';color:' + colors.fg + '">' + (ICONS[tool.id] || "") + '</div>' +
        '<div class="tool-card-name">' + tool.name + '</div>' +
        '<div class="tool-card-desc">' + tool.desc + '</div>';
      card.addEventListener("click", function () {
        navigateTo(tool.id);
      });
      grid.appendChild(card);
      // 交错延迟（每张卡片延迟 40ms）
      setTimeout(function () {
        card.style.opacity = "1";
        card.style.transform = "translateY(0) scale(1)";
      }, 50 + index * 40);
    });

    // 工具页面返回按钮 → 回到工具首页
    $("backBtn").addEventListener("click", navigateHome);

    // 首页信息按钮 → 关于页
    $("homeInfoBtn").addEventListener("click", navigateToAbout);

    // ========== 设置页面按钮 ==========
    // 添加小组件
    var settingAddWidget = $("setting_addWidget");
    if (settingAddWidget) {
      settingAddWidget.addEventListener("click", function () {
        if (window.AndroidBridge && window.AndroidBridge.requestPinWidget) {
          try {
            AndroidBridge.requestPinWidget();
            blog("正在请求添加桌面小组件...", "info");
          } catch (e) {
            blog("添加小组件失败: " + e, "error");
          }
        } else {
          blog("当前系统不支持一键添加小组件", "warning");
        }
      });
    }
    // 查看关于
    var settingGotoAbout = $("setting_gotoAbout");
    if (settingGotoAbout) {
      settingGotoAbout.addEventListener("click", navigateToAbout);
    }
    // 清除已保存设备
    var settingClearDevice = $("setting_clearDevice");
    if (settingClearDevice) {
      settingClearDevice.addEventListener("click", function () {
        if (confirm("确定要清除已保存的设备信息吗？\n清除后需要重新扫描连接。")) {
          clearSavedDevice();
          blog("已清除设备信息", "info");
          if (devicePanel) devicePanel.style.display = "none";
          if (statusGrid) statusGrid.style.display = "none";
          if (appCard) appCard.style.display = "none";
          if (queueCard) queueCard.style.display = "none";
          if (connectCard) connectCard.classList.remove("collapsed");
          _updateWidget("ZeppBox", "disconnected", "");
        }
      });
    }

    // 底部导航栏
    var navItems = document.querySelectorAll(".bottom-nav-item");
    navItems.forEach(function (item) {
      item.addEventListener("click", function () {
        var nav = item.getAttribute("data-nav");
        if (nav === "tools") {
          navigateHome();
        } else if (nav === "device") {
          navigateToDevice();
        } else if (nav === "settings") {
          navigateToSettings();
        }
      });
    });

    // =========================================================================
    // 自动跳转：有已保存设备时，直接进入设备页面（类似小米运动健康）
    // 每次打开程序自动刷新连接，无需手动操作
    // =========================================================================
    try {
      if (window.AndroidBridge) {
        var savedJson = AndroidBridge.getSavedDevice();
        if (savedJson && savedJson !== "null") {
          // 有已保存设备：自动跳转到设备页面，后台自动连接
          // 延迟执行，确保 navigateToDevice 内部的 DOM 操作能正确获取元素
          setTimeout(function () {
            navigateToDevice();
          }, 100);
        }
      }
    } catch (e) {}

    // =========================================================================
    // 全局液态玻璃按压反馈（iOS 风格涟漪 + 光晕）
    // 自动为所有按钮、卡片、可交互元素注入按压效果
    // =========================================================================
    initGlobalGlassPress();
  }

  // ===========================================================================
  // 全局液态玻璃按压反馈初始化
  // ===========================================================================
  function initGlobalGlassPress() {
    // 标记需要涟漪效果的元素选择器
    var rippleSelectors = [
      'button', '.btn', '.tool-card', '.glass-card', '.oron-status-card',
      '.miuix-basic-row', '.ct-tab', '.mode-btn', '.api-tab',
      '.oron-app-list-item', '.ble-scan-result', '.file-item',
      '.ct-item', '.aj-check-item', '.zone-drop', '.drop-zone',
      '.oron-context-menu-item', '.oron-queue-item-remove',
      '.queue-cancel-btn', '.queue-remove-btn', '.back-btn',
      '.header-info-btn', '.bottom-nav-item', '.home-highlight',
      '.miuix-snackbar-action', '.oron-dialog-close',
      '.card', '.ble-info-item', '.oron-queue-item', '.api-item'
    ].join(',');

    // mousedown / touchstart 全局委托
    document.addEventListener('pointerdown', function (e) {
      var target = e.target;
      // 向上查找最近的可涟漪元素
      var el = target.closest(rippleSelectors);
      if (!el) return;

      // 确保元素有 position: relative 用于涟漪定位
      var computed = getComputedStyle(el);
      if (computed.position === 'static') {
        el.style.position = 'relative';
      }
      if (computed.overflow === 'visible' || computed.overflow === '') {
        el.style.overflow = 'hidden';
      }

      // 创建涟漪
      var rect = el.getBoundingClientRect();
      var size = Math.max(rect.width, rect.height) * 2;
      var x = e.clientX - rect.left;
      var y = e.clientY - rect.top;

      var ripple = document.createElement('div');
      ripple.className = 'glass-ripple';
      ripple.style.width = size + 'px';
      ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      el.appendChild(ripple);

      // 动画结束后清理
      ripple.addEventListener('animationend', function () {
        if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
      });

      // 创建光晕覆盖层
      var overlay = document.createElement('div');
      overlay.className = 'glass-press-overlay';
      overlay.style.borderRadius = computed.borderRadius || 'inherit';
      el.appendChild(overlay);

      overlay.addEventListener('animationend', function (ev) {
        if (ev.animationName === 'glass-press-overlay-out') {
          if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        }
      });

      // 5秒后强制清理（以防万一）
      setTimeout(function () {
        if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      }, 5000);
    }, { passive: true });

    // 初始化日志级别
    initLogLevel();

    // 日志级别分段控制器事件
    var logSeg = document.getElementById("setting_logLevel");
    if (logSeg) {
      var logBtns = logSeg.querySelectorAll(".settings-segment-btn");
      logBtns.forEach(function (btn) {
        btn.addEventListener("click", function () {
          setLogLevel(btn.getAttribute("data-level"));
        });
      });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // ============= 全局设备信息对话框 =============

  window.showDeviceInfoDialog = function () {
    var dialog = document.getElementById("deviceInfoDialog");
    if (!dialog) return;
    // 从 ble 管理器获取设备信息数据
    var dlgMfr = document.getElementById("dlg_manufacturer");
    var dlgModel = document.getElementById("dlg_model");
    var dlgSerial = document.getElementById("dlg_serial");
    var dlgFw = document.getElementById("dlg_firmware");
    // 通过 DOM 读取当前卡片上的设备信息
    if (dlgMfr) dlgMfr.textContent = (window._deviceInfoManufacturer) || "--";
    if (dlgModel) dlgModel.textContent = (window._deviceInfoModel) || "--";
    if (dlgSerial) dlgSerial.textContent = (window._deviceInfoSerial) || "--";
    if (dlgFw) dlgFw.textContent = (window._deviceInfoFirmware) || "--";
    dialog.style.display = "flex";
    dialog.addEventListener("click", function onOverlayClick(e) {
      if (e.target === dialog) {
        dialog.style.display = "none";
        dialog.removeEventListener("click", onOverlayClick);
      }
    });
  };

  window.hideDeviceInfoDialog = function () {
    var dialog = document.getElementById("deviceInfoDialog");
    if (dialog) dialog.style.display = "none";
  };

  // 暴露手动刷新函数到全局作用域（供 HTML onclick 调用）
  window._manualRefreshDeviceInfo = _manualRefreshDeviceInfo;
  window._manualRefreshBattery = _manualRefreshBattery;

})();
